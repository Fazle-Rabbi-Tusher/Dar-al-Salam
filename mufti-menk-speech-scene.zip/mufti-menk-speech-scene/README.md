# Mufti Menk speech scene

A draft 3D-looking pixel-art lecture scene, with Mufti Menk based on the supplied
photographs, eight fictional seated listeners (four men and four women), a lectern
with microphones, and two tripod cameras in front of the speaker.

## Preview

From this extracted folder, run `python3 -m http.server 8000`, then open
`http://localhost:8000/preview/`. The preview uses the included PNGs and plain
JavaScript, with Play/Pause and a frame scrubber. It needs no Node dependencies.
`preview/speech-scene.mp4` and `preview/speech-scene.gif` show the full loop.
The sequence is a visual animation script, with no purported quotation or voice.

## Original repository animation checked

The existing repository already has the named card `mufti-ismail-menk`, a 120-frame
`talk`/`idle` script and four supplied animation strips. Copies of those original
files are in `original-animation/`. The asset builder expects horizontal strips
of 224 x 336 pixel cells, feet at (112,320), density 4. It loads SE and NE strips
and mirrors them for SW and NW. The generated speaker and seated audience assets
follow that format. Existing card identity, biography, links, sources and review
status are preserved. `panelApproved` remains false.

## Scripts and logic

- `scene.js`: pure deterministic 12 fps / 240-frame (20-second) scene model.
  Speaking: 0-84, pause: 84-108, speaking: 108-192, pause: 192-216,
  speaking: 216-240. The loop returns to speaking seamlessly.
- Speaker `talk` uses four poses at 3 ticks/pose; `idle` uses 6 ticks/pose,
  matching the repository's original strip tempo.
- All eight listeners remain seated, facing NE or NW toward the speaker. Their two-pose
  listening strips have reversed ordering for alternating variants, giving
  staggered nods on the same clock. Variation is fixed at authoring time, with
  no runtime randomness or wall-clock calls in scene state.
- Two recording cameras aim at the speaker. Four head poses repeat over 120 ticks;
  the tripod legs are pixel-identical in every pose.
- `repo-overlay/art/`: twelve character strips and six equipment/stage PNGs.
  Equipment is mapped to the repository's existing world palette. Alpha mattes
  are snapped to clean transparent/opaque pixels. Full-colour source sheets are
  preserved in `source-sheets/`. The browser preview also includes 4x-density
  display props to match its detailed characters; native props follow the
  repository's existing world-object resolution and palette. The extra stage platform is available as an
  optional prop; the installed scene uses the existing hall floor.
- `install.mjs`: idempotent native integration, merging object metadata and room
  placements, updating only the named card's loop/script, adding the eight
  anonymous audience members and copying prepared PNGs.
- `prepare-assets.mjs`: optional regeneration from the included source sheets,
  using the repository's installed Sharp dependency. Normal use needs no reimport.
- `verify.mjs`: checks identity/review preservation, native schema/script validity,
  name rules, 240-frame determinism, fixed seating, camera aim, strip dimensions
  and fixed tripod geometry.

## Install into Dar-al-Salam

Copy this complete folder to `scene-packs/menk-speech` in the project. From the
repository root, with its normal Node 24 / pnpm dependencies installed:

    node scene-packs/menk-speech/install.mjs .
    node --import tsx scene-packs/menk-speech/verify.mjs .
    pnpm build:preview
    pnpm dev

Navigate to Mufti Ismail Menk at tile (12.7,10.4), in the existing hall. Installation
changes his four original strips; retain the included originals or use Git to
restore them. Repository advisory approval rules still apply to production.

The downloadable ZIP includes prepared art, original animation references,
sources, scripts, browser preview, MP4/GIF and checksum inventory. These are
2D assets shaded to appear three-dimensional, not rigged 3D meshes.

The repository test update for its former no-background-people assumption is
in `integration/pipeline-test.patch`; apply it with `git apply` if using the
scene with that older test suite. It limits the exception to these eight seated
listeners and counts every ambient file.
