import sharp from 'sharp';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(root, 'repo-overlay');
const source = {
  speaker: 'exec-ed892d91-9877-4529-961a-90b276343eab.png',
  audience: 'exec-7e1bd64f-e500-4b7a-b69e-20638181fbd4.png',
  cameras: 'exec-592ac831-4837-4167-99a3-6528dfc97a27.png',
};
for (const p of [
  'source-sheets',
  'original-animation',
  'repo-overlay/art/sprites/anim',
  'repo-overlay/art/objects',
  'preview',
])
  await fs.mkdir(path.join(root, p), { recursive: true });
for (const [name, file] of Object.entries(source)) {
  const target = path.join(root, 'source-sheets', name + '.png');
  try {
    await fs.access(target);
  } catch {
    await fs.copyFile('/workspace/generated_images/' + file, target);
  }
}
async function cells(name, cols, rows) {
  let file = await fs.readFile(path.join(root, 'source-sheets', name + '.png'));
  if (name === 'cameras') {
    const { data, info } = await sharp(file)
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });
    for (let i = 0; i < data.length; i += 4)
      if (data[i] > 160 && data[i + 2] > 140 && data[i + 1] < 110)
        data[i + 3] = 0;
    file = await sharp(data, {
      raw: { width: info.width, height: info.height, channels: 4 },
    })
      .png()
      .toBuffer();
  }
  const { width, height } = await sharp(file).metadata();
  const result = [];
  for (let row = 0; row < rows; row++)
    for (let col = 0; col < cols; col++) {
      const left = Math.round((col * width) / cols),
        top = Math.round((row * height) / rows),
        right = Math.round(((col + 1) * width) / cols),
        bottom = Math.round(((row + 1) * height) / rows);
      const cropped = await sharp(file)
        .extract({ left, top, width: right - left, height: bottom - top })
        .png()
        .toBuffer();
      result.push(await sharp(cropped).trim({ threshold: 8 }).png().toBuffer());
    }
  return result;
}
const transparent = (w, h) =>
  sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  });
async function normalized(buffer, w, h, anchor, maxW, maxH) {
  const { data, info } = await sharp(buffer)
    .resize(maxW, maxH, { fit: 'inside', kernel: 'nearest' })
    .png()
    .toBuffer({ resolveWithObject: true });
  const png = await transparent(w, h)
    .composite([
      {
        input: data,
        left: Math.round(anchor[0] - info.width / 2),
        top: anchor[1] - info.height,
      },
    ])
    .png()
    .toBuffer();
  const raw = await sharp(png).ensureAlpha().raw().toBuffer();
  for (let i = 3; i < raw.length; i += 4) raw[i] = raw[i] >= 64 ? 255 : 0;
  return sharp(raw, { raw: { width: w, height: h, channels: 4 } })
    .png()
    .toBuffer();
}
const speaker = await cells('speaker', 4, 4),
  audience = await cells('audience', 4, 4),
  equipment = await cells('cameras', 4, 2);
const frameMeta = {};
async function strip(id, action, facing, frames, maxW = 208, maxH = 292) {
  const prepared = await Promise.all(
    frames.map((b) => normalized(b, 224, 336, [112, 320], maxW, maxH)),
  );
  const name = `${id}__${action}_${facing}.png`;
  await transparent(224 * frames.length, 336)
    .composite(prepared.map((input, i) => ({ input, left: i * 224, top: 0 })))
    .png()
    .toFile(path.join(out, 'art/sprites/anim', name));
  frameMeta[name] = {
    frameWidth: 224,
    frameHeight: 336,
    frames: frames.length,
    anchor: [112, 320],
    density: 4,
  };
}
for (const [row, action, facing] of [
  [0, 'talk', 'SE'],
  [1, 'talk', 'NE'],
  [2, 'idle', 'SE'],
  [3, 'idle', 'NE'],
])
  await strip(
    'mufti-ismail-menk',
    action,
    facing,
    speaker.slice(row * 4, row * 4 + 4),
  );
for (let i = 0; i < 8; i++)
  await strip(
    `menk-speech-listener-${i + 1}`,
    'sit',
    'NE',
    i % 2
      ? audience.slice(i * 2, i * 2 + 2).reverse()
      : audience.slice(i * 2, i * 2 + 2),
    208,
    230,
  );
// The camera's legs stay fixed; only its upper head changes pose.
const cameraFrames = await Promise.all(
  equipment.slice(0, 4).map((b) => normalized(b, 40, 56, [20, 54], 36, 52)),
);
const fixedLegs = await sharp(cameraFrames[0])
  .extract({ left: 0, top: 24, width: 40, height: 32 })
  .png()
  .toBuffer();
for (let i = 0; i < 4; i++) {
  const head = await sharp(cameraFrames[i])
    .extract({ left: 0, top: 0, width: 40, height: 24 })
    .png()
    .toBuffer();
  await transparent(40, 56)
    .composite([
      { input: head, left: 0, top: 0 },
      { input: fixedLegs, left: 0, top: 24 },
    ])
    .png()
    .toFile(path.join(out, 'art/objects', `menk-camera-${i}.png`));
}
await fs.writeFile(
  path.join(out, 'art/objects/menk-lectern.png'),
  await normalized(equipment[4], 64, 64, [32, 61], 60, 52),
);
await fs.writeFile(
  path.join(out, 'art/objects/menk-stage.png'),
  await normalized(equipment[7], 144, 72, [72, 68], 140, 62),
);
await fs.writeFile(
  path.join(root, 'strip-metadata.json'),
  JSON.stringify(frameMeta, null, 2) + '\n',
);
console.log(
  'Prepared four speaker strips, eight seated listener strips and six equipment PNGs.',
);
// Recording equipment follows the repository's existing object palette.
const palette = JSON.parse(
  await fs.readFile('content/palettes/world-palette.json', 'utf8'),
).map((hex) => [
  parseInt(hex.slice(1, 3), 16),
  parseInt(hex.slice(3, 5), 16),
  parseInt(hex.slice(5, 7), 16),
]);
for (const name of await fs.readdir(path.join(out, 'art/objects'))) {
  const file = path.join(out, 'art/objects', name);
  const { data, info } = await sharp(file)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  const cache = new Map();
  for (let i = 0; i < data.length; i += 4) {
    if (!data[i + 3]) continue;
    const key = (data[i] << 16) | (data[i + 1] << 8) | data[i + 2];
    let best = cache.get(key);
    if (!best) {
      let distance = Infinity;
      for (const c of palette) {
        const d =
          (data[i] - c[0]) ** 2 +
          (data[i + 1] - c[1]) ** 2 +
          (data[i + 2] - c[2]) ** 2;
        if (d < distance) {
          distance = d;
          best = c;
        }
      }
      cache.set(key, best);
    }
    data[i] = best[0];
    data[i + 1] = best[1];
    data[i + 2] = best[2];
  }
  await sharp(data, {
    raw: { width: info.width, height: info.height, channels: 4 },
  })
    .png()
    .toFile(file);
}
// Detailed 4x display props keep the preview at the same density as supplied people.
const display = path.join(root, 'preview/art');
await fs.mkdir(display, { recursive: true });
const high = await Promise.all(
  equipment
    .slice(0, 4)
    .map((b) => normalized(b, 160, 224, [80, 216], 144, 208)),
);
const highLegs = await sharp(high[0])
  .extract({ left: 0, top: 96, width: 160, height: 128 })
  .png()
  .toBuffer();
for (let i = 0; i < 4; i++) {
  const head = await sharp(high[i])
    .extract({ left: 0, top: 0, width: 160, height: 96 })
    .png()
    .toBuffer();
  await transparent(160, 224)
    .composite([
      { input: head, left: 0, top: 0 },
      { input: highLegs, left: 0, top: 96 },
    ])
    .png()
    .toFile(path.join(display, `menk-camera-${i}.png`));
}
await fs.writeFile(
  path.join(display, 'menk-lectern.png'),
  await normalized(equipment[4], 256, 256, [128, 244], 240, 208),
);
