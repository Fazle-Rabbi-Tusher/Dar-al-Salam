import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import './scene.js';
const root = path.dirname(fileURLToPath(import.meta.url)),
  scene = globalThis.MenkSpeechScene;
const repo = path.resolve(process.argv[2] ?? '.');
const { characterSchema } = await import(
  path.join(repo, 'packages/shared/schema.ts')
);
const { scriptErrors, characterState } = await import(
  path.join(repo, 'packages/shared/script.ts')
);
const { forbiddenName } = await import(
  path.join(repo, 'packages/shared/rules.ts')
);
const read = async (p) =>
  JSON.parse(await fs.readFile(path.join(repo, p), 'utf8'));
const rules = await read('content/rules/never-depict.json');
const card = characterSchema.parse(
  await read('content/characters/mufti-ismail-menk.json'),
);
const original = JSON.parse(
  await fs.readFile(
    path.join(root, 'original-animation/mufti-ismail-menk.json'),
    'utf8',
  ),
);
for (const key of Object.keys(original))
  if (!['loop', 'script'].includes(key))
    assert.deepEqual(card[key], original[key], key);
assert.equal(card.panelApproved, false);
const crowd = await read('content/ambient/menk-speech.json');
assert.equal(crowd.length, 8);
assert.equal(scene.audience.filter((a) => a.gender === 'female').length, 4);
for (const actor of [card, ...crowd]) {
  characterSchema.parse(actor);
  assert.deepEqual(scriptErrors(actor), []);
  for (const name of [
    actor.id,
    ...Object.values(actor.name ?? {}),
    ...(actor.aliases ?? []),
  ])
    assert.equal(forbiddenName(name, rules), false, name);
  for (let f = 0; f < 240; f++) assert.ok(characterState(actor, f));
}
for (let f = 0; f < 240; f++) {
  const state = scene.state(f);
  assert.deepEqual(state, scene.state(f + 240));
  for (const a of state.audience) {
    assert.equal(a.action, 'sit');
    assert.ok(['NE', 'NW'].includes(a.facing));
    assert.equal(
      a.facing,
      scene.speakerTile[0] - a.tile[0] - (scene.speakerTile[1] - a.tile[1]) >= 0
        ? 'NE'
        : 'NW',
    );
    assert.deepEqual(a.tile, scene.audience.find((x) => x.id === a.id).tile);
  }
  for (const camera of state.cameras) {
    assert.equal(camera.recording, true);
    assert.deepEqual(camera.aim, scene.speakerTile);
    assert.ok(camera.tile[1] > scene.speakerTile[1]);
  }
}
const metadata = JSON.parse(
  await fs.readFile(path.join(root, 'strip-metadata.json'), 'utf8'),
);
for (const [name, meta] of Object.entries(metadata)) {
  const m = await sharp(
    path.join(root, 'repo-overlay/art/sprites/anim', name),
  ).metadata();
  assert.equal(m.width, 224 * meta.frames);
  assert.equal(m.height, 336);
  assert.equal(m.hasAlpha, true);
}
const legs = await Promise.all(
  [0, 1, 2, 3].map((i) =>
    sharp(path.join(root, `repo-overlay/art/objects/menk-camera-${i}.png`))
      .extract({ left: 0, top: 24, width: 40, height: 32 })
      .raw()
      .toBuffer(),
  ),
);
for (const other of legs) assert.deepEqual(other, legs[0]);
console.log(
  'Passed: native schema/scripts, identity/review preservation, 240-frame determinism, eight seated listeners, camera aim/fixed legs, twelve strip dimensions.',
);
