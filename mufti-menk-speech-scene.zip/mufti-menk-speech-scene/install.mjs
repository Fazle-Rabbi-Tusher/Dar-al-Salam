import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './scene.js';
const source = path.dirname(fileURLToPath(import.meta.url)),
  target = path.resolve(process.argv[2] ?? '.');
const read = async (p) =>
  JSON.parse(await fs.readFile(path.join(target, p), 'utf8'));
const write = async (p, v) => {
  await fs.mkdir(path.dirname(path.join(target, p)), { recursive: true });
  await fs.writeFile(path.join(target, p), JSON.stringify(v, null, 2) + '\n');
};
const scene = globalThis.MenkSpeechScene;
const card = await read('content/characters/mufti-ismail-menk.json');
// Keep all identity, biography, source and panel-review fields exactly as found.
card.loop = 240;
card.script = scene.steps;
await fs.cp(path.join(source, 'repo-overlay/art'), path.join(target, 'art'), {
  recursive: true,
});
await write('content/characters/mufti-ismail-menk.json', card);
const listeners = scene.audience.map((a) => ({
  id: a.id,
  kind: 'person',
  aliases: [],
  district: 'modern-quarter',
  depiction: 'back',
  role: `Seated ${a.gender} listener at the talk`,
  look: {
    ...card.look,
    base: a.gender === 'female' ? 'adult-woman' : 'adult-man-beard',
    garment: a.gender === 'female' ? 'abaya' : 'jubba',
    headwear: a.gender === 'female' ? 'hijab' : 'none',
  },
  loop: 240,
  script: [{ from: 0, to: 240, action: 'sit', at: a.tile, facing: a.facing }],
}));
await write('content/ambient/menk-speech.json', listeners);
const objectIndex = await read('art/objects/index.json');
objectIndex['menk-recording-camera'] = {
  file: 'objects/menk-camera-0.png',
  width: 40,
  height: 56,
  anchor: [20, 54],
  frames: [0, 1, 2, 3].map((i) => `objects/menk-camera-${i}.png`),
  period: 120,
};
objectIndex['menk-speech-lectern'] = {
  file: 'objects/menk-lectern.png',
  width: 64,
  height: 64,
  anchor: [32, 61],
};
await write('art/objects/index.json', objectIndex);
const room = await read('rooms/mosque-garden.tmj'),
  layer = room.layers.find((l) => l.type === 'objectgroup');
const types = new Set(['menk-recording-camera', 'menk-speech-lectern']);
const old = layer.objects.filter((o) => types.has(o.type));
layer.objects = layer.objects.filter((o) => !types.has(o.type));
let id = Math.max(...layer.objects.map((o) => o.id)) + 1;
const placements = [
  ...scene.cameras.map((c) => ({
    type: 'menk-recording-camera',
    tile: c.tile,
  })),
  { type: 'menk-speech-lectern', tile: [12.9, 10.95] },
];
placements.forEach((p, i) =>
  layer.objects.push({
    id: old[i]?.id ?? id++,
    type: p.type,
    x: p.tile[0],
    y: p.tile[1],
    footprint: [1, 1],
    walkable: false,
    z: 0,
  }),
);
await write('rooms/mosque-garden.tmj', room);
console.log(
  'Installed: original Menk card updated, eight seated listeners, two cameras, lectern; review metadata preserved.',
);
