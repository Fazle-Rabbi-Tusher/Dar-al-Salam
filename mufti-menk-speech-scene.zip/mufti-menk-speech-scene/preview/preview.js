/* Preview host owns elapsed time; the shared scene model evaluates integer frames only. */
const model = globalThis.MenkSpeechScene,
  canvas = document.querySelector('#scene'),
  ctx = canvas.getContext('2d');
const images = new Map(),
  base = '../repo-overlay/art/';
const names = [
  'sprites/anim/mufti-ismail-menk__talk_SE.png',
  'sprites/anim/mufti-ismail-menk__idle_SE.png',
  ...[1, 2, 3, 4, 5, 6, 7, 8].map(
    (i) => `sprites/anim/menk-speech-listener-${i}__sit_NE.png`,
  ),
  ...[0, 1, 2, 3].map((i) => `objects/menk-camera-${i}.png`),
  'objects/menk-lectern.png',
];
let worldFrame = 0,
  playing = true,
  accumulator = 0,
  lastTime;
const zoom = 2.6,
  origin = [690, 240];
function project(p) {
  return [
    origin[0] + (p[0] - p[1] - (12.7 - 10.4)) * 16 * zoom,
    origin[1] + (p[0] + p[1] - (12.7 + 10.4)) * 8 * zoom,
  ];
}
function polygon(points, fill, stroke) {
  ctx.beginPath();
  points.forEach((p, i) => (i ? ctx.lineTo(...p) : ctx.moveTo(...p)));
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}
function floor() {
  ctx.fillStyle = '#151c25';
  ctx.fillRect(0, 0, 1100, 720);
  const corners = [
    [7.8, 8],
    [20.8, 8],
    [20.8, 21],
    [7.8, 21],
  ].map(project);
  polygon(corners, '#9c7953', '#c7a97a');
  for (let i = 8; i <= 21; i++) {
    const a = project([i, 8]),
      b = project([i, 21]);
    ctx.strokeStyle = '#896743';
    ctx.beginPath();
    ctx.moveTo(...a);
    ctx.lineTo(...b);
    ctx.stroke();
    const c = project([8, i]),
      d = project([20.8, i]);
    ctx.beginPath();
    ctx.moveTo(...c);
    ctx.lineTo(...d);
    ctx.stroke();
  }
  const a = project([7.8, 8]),
    b = project([20.8, 8]);
  polygon([a, b, [b[0], b[1] - 110], [a[0], a[1] - 110]], '#27343a', '#4a5350');
  const c = project([7.8, 21]);
  polygon([a, c, [c[0], c[1] - 110], [a[0], a[1] - 110]], '#202c32', '#4a5350');
  polygon(
    [
      [9, 9],
      [18, 9],
      [18, 12],
      [9, 12],
    ].map(project),
    '#705b42',
    '#bca270',
  );
}
function sprite(image, tile, w, h, anchor, flip = false) {
  const [x, y] = project(tile);
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));
  if (flip) ctx.scale(-1, 1);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(
    image,
    0,
    0,
    image.width,
    image.height,
    -anchor[0] * zoom,
    -anchor[1] * zoom,
    w * zoom,
    h * zoom,
  );
  ctx.restore();
}
function person(image, tile, frame, flip = false) {
  const [x, y] = project(tile);
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));
  if (flip) ctx.scale(-1, 1);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(
    image,
    frame * 224,
    0,
    224,
    336,
    -28 * zoom,
    -80 * zoom,
    56 * zoom,
    84 * zoom,
  );
  ctx.restore();
}
function render(frame = worldFrame) {
  worldFrame = model.frame(frame);
  const s = model.state(worldFrame);
  floor();
  const queue = [];
  queue.push({
    tile: s.speaker.tile,
    draw: () =>
      person(
        images.get(
          `sprites/anim/mufti-ismail-menk__${s.speaker.action}_SE.png`,
        ),
        s.speaker.tile,
        s.speaker.pose,
        true,
      ),
  });
  queue.push({
    tile: s.lectern.tile,
    draw: () =>
      sprite(
        images.get('objects/menk-lectern.png'),
        s.lectern.tile,
        64,
        64,
        [32, 61],
      ),
  });
  for (const a of s.audience)
    queue.push({
      tile: a.tile,
      draw: () =>
        person(
          images.get(`sprites/anim/${a.id}__sit_NE.png`),
          a.tile,
          a.pose,
          a.facing === 'NW',
        ),
    });
  for (const c of s.cameras)
    queue.push({
      tile: c.tile,
      draw: () =>
        sprite(
          images.get(`objects/menk-camera-${c.pose}.png`),
          c.tile,
          40,
          56,
          [20, 54],
        ),
    });
  queue.sort((a, b) => a.tile[0] + a.tile[1] - b.tile[0] - b.tile[1]);
  queue.forEach((o) => o.draw());
  ctx.fillStyle = '#c9b98f';
  ctx.font = '14px monospace';
  ctx.fillText('DRAFT ART · SHARED 240-FRAME CLOCK', 28, 688);
  document.querySelector('#scrub').value = worldFrame;
  document.querySelector('#status').textContent =
    `${s.speaker.action === 'talk' ? 'Speaking' : 'Listening pause'} · ${(worldFrame / 12).toFixed(1)} s`;
}
function tick(t) {
  if (lastTime !== undefined && playing) {
    accumulator += Math.min(1000, t - lastTime);
    while (accumulator >= 1000 / 12) {
      worldFrame = model.frame(worldFrame + 1);
      accumulator -= 1000 / 12;
    }
    render();
  }
  lastTime = t;
  requestAnimationFrame(tick);
}
document.querySelector('#play').onclick = () => {
  playing = !playing;
  accumulator = 0;
  document.querySelector('#play').textContent = playing ? 'Pause' : 'Play';
};
document.querySelector('#scrub').oninput = (e) => {
  playing = false;
  document.querySelector('#play').textContent = 'Play';
  render(Number(e.target.value));
};
globalThis.scenePreview = {
  setFrame(f) {
    playing = false;
    render(f);
  },
  get frame() {
    return worldFrame;
  },
  get playing() {
    return playing;
  },
};
globalThis.sceneReady = Promise.all(
  names.map(
    (name) =>
      new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => {
          images.set(name, image);
          resolve();
        };
        image.onerror = () => reject(Error('Missing ' + name));
        image.src = name.startsWith('objects/')
          ? 'art/' + name.split('/').pop()
          : base + name;
      }),
  ),
).then(() => {
  render(0);
  requestAnimationFrame(tick);
});
