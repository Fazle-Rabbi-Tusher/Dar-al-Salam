/* Pure fixed-frame scene state. Works in browsers and Node; no runtime randomness. */
(() => {
  const speakerTile = [12.7, 10.4];
  const variants = [0, 5, 2, 7, 4, 1, 6, 3];
  const positions = [
    [9.4, 14],
    [11.5, 14],
    [15, 14],
    [17.1, 14],
    [9.4, 16.7],
    [11.5, 16.7],
    [15, 16.7],
    [17.1, 16.7],
  ];
  const audience = variants.map((variant, i) => ({
    id: `menk-speech-listener-${variant + 1}`,
    gender: variant < 4 ? 'male' : 'female',
    variant,
    tile: positions[i],
    facing:
      12.7 - positions[i][0] - (10.4 - positions[i][1]) >= 0 ? 'NE' : 'NW',
    action: 'sit',
  }));
  const steps = [
    { from: 0, to: 84, action: 'talk' },
    { from: 84, to: 108, action: 'idle' },
    { from: 108, to: 192, action: 'talk' },
    { from: 192, to: 216, action: 'idle' },
    { from: 216, to: 240, action: 'talk' },
  ].map((s) => ({ ...s, at: speakerTile, facing: 'SW' }));
  const cameras = [
    { id: 'menk-recording-camera-left', tile: [11, 12.5] },
    { id: 'menk-recording-camera-right', tile: [14.1, 12.6] },
  ];
  const frame = (n) => ((Math.floor(n) % 240) + 240) % 240;
  function state(n) {
    const f = frame(n),
      step = steps.find((s) => f >= s.from && f < s.to);
    return {
      frame: f,
      speaker: {
        tile: speakerTile,
        action: step.action,
        facing: 'SW',
        pose: Math.floor(f / (step.action === 'idle' ? 6 : 3)) % 4,
      },
      audience: audience.map((a) => ({ ...a, pose: Math.floor(f / 6) % 2 })),
      cameras: cameras.map((c) => ({
        ...c,
        pose: Math.floor(f / 30) % 4,
        aim: speakerTile,
        recording: true,
      })),
      lectern: { tile: [12.9, 10.95] },
    };
  }
  globalThis.MenkSpeechScene = Object.freeze({
    fps: 12,
    loop: 240,
    speakerTile,
    audience,
    steps,
    cameras,
    frame,
    state,
  });
})();
