AL-BAYT AL-MUZLIM · THE COMPLETE LOCATION
Pixel Atelier — a spacious experimental chamber and walkable courtyard
======================================================================

START HERE

1. Extract the entire ZIP into a folder.
2. With Python 3 installed, open a terminal in that folder.
3. Run: python3 serve.py
   On Windows, use: py serve.py
4. Open http://127.0.0.1:8000/ in a modern browser.
5. Stop the server with Ctrl+C when finished.

The server listens only on 127.0.0.1 on this computer. If port 8000 is
already in use, stop the other local server before starting this one.
JavaScript modules can be blocked when index.html is opened directly as
a file, so use the local server. No installation or network service is
needed by the viewer itself. The Book, Scholar and Workshop navigation
links open separate published exhibits and require internet access.

WHAT IS INCLUDED

The complete interactive viewer and editable source are at the archive
root: index.html, style.css, app.js, scene.js, courtyard.js, instruments.js,
observation-instruments.js, instrument-experiments.js, renderer.js and software.js.
Textures are generated procedurally by the viewer. assets/ contains the
favicon, three self-contained glTF 2.0 binary models and the export report.
serve.py is a small standard-library local server. SOURCE-LINKS.json lists
the historical and optical sources. MANIFEST.json records file sizes and
SHA-256 checksums. PACKAGE-VALIDATION.json records the packaging checks.

The copied viewer's ZIP download links open this guide. The separate
GLB links still download the included room and instrument models.

EXPLORING THE LOCATION

The viewer starts in Room, a working-room cutaway showing the four apparatus
stations together. Anchored labels open each station's experiment controls.
Rendered previews on the station buttons help identify each collection.
Inside enters the enclosed chamber at eye level. Drag to look around.
Hold the direction buttons or use W A S D to move;
arrow keys turn the camera. Scroll, pinch or use + / - to zoom. In the
Inside and Court views this adjusts the field of view.

Inside enters the room; Court enters the courtyard. Study opens a room
cutaway, and Plan shows the room from above. Site shows the complete
setting; Site plan is available among the lower focus buttons. Inspection
views orbit when you drag. Orbit rotates automatically. Courtyard
inspects the courtyard; Pinhole looks out through the opening. Aperture,
Screen, Optical Bench, Geometry Lectern and Instrument Shelves focus on
the experiment's details.

The clear room floor grows from 9.6 x 7.44 to 14.4 x 11.16 design units:
1.5 times each dimension, or 2.25 times the previous floor area. The
bench, lectern, stool, shelves, storage and screen have distinct working
areas. Their original shapes and scale are preserved by translation.
The aperture stays fixed, and the full receiving-canvas cone is clear.

The mirror apparatus and astronomical instruments are scaled to 1.35 times
their previous size, sighting tubes to 1.45 times, and the clock to 1.18
times. Their tables and display bench keep the same working heights
while their horizontal footprints grow. The original room furniture stays
at its previous scale. These are artistic display proportions.

Four rendered instrument cards open the seven mirror forms, sighting tubes,
astronomical instruments and water clock. On desktop, experiment controls
sit beside the large model, with measurements visible on its view. On
phones, the model stays visible while you scroll through the controls.
The room and outdoor views use the full stage width. Fit instrument
restores the working close-up; Back to the room returns to the overview.

Mirrors: choose a rendered shape thumbnail, adjust Incoming beam angle, and use Focus this mirror
or Set beam to 0°. The incoming rays are parallel at every selected angle.
The coloured rays meet the selected surface and reflect using its local
normal; the readout compares the angles. The main mirror card opens the
plane mirror. See all seven together returns to the collection.

Sighting tubes: adjust Tube elevation to bring the sight line onto the fixed
target. Align with the target sets the aligned position automatically.
Try an off-target angle shows an obstructed sight line for comparison.

Astronomy: Sighting angle moves the quadrant alidade. Demonstration sun
altitude changes the gnomon's shadow using height / tan(altitude). These
are indoor teaching models; sky and Sun observations require outdoor
conditions. Low Sun · 40° and High Sun · 80° compare the shadow endpoints.

Water clock: Explore the cycle sets elapsed time from 0 to 24 in
quarter-hour steps. Run clock plays the mechanism. Speed offers 0.5, 1 or 2
hours per second. Reset cycle pauses at hour 0. The movement is accelerated
and illustrative.

The initial mirror angle is 15 degrees; Set beam to 0° restores it to 0.
The tube begins at 14 degrees, away from the target. Align with the target
sets it to 22 degrees. Initial quadrant and sun altitudes are 35 and 55
degrees. Reset room pauses playback, returns to the room overview and
restores clock hour 6 and the original optical controls.

The courtyard has complete roofed buildings with side and rear masonry,
deep door and window recesses, and an open shaded gallery. Worn paving,
a turquoise basin, palms, planting and furnishings fill the courtyard.
Its clear area is 20.9 x 13.6 design units, or 284.24 square units, about
1.77 times the room floor area. Neighbouring buildings include recessed
openings and roof-access details.
Continuous ground, streets and neighbouring buildings extend the place.
The courtyard stands beyond the pinhole wall. Its upright preview is
rendered from the same exterior geometry at the opening. The receiving
screen uses that image rotated 180 degrees.

The aperture-width slider changes the projection's brightness and
softness. Screen position moves the receiving frame. Sunlight toggles
illumination through the opening; the exterior remains in daylight.
Reveal light paths toggles teaching rays. Cutaway walls & roof opens the
experimental chamber for inspection.
These controls, the projection comparison and individual GLB downloads
are in Room lighting & projection below the viewer. The navigation above
the instrument cards also provides the ZIP link in the published viewer.

Inspection and Dark experiment change the supplementary inspection
lighting; its slider offers finer control. Micro pixels / Fine pixels
changes the rendering detail. The download icon saves the current view
as PNG. The fullscreen icon enlarges the viewer when supported.

Keyboard shortcuts: R restores the working-room overview and controls;
L toggles sunlight; C toggles the cutaway.
Shortcuts pause while editing controls or reading the source dialog.

THE THREE 3D MODELS

assets/al-bayt-al-muzlim-cutaway.glb opens the interior for inspection.
assets/al-bayt-al-muzlim-complete.glb includes the enclosing roof/walls.
Both contain the enlarged room and the original-scale furnishings;
their model metadata includes the floor dimensions and translations.
Both include the complete courtyard and its surroundings: hall, gallery
and wing walls, roofs and openings; paving, basin and planting; ground,
streets and neighbouring buildings. Named exterior object groups can
be selected separately in a 3D editor.
Both contain named object groups, indexed geometry, normals, UVs, vertex
colours, embedded PNG textures and material settings for brass, stone,
polished iron, timber, glass, water and cloth. The projection texture is
inverted 180°. Both room models include the new instrument collection.

assets/al-bayt-al-muzlim-instruments.glb contains only the new mirror,
sighting, astronomical and clock assemblies. Their positions match the
room models, and the named components can be selected in a 3D editor.

All three GLBs are static at clock hour 6. The room models use aperture
35%, screen position 50%, sunlight and pinhole light paths on. Dynamic
station labels, experiment overlays and clock playback are in the browser
viewer and included source, without being baked into the apparatus models.
Import a GLB
into software that supports
glTF 2.0; its lighting and transparency display may differ from the
viewer's supplementary lighting and material highlights. Scene units
are design units, not measured historical dimensions.

HISTORY AND ARTISTIC SCOPE

Al-bayt al-muzlim means “the dark room.” Ibn al-Haytham described experiments
in dark chambers with light admitted through small openings. In the Optics,
separate candle flames create separate light patches. His later study of
eclipses considers solar-crescent imaging. This scene is an imagined
experimental chamber, not an identified surviving private sanctuary. [1,2]

The masonry, arches, shutter, brass plate, canvas screen, bench, lectern,
shelves, vessel shapes and layout interpret the artistic brief. Glass
and geometric tools connect the scene to his optical studies. Astrolabes
provide contemporary context without claiming verified ownership. [3–5]

The seven mirror families are plane, convex spherical, concave spherical,
convex cylindrical, concave cylindrical, convex conical and concave
conical. They use shaped polished-iron surfaces. The viewer gives them
reflective highlights and ray demonstrations based on the law of reflection;
it does not simulate a reflected room image. [2]

The lensless copper sight tubes, funnel eyepiece and alidade, meridian
quadrant, and gnomon with shadow board draw on the translated meridian
treatises. The water clock follows a manuscript-based reconstruction:
an outer tank, perforated sinking cylinder, guide rings and bars, cord
and pulleys drive a rotating disc with 24 divisions past a fixed pointer.
Forms are researched; dimensions, mounts and placement are artistic.
The clock positions and playback illustrate the mechanism without calculating
water flow or calibrated timekeeping. [7,8]

The courtyard is a modern explanatory reconstruction based on the
illustrated location, not a claimed historical site. Its camera position
follows the pinhole; field of view and framing are selected to make the
scene legible, rather than calibrated to the physical screen dimensions.
A larger aperture
admits more light but softens an image. The controls illustrate brightness,
softness and inversion qualitatively; they do not calculate calibrated
optics, lens aberrations or small-aperture diffraction. Visible rays are
a teaching overlay; actual shafts need scattering particles such as dust.
Inspection light makes the artwork easier to explore. [2,6]

VALIDATION

assets/export-validation.json records the exporter checks: finite vertex
attributes, unit normals, valid indices/buffer ranges, embedded image
decoding, hashes, correct texture inversion and placement of the courtyard
architecture outside the pinhole wall. It measures the main buildings'
wall volumes and roof thickness, checks faces in all six axis directions,
and verifies the named ground and street context. Openings are intentional;
these are spatial-depth checks, not a watertight-mesh claim.
The courtyard rectangle is measured against paving coverage and room area.
Neighbouring houses have checked wall/roof volumes and measurable opening
recesses. The roof-access stair has physical treads reaching its terrace.
Room checks measure the 1.5 x 1.5 floor expansion, sample the actual floor
mesh, verify disjoint major furniture footprints and test the full canvas
cone for obstructions. Geometry hashes compare twelve furnishing and
fixture groups with the previous source after subtracting translations.
The near, middle and far screen positions are checked for clearance.
Instrument checks verify all seven surface families and their concavity,
open sighting bores, astronomical components and water-clock apparatus.
The 24 dial marks, fixed pointer and cylinder/disc movement are checked
at hours 0, 6, 12 and 24. Instrument stations are checked against actual
mesh bounds, room collision boxes, existing furniture and the optical cone.
Proportion checks compare enlarged apertures, bores, lengths, quadrant and
clock radii, gnomon height and cylinder travel against the previous apparatus.
Station scale transforms cover all groups while working-table heights stay
fixed. Clock and shadow checks use their scaled dimensions.
Interactive experiment checks cover reflected-ray hits on all seven mirror
surfaces and the law of reflection, aligned and obstructed tube positions,
quadrant angles, and the gnomon's calculated and drawn shadow. Moving tube
and alidade shapes retain their scale. Dynamic station overlays are kept
out of the static apparatus models.
PACKAGE-VALIDATION.json records local links, safe paths, model hashes and
source consistency.
MANIFEST.json hashes every packaged file other than the manifest itself.
The archive builder also checks ZIP integrity, every recorded checksum,
absence of recursive archives, and the limit of 30,000,000 bytes.

BROWSER PREVIEWS

The following images show views captured from the interactive location:
assets/working-room-stations.jpg
assets/mirror-reflection-demo.jpg
assets/precision-mirrors.jpg
assets/water-clock.jpg
assets/spacious-room-interior.jpg
assets/spacious-room-plan.jpg
assets/courtyard-ground-level.jpg
assets/location-architecture.jpg

SOURCE LINKS

[1] A. I. Sabra — Ibn al-Haytham, Abu — Dictionary of Scientific Biography
https://www.encyclopedia.com/science/dictionaries-thesauruses-pictures-and-press-releases/ibn-al-haytham-abu
Dark-chamber experiments; distinction between the Optics and later eclipse imaging.

[2] A. Mark Smith — Optics to the Time of Kepler
https://ethos.lps.library.cmu.edu/article/id/711/
Historical optical experiments, seven polished-iron mirror forms and visibility of light through scattering.

[3] Roshdi Rashed — Ibn al-Haytham's scientific research programme
https://link.springer.com/chapter/10.1007/978-3-319-31903-2_2
Glass spheres, refraction and geometrical investigations.

[4] Ordered Universe — Ibn al-Haytham geometric vision board
https://ordered-universe.com/ibn-al-haytham/ibn-al-haytham-raytracing-experiment-home/ibn-al-haytham-raytracing-experitment-board/
A reconstruction of the marked board and pegs in Optics Book III.

[5] National Museums Scotland — A 1,000-year-old star catcher
https://www.nms.ac.uk/discover-catalogue/a-1000-year-old-star-catcher
An 11th-century astrolabe as period context; not evidence of personal ownership.

[6] Institute of Physics — From pinhole camera to lens camera
https://spark.iop.org/pinhole-camera-lens-camera
Qualitative aperture-size and image-definition relationship.

[7] Jan P. Hogendijk — Two Treatises by Ibn al-Haytham on the Determination of the Meridian Line, Translated from the Edition by Fuat Sezgin
https://dspace.library.uu.nl/bitstream/handle/1874/426069/IH_meridian.pdf?isAllowed=y&sequence=1
Translated primary text: copper sighting tube, funnel eyepiece, alidade, meridian quadrant, gnomon and shadow observations.

[8] Salim Al-Hassani — The Mechanical Water Clock of Ibn Al-Haytham (2013)
https://muslimheritage.com/the-mechanical-water-clock-of-ibn-al-haytham/
Manuscript-based reconstruction: water tank, sinking cylinder, guides, cord, pulleys and 24-division rotating disc.
