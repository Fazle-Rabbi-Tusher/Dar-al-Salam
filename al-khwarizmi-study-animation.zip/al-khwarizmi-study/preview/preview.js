const model = globalThis.KhwarizmiStudy,
  canvas = document.querySelector('#scene'),
  ctx = canvas.getContext('2d');
const images = new Map();
const names = [];
for (const action of ['read', 'write', 'teach', 'walk', 'idle'])
  for (const view of ['SE', 'NE'])
    names.push(
      `../repo-overlay/art/sprites/anim/al-khwarizmi__${action}_${view}.png`,
    );
for (const prop of model.props) names.push(`art/${prop.type}.png`);
const zoom = 3.3,
  origin = [350, 470];
let clock = 0,
  playing = true,
  lastTime,
  view = 'auto';
function project(tile) {
  return [
    origin[0] + (tile[0] - tile[1] - (18 - 44.5)) * 16 * zoom,
    origin[1] + (tile[0] + tile[1] - (18 + 44.5)) * 8 * zoom,
  ];
}
function polygon(points, fill, stroke) {
  ctx.beginPath();
  points.forEach((p, i) => (i ? ctx.lineTo(...p) : ctx.moveTo(...p)));
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}
function backdrop() {
  ctx.fillStyle = '#171c24';
  ctx.fillRect(0, 0, 1100, 720);
  polygon(
    [
      [14, 41],
      [26, 41],
      [26, 49],
      [14, 49],
    ].map(project),
    '#a48259',
    '#d4ba87',
  );
  for (let x = 14; x <= 26; x++) {
    const a = project([x, 41]),
      b = project([x, 49]);
    ctx.strokeStyle = '#886a48';
    ctx.beginPath();
    ctx.moveTo(...a);
    ctx.lineTo(...b);
    ctx.stroke();
  }
  for (let y = 41; y <= 49; y++) {
    const a = project([14, y]),
      b = project([26, y]);
    ctx.beginPath();
    ctx.moveTo(...a);
    ctx.lineTo(...b);
    ctx.stroke();
  }
  const a = project([14, 41]),
    b = project([26, 41]);
  polygon([a, b, [b[0], b[1] - 100], [a[0], a[1] - 100]], '#39423e', '#60634e');
}
function prop(p) {
  const image = images.get(`art/${p.type}.png`),
    [x, y] = project(p.tile);
  ctx.drawImage(
    image,
    Math.round(x - (p.width / 2) * zoom),
    Math.round(y - (p.height - 4) * zoom),
    p.width * zoom,
    p.height * zoom,
  );
}
function person(s) {
  const face = view === 'auto' ? s.view : view,
    image = images.get(
      `../repo-overlay/art/sprites/anim/al-khwarizmi__${s.action}_${face}.png`,
    );
  const flip = view === 'auto' ? s.flip : false;
  const [x, y] = project(s.tile);
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));
  if (flip) ctx.scale(-1, 1);
  ctx.drawImage(
    image,
    s.pose * 224,
    0,
    224,
    336,
    -28 * zoom,
    -80 * zoom,
    56 * zoom,
    84 * zoom,
  );
  ctx.restore();
}
function render(value = clock) {
  clock = ((value % 240) + 240) % 240;
  const s = model.state(clock);
  ctx.imageSmoothingEnabled = false;
  backdrop();
  const queue = model.props.map((p) => ({ tile: p.tile, draw: () => prop(p) }));
  queue.push({ tile: s.tile, draw: () => person(s) });
  queue.sort((a, b) => a.tile[0] + a.tile[1] - b.tile[0] - b.tile[1]);
  queue.forEach((o) => o.draw());
  ctx.fillStyle = '#dfc18b';
  ctx.font = '14px monospace';
  ctx.fillText(
    'DRAFT · READING / WRITING / DIAGRAMS / THINKING / WALKING',
    26,
    680,
  );
  document.querySelector('#scrub').value = Math.floor(clock);
  document.querySelector('#status').textContent =
    `${{ read: 'Reading / page turn', write: 'Writing notes', teach: 'Studying geometry', idle: 'Thinking', walk: 'Walking' }[s.action]} · ${(clock / 12).toFixed(1)} s`;
}
function tick(t) {
  if (lastTime !== undefined && playing) {
    clock = (clock + (Math.min(1000, t - lastTime) * 12) / 1000) % 240;
    render();
  }
  lastTime = t;
  requestAnimationFrame(tick);
}
document.querySelector('#play').onclick = () => {
  playing = !playing;
  document.querySelector('#play').textContent = playing ? 'Pause' : 'Play';
};
document.querySelector('#scrub').oninput = (e) => {
  playing = false;
  document.querySelector('#play').textContent = 'Play';
  render(Number(e.target.value));
};
document.querySelector('#view').onchange = (e) => {
  view = e.target.value;
  render();
};
globalThis.studyPreview = {
  setFrame(f) {
    playing = false;
    document.querySelector('#play').textContent = 'Play';
    render(f);
  },
  get frame() {
    return clock;
  },
  get playing() {
    return playing;
  },
};
globalThis.studyReady = Promise.all(
  names.map(
    (name) =>
      new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
          images.set(name, img);
          resolve();
        };
        img.onerror = () => reject(Error('Missing ' + name));
        img.src = name;
      }),
  ),
).then(() => {
  render(0);
  requestAnimationFrame(tick);
});
