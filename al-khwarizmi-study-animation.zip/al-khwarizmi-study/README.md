# Al-Khwarizmi — animated study routine

A draft character in the owner's uploaded Isometric Character Sprites style:
cream turban, gray beard, brown scholar robe and restrained gold trim. The source
turnaround shows eight views, also exported individually in `turnaround/`. The game uses front/rear strips and mirrored views
on its rotatable planet. All artwork is 2D pixel art shaded for solid 3D volume.

## Watch

- `preview/study-routine.mp4`: 20-second routine at 24 rendered frames per second.
- `preview/study-routine.gif`: lightweight animated preview.
- `preview/reading.png`, `writing.png`, `geometry.png`, `walking.png`: scene stills.
- `preview/native-world.png`: actual repository renderer integration capture.
- Interactive: from this folder run `python3 -m http.server 8000`, then visit
  `http://localhost:8000/preview/`. Play/pause, scrub and choose front/rear views.

## Actions and movement

The deterministic simulation retains the original 12 Hz / 240-tick master loop:
0-48 reading/page turn; 48-96 writing; 96-120 walking to the diagram;
120-168 diagram study/teaching; 168-216 thinking; 216-240 walking back.
Reading, writing and teaching each have eight drawn poses per view. Walking has
six and idle has four: 68 supplied poses across ten transparent PNG strips.

Strips are 224x336 pixels per frame, density four, registered to the same foot
anchor (112,320). Each row uses one scale; a shoe-based horizontal anchor avoids
hand/book movements causing body sliding. Walking uses smoothstep acceleration
and braking, with optional render-time position interpolation between simulation
ticks. Pause freezes elapsed time and the interpolated foot position. No random
or wall-clock calls are used in the scene model. Book pages, quill movements,
hand gestures and blinks are drawn poses, rather than procedural body stretching.

`integration/runtime.patch` preserves every supplied frame instead of dropping
an eight-frame strip down to the four fallback poses. It also adds optional
path easing and opt-in `smoothMotion`; legacy actors keep their current behavior.
Character culling bounds account for the supplied pose envelope.

## Install in Dar-al-Salam

Copy this folder to `scene-packs/al-khwarizmi-study` in the repository. With the
normal Node 24 / pnpm project dependencies installed, run from repository root:

    node scene-packs/al-khwarizmi-study/install.mjs .
    pnpm build:preview
    node --import tsx scene-packs/al-khwarizmi-study/verify.mjs .
    pnpm test
    pnpm dev

The installer applies the runtime patch once, copies the prepared art and updates
only this character's loop/script/look and the local study props. It replaces
his workstation's computer desk with a wooden writing desk and adds a geometry
stand and armillary display. The walking start is half a tile clear of the old
desk collider; the route avoids the room's blocked tiles. His identity, alias,
dates, quick facts, biography placeholders, sources, links and `panelApproved:
false` remain unchanged. Existing religious/content approval rules still apply.

Original card, strips and fallback head files are in `original-animation/`.
The fallback head is regenerated only for this character to support his new
scripted actions; other character artwork is preserved. Source sheets and a
matching illustration are included. Existing unrelated local changes are not
part of this bundle.

## Asset folders

- `source-sheets/`: original generated opaque magenta-background sheets.
- `repo-overlay/art/`: prepared transparent sprites, palette-compatible native
  objects, illustration and action-complete fallback head files.
- `preview/art/`: detailed 4x display props matching character density. Native
  objects follow the repository's existing object resolution and world palette.
- `scene.js`: shared pure scene state used by the interactive preview.
- `prepare-assets.mjs`: optional source reimport, matte removal, registration and
  native palette conversion. Normal installation needs no image-generation call.
- `integration/`: runtime patch and native object metadata.
- `verify.mjs`: native state, collision, repeatability, identity, anchor and frame
  preservation checks against the built manifest.

The eight prop views include an antique writing desk/reverse view, geometry
stand, armillary, bookcase, stool, reading stand and scroll bundle. Preview
bookcase and extra props are available for dressing; the native installer makes
only the workstation changes described above. No new historical assertions or
attributed speech are added to the draft card.

`style-reference/al-khwarizmi.png` is an unmodified copy from the owner's
uploaded sprite pack. It defines the rendering style and proportions; the brown
robe and cream turban follow the newer supplied action references.
