import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import './scene.js';
const source = path.dirname(fileURLToPath(import.meta.url)),
  target = path.resolve(process.argv[2] ?? '.');
const read = async (p) =>
  JSON.parse(await fs.readFile(path.join(target, p), 'utf8'));
const write = async (p, v) => {
  await fs.mkdir(path.dirname(path.join(target, p)), { recursive: true });
  await fs.writeFile(path.join(target, p), JSON.stringify(v, null, 2) + '\n');
};
// Apply the supplied-frame/eased-path runtime support once, preserving other work.
const patch = path.join(source, 'integration/runtime.patch');
try {
  await fs.access(patch);
  const check = spawnSync('git', ['apply', '--check', patch], { cwd: target });
  if (check.status === 0) {
    const apply = spawnSync('git', ['apply', patch], {
      cwd: target,
      encoding: 'utf8',
    });
    if (apply.status !== 0) throw Error(apply.stderr);
  } else {
    const reverse = spawnSync('git', ['apply', '--reverse', '--check', patch], {
      cwd: target,
    });
    if (reverse.status !== 0)
      throw Error(
        'Runtime patch differs from this repository; review integration/runtime.patch before installing.',
      );
  }
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
const card = await read('content/characters/al-khwarizmi.json');
card.loop = 240;
card.smoothMotion = true;
card.script = globalThis.KhwarizmiStudy.steps;
card.look.colours = {
  ...card.look.colours,
  hair: 'hair-grey',
  garmentPrimary: 'cocoa',
  garmentSecondary: 'brass',
};
await fs.cp(path.join(source, 'repo-overlay/art'), path.join(target, 'art'), {
  recursive: true,
});
await write('content/characters/al-khwarizmi.json', card);
try {
  await fs.cp(
    path.join(source, 'repo-overlay/packages'),
    path.join(target, 'packages'),
    { recursive: true },
  );
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
const objectIndex = await read('art/objects/index.json');
Object.assign(
  objectIndex,
  JSON.parse(
    await fs.readFile(path.join(source, 'integration/objects.json'), 'utf8'),
  ),
);
await write('art/objects/index.json', objectIndex);
const room = await read('rooms/mosque-garden.tmj'),
  layer = room.layers.find((l) => l.type === 'objectgroup');
const desk = layer.objects.find(
  (o) =>
    o.type === 'khwarizmi-desk' ||
    (o.type === 'm-computer-desk' && o.x === 17 && o.y === 45.5),
);
if (!desk)
  throw Error(
    'Cannot locate Al-Khwarizmi workstation; no room replacement was written.',
  );
desk.type = 'khwarizmi-desk';
const types = new Set(['khwarizmi-geometry', 'khwarizmi-armillary']);
const old = layer.objects.filter((o) => types.has(o.type));
layer.objects = layer.objects.filter((o) => !types.has(o.type));
let id = Math.max(...layer.objects.map((o) => o.id)) + 1;
for (const [i, p] of [
  { type: 'khwarizmi-geometry', tile: [23, 44] },
  { type: 'khwarizmi-armillary', tile: [24, 45.5] },
].entries())
  layer.objects.push({
    id: old[i]?.id ?? id++,
    type: p.type,
    x: p.tile[0],
    y: p.tile[1],
    footprint: [1, 1],
    walkable: false,
    z: 0,
  });
await write('rooms/mosque-garden.tmj', room);
console.log(
  'Installed Al-Khwarizmi: reading, writing, diagram study, thinking and eased walks; card review status preserved.',
);
