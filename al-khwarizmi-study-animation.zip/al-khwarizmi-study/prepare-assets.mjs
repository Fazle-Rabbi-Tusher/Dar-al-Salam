import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const sources = {
  turnaround: 'exec-38001f42-ee40-43d2-bf9a-225daf4824b2.png',
  read: 'exec-e44cadeb-e540-4f25-9a78-1424daecff30.png',
  work: 'exec-e4831bdc-7ab8-4840-85ad-2b7235025923.png',
  movement: 'exec-98484785-b953-4037-8393-bd48b7977a67.png',
  props: 'exec-b569df24-07fa-4872-81e6-4d59766d9e65.png',
};
const overlay = path.join(root, 'repo-overlay');
for (const p of [
  'source-sheets',
  'original-animation',
  'preview/art',
  'repo-overlay/art/sprites/anim',
  'repo-overlay/art/objects',
  'repo-overlay/art/illustrations',
  'integration',
])
  await fs.mkdir(path.join(root, p), { recursive: true });
for (const [name, file] of Object.entries(sources)) {
  const p = path.join(root, 'source-sheets', name + '.png');
  try {
    await fs.access(p);
  } catch {
    await fs.copyFile('/workspace/generated_images/' + file, p);
  }
}
const blank = (w, h) =>
  sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  });
async function cells(name, cols, rows) {
  const { data, info } = await sharp(
    path.join(root, 'source-sheets', name + '.png'),
  )
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  for (let i = 0; i < data.length; i += 4)
    if (
      data[i] > 150 &&
      data[i + 2] > 120 &&
      data[i + 1] < 140 &&
      data[i] > data[i + 1] * 1.3 &&
      data[i + 2] > data[i + 1] * 1.3
    )
      data[i + 3] = 0;
  const png = await sharp(data, {
    raw: { width: info.width, height: info.height, channels: 4 },
  })
    .png()
    .toBuffer();
  const result = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const left = Math.round((c * info.width) / cols),
        top = Math.round((r * info.height) / rows),
        right = Math.round(((c + 1) * info.width) / cols),
        bottom = Math.round(((r + 1) * info.height) / rows);
      const crop = await sharp(png)
        .extract({ left, top, width: right - left, height: bottom - top })
        .png()
        .toBuffer();
      result.push(await sharp(crop).trim({ threshold: 8 }).png().toBuffer());
    }
  return result;
}
async function normalized(buffer, w, h, anchor, maxW, maxH, scale, footAxis) {
  const m = await sharp(buffer).metadata();
  const ratio = scale ?? Math.min(maxW / m.width, maxH / m.height);
  const width = Math.round(m.width * ratio),
    height = Math.round(m.height * ratio);
  const resized = await sharp(buffer)
    .resize(width, height, { kernel: 'nearest' })
    .png()
    .toBuffer();
  const png = await blank(w, h)
    .composite([
      {
        input: resized,
        left: Math.round(
          anchor[0] - (footAxis === undefined ? width / 2 : footAxis * ratio),
        ),
        top: anchor[1] - height,
      },
    ])
    .png()
    .toBuffer();
  const raw = await sharp(png).ensureAlpha().raw().toBuffer();
  for (let i = 3; i < raw.length; i += 4) raw[i] = raw[i] >= 64 ? 255 : 0;
  return sharp(raw, { raw: { width: w, height: h, channels: 4 } })
    .png()
    .toBuffer();
}
const read = await cells('read', 8, 2),
  work = await cells('work', 8, 4),
  movement = await cells('movement', 6, 4),
  props = await cells('props', 4, 2);
const metadata = {};
async function strip(action, view, frames, flip = false) {
  const buffers = await Promise.all(
    frames.map((b) => (flip ? sharp(b).flop().png().toBuffer() : b)),
  );
  const sizes = await Promise.all(buffers.map((b) => sharp(b).metadata()));
  const axes = await Promise.all(
    buffers.map(async (buffer, i) => {
      const { data, info } = await sharp(buffer)
        .ensureAlpha()
        .raw()
        .toBuffer({ resolveWithObject: true });
      let left = info.width,
        right = -1;
      for (let y = Math.floor(info.height * 0.95); y < info.height; y++)
        for (let x = 0; x < info.width; x++)
          if (data[(y * info.width + x) * 4 + 3] > 64) {
            left = Math.min(left, x);
            right = Math.max(right, x);
          }
      return right >= left ? (left + right) / 2 : sizes[i].width / 2;
    }),
  );
  const scale = Math.min(
    252 / Math.max(...sizes.map((m) => m.height)),
    109 / Math.max(...axes),
    109 / Math.max(...sizes.map((m, i) => m.width - axes[i])),
  );
  const prepared = await Promise.all(
    buffers.map((b, i) =>
      normalized(b, 224, 336, [112, 320], 218, 252, scale, axes[i]),
    ),
  );
  const name = `al-khwarizmi__${action}_${view}.png`;
  await blank(224 * frames.length, 336)
    .composite(prepared.map((input, i) => ({ input, left: i * 224, top: 0 })))
    .png()
    .toFile(path.join(overlay, 'art/sprites/anim', name));
  metadata[name] = {
    frameWidth: 224,
    frameHeight: 336,
    frames: frames.length,
    anchor: [112, 320],
    density: 4,
  };
  return prepared;
}
await strip('read', 'SE', read.slice(0, 8));
await strip('read', 'NE', read.slice(8, 16));
await strip('write', 'SE', work.slice(0, 8), true);
await strip('write', 'NE', work.slice(8, 16));
await strip('teach', 'SE', work.slice(16, 24), true);
await strip('teach', 'NE', work.slice(24, 32));
await strip('walk', 'SE', movement.slice(0, 6), true);
await strip('walk', 'NE', movement.slice(6, 12));
const idle = await strip('idle', 'SE', movement.slice(12, 16), true),
  back = await strip('idle', 'NE', movement.slice(18, 22));
await fs.writeFile(path.join(overlay, 'art/sprites/al-khwarizmi.png'), idle[0]);
await fs.writeFile(
  path.join(overlay, 'art/sprites/al-khwarizmi-back.png'),
  back[0],
);
await sharp(idle[0])
  .resize(672, 1008, { kernel: 'nearest' })
  .png()
  .toFile(path.join(overlay, 'art/illustrations/al-khwarizmi.png'));
const specs = [
  ['desk', 80, 56],
  ['desk-back', 80, 56],
  ['geometry', 64, 88],
  ['armillary', 48, 80],
  ['bookcase', 80, 104],
  ['stool', 32, 40],
  ['reading-stand', 48, 48],
  ['scrolls', 40, 32],
];
const objectIndex = {};
const palette = JSON.parse(
  await fs.readFile('content/palettes/world-palette.json', 'utf8'),
).map((s) => [
  parseInt(s.slice(1, 3), 16),
  parseInt(s.slice(3, 5), 16),
  parseInt(s.slice(5, 7), 16),
]);
for (let i = 0; i < specs.length; i++) {
  const [name, w, h] = specs[i],
    anchor = [w / 2, h - 4];
  await fs.writeFile(
    path.join(root, 'preview/art', name + '.png'),
    await normalized(
      props[i],
      w * 4,
      h * 4,
      [anchor[0] * 4, anchor[1] * 4],
      (w - 4) * 4,
      (h - 8) * 4,
    ),
  );
  const png = await normalized(props[i], w, h, anchor, w - 4, h - 8);
  const { data, info } = await sharp(png)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  const cache = new Map();
  for (let j = 0; j < data.length; j += 4) {
    if (!data[j + 3]) continue;
    const key = (data[j] << 16) | (data[j + 1] << 8) | data[j + 2];
    let best = cache.get(key);
    if (!best) {
      let distance = Infinity;
      for (const c of palette) {
        const d =
          (data[j] - c[0]) ** 2 +
          (data[j + 1] - c[1]) ** 2 +
          (data[j + 2] - c[2]) ** 2;
        if (d < distance) {
          distance = d;
          best = c;
        }
      }
      cache.set(key, best);
    }
    for (let k = 0; k < 3; k++) data[j + k] = best[k];
  }
  const file = `objects/khwarizmi-${name}.png`;
  await sharp(data, {
    raw: { width: info.width, height: info.height, channels: 4 },
  })
    .png()
    .toFile(path.join(overlay, 'art', file));
  objectIndex['khwarizmi-' + name] = { file, width: w, height: h, anchor };
}
await fs.writeFile(
  path.join(root, 'strip-metadata.json'),
  JSON.stringify(metadata, null, 2) + '\n',
);
await fs.writeFile(
  path.join(root, 'integration/objects.json'),
  JSON.stringify(objectIndex, null, 2) + '\n',
);
console.log(
  'Prepared ten strips (68 poses), front/back stills, illustration, eight props and detailed preview art.',
);
