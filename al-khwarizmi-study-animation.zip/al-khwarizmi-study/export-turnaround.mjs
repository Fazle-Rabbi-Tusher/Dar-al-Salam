import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const file = path.join(root, 'source-sheets/turnaround.png');
const { data, info } = await sharp(file)
  .ensureAlpha()
  .raw()
  .toBuffer({ resolveWithObject: true });
for (let i = 0; i < data.length; i += 4)
  if (
    data[i] > 150 &&
    data[i + 2] > 120 &&
    data[i + 1] < 140 &&
    data[i] > data[i + 1] * 1.3 &&
    data[i + 2] > data[i + 1] * 1.3
  )
    data[i + 3] = 0;
const png = await sharp(data, {
  raw: { width: info.width, height: info.height, channels: 4 },
})
  .png()
  .toBuffer();
const names = [
  'front',
  'front-right',
  'right',
  'back-right',
  'back',
  'back-left',
  'left',
  'front-left',
];
await fs.mkdir(path.join(root, 'turnaround'), { recursive: true });
for (let i = 0; i < 8; i++) {
  const col = i % 4,
    row = Math.floor(i / 4),
    left = Math.round((col * info.width) / 4),
    top = Math.round((row * info.height) / 2),
    right = Math.round(((col + 1) * info.width) / 4),
    bottom = Math.round(((row + 1) * info.height) / 2);
  const crop = await sharp(png)
    .extract({ left, top, width: right - left, height: bottom - top })
    .png()
    .toBuffer();
  const cut = await sharp(crop).trim({ threshold: 8 }).png().toBuffer();
  const { data: b, info: m } = await sharp(cut)
    .resize(208, 252, { fit: 'inside', kernel: 'nearest' })
    .png()
    .toBuffer({ resolveWithObject: true });
  await sharp({
    create: {
      width: 224,
      height: 336,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  })
    .composite([
      { input: b, left: Math.round(112 - m.width / 2), top: 320 - m.height },
    ])
    .png()
    .toFile(path.join(root, 'turnaround', `${i}-${names[i]}.png`));
}
console.log('Exported eight transparent turnaround reference views.');
