/* Authored integer-tick simulation; fractional input only interpolates path rendering. */
(() => {
  const A = [18, 44.5],
    B = [21, 44.5];
  const steps = [
    { from: 0, to: 48, action: 'read', at: A, facing: 'SW' },
    { from: 48, to: 96, action: 'write', at: A, facing: 'SW' },
    { from: 96, to: 120, action: 'walk', path: [A, B], easing: 'smoothstep' },
    { from: 120, to: 168, action: 'teach', at: B, facing: 'SE' },
    { from: 168, to: 216, action: 'idle', at: B, facing: 'SE' },
    { from: 216, to: 240, action: 'walk', path: [B, A], easing: 'smoothstep' },
  ];
  const props = [
    { type: 'desk', tile: [17, 45.5], width: 80, height: 56 },
    { type: 'geometry', tile: [23, 44], width: 64, height: 88 },
    { type: 'armillary', tile: [24, 45.5], width: 48, height: 80 },
    { type: 'bookcase', tile: [16.4, 42.6], width: 80, height: 104 },
  ];
  function state(value) {
    const time = ((value % 240) + 240) % 240,
      frame = Math.floor(time),
      step = steps.find((s) => frame >= s.from && frame < s.to);
    let tile = step.at,
      facing = step.facing;
    if (step.path) {
      const t = (time - step.from) / (step.to - step.from),
        p = t * t * (3 - 2 * t),
        [a, b] = step.path;
      tile = [a[0] + (b[0] - a[0]) * p, a[1] + (b[1] - a[1]) * p];
      const dx = b[0] - a[0] - (b[1] - a[1]),
        dy = b[0] - a[0] + b[1] - a[1];
      facing = dy >= 0 ? (dx >= 0 ? 'SE' : 'SW') : dx >= 0 ? 'NE' : 'NW';
    }
    const action = step.action,
      count = action === 'walk' ? 6 : action === 'idle' ? 4 : 8,
      tempo = action === 'walk' ? 2 : action === 'idle' ? 6 : 3;
    return {
      frame,
      time,
      action,
      tile,
      facing,
      view: ['SE', 'SW'].includes(facing) ? 'SE' : 'NE',
      flip: ['SW', 'NW'].includes(facing),
      pose: Math.floor(frame / tempo) % count,
      count,
      tempo,
      props,
    };
  }
  globalThis.KhwarizmiStudy = Object.freeze({
    fps: 12,
    loop: 240,
    steps,
    props,
    state,
  });
})();
