import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import './scene.js';
const root = path.dirname(fileURLToPath(import.meta.url)),
  repo = path.resolve(process.argv[2] ?? '.');
const { characterSchema } = await import(
  path.join(repo, 'packages/shared/schema.ts')
);
const { characterState, scriptErrors } = await import(
  path.join(repo, 'packages/shared/script.ts')
);
const { forbiddenName } = await import(
  path.join(repo, 'packages/shared/rules.ts')
);
const { loadContent } = await import(
  path.join(repo, 'tools/build/validate.ts')
);
const content = await loadContent(),
  c = content.characters.find((c) => c.id === 'al-khwarizmi');
characterSchema.parse(c);
const original = JSON.parse(
  await fs.readFile(
    path.join(root, 'original-animation/al-khwarizmi.json'),
    'utf8',
  ),
);
for (const key of Object.keys(original))
  if (!['look', 'script', 'loop'].includes(key))
    assert.deepEqual(c[key], original[key], key);
assert.equal(c.panelApproved, false);
assert.equal(c.smoothMotion, true);
assert.deepEqual(scriptErrors(c, content.room), []);
for (const name of [c.id, ...Object.values(c.name), ...c.aliases])
  assert.equal(forbiddenName(name, content.rules), false, name);
for (let f = 0; f < 240; f += 0.25) {
  const a = characterState(c, f),
    b = globalThis.KhwarizmiStudy.state(f);
  assert.equal(a.action, b.action);
  assert.equal(a.facing, b.facing);
  for (let i = 0; i < 2; i++)
    assert.ok(Math.abs(a.tile[i] - b.tile[i]) < 1e-10);
  assert.deepEqual(characterState(c, f), characterState(c, f + 240));
}
const meta = JSON.parse(
  await fs.readFile(path.join(root, 'strip-metadata.json'), 'utf8'),
);
for (const [name, m] of Object.entries(meta)) {
  const { data, info } = await sharp(
    path.join(root, 'repo-overlay/art/sprites/anim', name),
  )
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  assert.equal(info.width, 224 * m.frames);
  assert.equal(info.height, 336);
  for (let f = 0; f < m.frames; f++) {
    let left = 224,
      right = -1,
      bottom = 0;
    for (let y = 308; y < 336; y++)
      for (let x = 0; x < 224; x++)
        if (data[(y * info.width + f * 224 + x) * 4 + 3] > 64) {
          left = Math.min(left, x);
          right = Math.max(right, x);
          bottom = Math.max(bottom, y);
        }
    assert.equal(bottom, 319, name);
    assert.ok(
      Math.abs((left + right) / 2 - 112) < 5,
      name + ' horizontal foot anchor',
    );
  }
}
const manifest = JSON.parse(
  await fs.readFile(path.join(repo, 'web/public/world/world.json'), 'utf8'),
);
const baked = manifest.characters.find((c) => c.id === 'al-khwarizmi');
for (const action of ['read', 'write', 'teach'])
  for (const view of ['SE', 'SW', 'NE', 'NW'])
    assert.equal(baked.frames[`${action}_${view}`].length, 8);
assert.equal(baked.frames.walk_SE.length, 6);
assert.equal(baked.smoothMotion, true);
console.log(
  'Verified: draft identity preserved; native/preview states match at 960 subframes; collision-free eased paths; 68 anchored poses; 8-frame sequences retained in actual manifest.',
);
