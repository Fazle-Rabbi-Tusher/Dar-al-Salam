import * as THREE from './vendor/three.module.min.js';
import {
  FPS,
  ADULT_HEAD_SCALE,
  TORSO_LENGTH,
  DURATION,
  MEN,
  WOMEN,
  IMAM,
  CHILDREN,
  stateAtTick,
  childState,
  cameraAtTick,
  caption,
} from './timeline.mjs';
const canvas = document.querySelector('#scene');
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: false,
  alpha: true,
  preserveDrawingBuffer: true,
});
renderer.setPixelRatio(1);
renderer.setSize(960, 540, false);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#1b282b');
scene.fog = new THREE.FogExp2('#c7a573', 0.014);
const camera = new THREE.OrthographicCamera(-14, 14, 8, -8, 0.1, 90);
const v = (a) => new THREE.Vector3(...a),
  up = new THREE.Vector3(0, 1, 0),
  identity = new THREE.Quaternion();
const boxGeometry = new THREE.BoxGeometry(1, 1, 1),
  dummy = new THREE.Object3D(),
  colors = new Map();
const color = (s) => {
  if (!colors.has(s)) colors.set(s, new THREE.Color(s));
  return colors.get(s);
};
const standard = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.88,
  metalness: 0.04,
});
class Batch {
  constructor(capacity, material = standard) {
    this.mesh = new THREE.InstancedMesh(boxGeometry, material, capacity);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.mesh.frustumCulled = false;
    this.used = 0;
    scene.add(this.mesh);
  }
  add(position, size, tint, q = identity) {
    dummy.position.copy(v(position));
    dummy.scale.set(...size);
    dummy.quaternion.copy(q);
    dummy.updateMatrix();
    const i = this.used++;
    this.mesh.setMatrixAt(i, dummy.matrix);
    this.mesh.setColorAt(i, color(tint));
  }
  finish() {
    this.mesh.count = this.used;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
}
const roofFrame = new Batch(30);
const architecture = new Batch(14000),
  glow = new Batch(
    100,
    new THREE.MeshStandardMaterial({
      color: 0xffd194,
      emissive: 0xffa83b,
      emissiveIntensity: 2.4,
      roughness: 0.5,
    }),
  );
function block(p, s, c, q) {
  // The Qibla wall is cut away for the owner-requested front-facing camera.
  if (p[2] < -6.8 && p[1] > 0.4) return;
  architecture.add(p, s, c, q);
}
function beam(a, b, width, depth, c) {
  const A = v(a),
    B = v(b),
    d = B.clone().sub(A),
    q = new THREE.Quaternion().setFromUnitVectors(up, d.clone().normalize());
  block(
    A.add(B).multiplyScalar(0.5).toArray(),
    [width, d.length(), depth],
    c,
    q,
  );
}
const hash = (i) => {
  const x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
};
function rug(x, z, width, length, imam = false) {
  const green = imam ? '#24534c' : '#2c504c',
    gold = '#bd9859';
  block([x, 0.01, z], [width, 0.02, length], green);
  for (const side of [-1, 1]) {
    block(
      [x + side * (width / 2 - 0.035), 0.022, z],
      [0.018, 0.006, length - 0.06],
      gold,
    );
    block(
      [x, 0.022, z + side * (length / 2 - 0.04)],
      [width - 0.04, 0.006, 0.02],
      gold,
    );
  }
  for (let j = 0; j < 4; j++) {
    const zz = z - length / 2 + 0.16 + (j * (length - 0.32)) / 3;
    for (const side of [-1, 1])
      block(
        [x + side * (width * 0.32), 0.025, zz],
        [0.045, 0.006, 0.045],
        gold,
        new THREE.Quaternion().setFromAxisAngle(up, Math.PI / 4),
      );
  }
}
// Cutaway architecture keeps the camera side open while retaining a monumental prayer hall.
block([0, -0.065, 1.2], [12.4, 0.12, 17.6], '#bda77d');
for (let x = -6; x <= 6; x += 0.5)
  for (let z = -7; z <= 9.5; z += 0.5) {
    const c = ['#cab88e', '#c3af85', '#d2bf98'][
      Math.floor(hash(x * 97 + z * 43) * 3)
    ];
    block([x, 0.003, z], [0.485, 0.01, 0.485], c);
  }
block([0, 2.65, -7.35], [12.5, 5.3, 0.36], '#d7c6a4');
block([-6.22, 2.5, 1.2], [0.25, 5.0, 17.3], '#cfbc98');
block([6.22, 2.5, 1.2], [0.25, 5.0, 17.3], '#cfbc98');
block([0, 2.65, 9.85], [12.5, 5.3, 0.25], '#d7c6a4');
for (const x of [-3.7, 0, 3.7]) {
  block([x, 3.35, 9.69], [1.5, 2.2, 0.035], '#78998e');
  for (let k = -0.6; k <= 0.6; k += 0.3)
    block([x + k, 3.35, 9.65], [0.035, 2.2, 0.04], '#b89c65');
  for (let h = 2.35; h < 4.5; h += 0.3)
    block([x, h, 9.64], [1.5, 0.035, 0.04], '#b89c65');
}
for (const z of [-5.3, -1, 3.3, 7.7]) {
  for (const x of [-5.8, 5.8]) {
    block([x, 2.25, z], [0.34, 4.5, 0.34], '#ddcfae');
    block([x, 0.18, z], [0.62, 0.36, 0.62], '#c0a780');
    block([x, 4.45, z], [0.62, 0.18, 0.62], '#d7c3a0');
    for (let h = 0.4; h < 4.3; h += 0.25)
      block([x, h, z], [0.355, 0.018, 0.355], '#cbb794');
  }
  // Left wall window, translucent teal glazing and geometric muntins.
  block([-6.045, 2.7, z + 1.25], [0.018, 2.5, 1.65], '#668c88');
  for (let a = -0.65; a <= 0.65; a += 0.26)
    block([-6.025, 2.7, z + 1.25 + a], [0.025, 2.4, 0.035], '#ad925b');
  for (let yy = 1.6; yy < 3.9; yy += 0.32)
    block([-6.02, yy, z + 1.25], [0.028, 0.035, 1.65], '#ad925b');
}
// A continuous teal carpet unifies the individual row rugs.
block([0, 0.01, 1.1], [10.1, 0.006, 15.8], '#31534f');
for (const x of [-5.0, 5.0])
  block([x, 0.015, 1.1], [0.025, 0.003, 15.6], '#b89859');
for (const z of [-6.7, 8.9])
  block([0, 0.015, z], [10.0, 0.003, 0.025], '#b89859');
for (const z of [-5.3, -1, 3.3, 7.7])
  for (let i = 0; i <= 16; i++) {
    const angle = (i / 16) * Math.PI;
    block(
      [-6.0, 3.65 + 0.95 * Math.sin(angle), z + 1.25 + 0.9 * Math.cos(angle)],
      [0.08, 0.15, 0.17],
      '#e0c99d',
    );
  }
for (const cx of [-3.7, 3.7])
  for (let row = 0; row < 3; row++)
    for (let col = 0; col < 3; col++) {
      const x = cx + (col - 1) * 0.36,
        y = 1.7 + row * 0.42;
      beam([x - 0.14, y, -7.13], [x, y + 0.18, -7.13], 0.025, 0.025, '#a98a53');
      beam([x, y + 0.18, -7.13], [x + 0.14, y, -7.13], 0.025, 0.025, '#a98a53');
      beam([x + 0.14, y, -7.13], [x, y - 0.18, -7.13], 0.025, 0.025, '#a98a53');
      beam([x, y - 0.18, -7.13], [x - 0.14, y, -7.13], 0.025, 0.025, '#a98a53');
    }
// Plain pointed mihrab, with no generated lettering or symbols.
const nicheShape = new THREE.Shape();
nicheShape.moveTo(-1.25, 0);
nicheShape.lineTo(1.25, 0);
nicheShape.lineTo(1.25, 2.5);
nicheShape.quadraticCurveTo(1.1, 3.05, 0, 3.8);
nicheShape.quadraticCurveTo(-1.1, 3.05, -1.25, 2.5);
nicheShape.closePath();
const niche = new THREE.Mesh(
  new THREE.ShapeGeometry(nicheShape),
  new THREE.MeshStandardMaterial({
    color: '#c19a61',
    emissive: '#8f632f',
    emissiveIntensity: 0.25,
    roughness: 1,
  }),
);
niche.position.set(0, 0.04, -7.155);
// The plain mihrab remains on the removed Qibla wall, outside this shot.
niche.visible = false;
scene.add(niche);
for (const x of [-1.4, 1.4]) {
  block([x, 1.35, -7.02], [0.2, 2.7, 0.2], '#e5d2a4');
  block([x, 0.15, -6.93], [0.38, 0.3, 0.38], '#c3a477');
}
for (let i = 0; i < 16; i++) {
  const t = (i / 15) * Math.PI,
    x = 1.42 * Math.cos(t),
    y = 2.55 + 1.5 * Math.sin(t);
  block(
    [x, y, -7.02],
    [0.21, 0.23, 0.2],
    '#e4cea0',
    new THREE.Quaternion().setFromAxisAngle(
      new THREE.Vector3(0, 0, 1),
      t - Math.PI / 2,
    ),
  );
}
// Coffered perimeter beams; the centre roof remains cut away for visibility.
for (const x of [-6, 6])
  roofFrame.add([x, 5.15, 1.0], [0.12, 0.16, 17.0], '#77583b');
for (const z of [9]) roofFrame.add([0, 5.15, z], [12.0, 0.16, 0.12], '#77583b');
for (const x of [-4.6, 4.6])
  for (const z of [-4.5, 0.2, 5.2]) {
    block([x, 4.15, z], [0.035, 1.4, 0.035], '#725338');
    glow.add([x, 3.35, z], [0.23, 0.45, 0.23], '#ffd695');
    for (const dx of [-0.16, 0.16])
      for (const dz of [-0.16, 0.16])
        block([x + dx, 3.35, z + dz], [0.025, 0.6, 0.025], '#9d793d');
    block([x, 3.02, z], [0.42, 0.07, 0.42], '#aa8040');
    block([x, 3.67, z], [0.42, 0.07, 0.42], '#aa8040');
    const light = new THREE.PointLight('#ffc782', 9, 10, 2);
    light.position.set(x, 3.25, z);
    scene.add(light);
  }
// Original reference layout: congregation behind imam, women behind screen.
for (const x of [-4.55, -1.55, 1.55, 4.55]) {
  block([x, 1.12, 3.4], [0.13, 2.24, 0.14], '#634429');
  block([x, 2.3, 3.4], [0.2, 0.1, 0.2], '#b18b4c');
}
for (const y of [0.15, 0.38, 2.12])
  block([0, y, 3.4], [9.15, 0.1, 0.13], '#74502f');
for (let x = -4.4; x < 4.4; x += 0.22)
  block([x, 1.25, 3.4], [0.027, 1.65, 0.055], '#9a723e');
for (let x = -4.3; x < 4.3; x += 0.4)
  for (let y = 0.6; y < 1.9; y += 0.4) {
    beam(
      [x - 0.18, y - 0.18, 3.385],
      [x + 0.18, y + 0.18, 3.385],
      0.025,
      0.055,
      '#ac8246',
    );
    beam(
      [x - 0.18, y + 0.18, 3.385],
      [x + 0.18, y - 0.18, 3.385],
      0.025,
      0.055,
      '#ac8246',
    );
  }
// Rear-side carpeted pillar gives the two quiet children a real occluding object.
block([4.85, 1.75, 8.6], [0.4, 3.5, 0.4], '#d8c6a2');
block([4.85, 0.14, 8.6], [0.62, 0.28, 0.62], '#a98b5f');
for (const actor of [IMAM, ...MEN, ...WOMEN])
  rug(
    actor.x,
    actor.z - 0.32,
    actor.imam ? 1.2 : 0.7,
    actor.imam ? 2.0 : 1.75,
    actor.imam,
  );
for (const c of CHILDREN.filter((c) => ['toddler', 'girl'].includes(c.role)))
  rug(c.x, c.z - 0.16, 0.42, 0.85);
architecture.finish();
roofFrame.finish();
glow.finish();
scene.add(new THREE.HemisphereLight('#ffe4ba', '#66766e', 1.25));
const sun = new THREE.DirectionalLight('#ffe0a9', 2.7);
sun.position.set(-4, 9, -2);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -10;
sun.shadow.camera.right = 10;
sun.shadow.camera.top = 10;
sun.shadow.camera.bottom = -10;
sun.shadow.normalBias = 0.035;
sun.shadow.bias = -0.00015;
scene.add(sun);
const fill = new THREE.DirectionalLight('#9ebfc0', 0.7);
fill.position.set(6, 5, 8);
scene.add(fill);
const shaftMaterial = new THREE.ShaderMaterial({
  transparent: true,
  depthWrite: false,
  side: THREE.DoubleSide,
  blending: THREE.AdditiveBlending,
  uniforms: { tint: { value: new THREE.Color('#ffd299') } },
  vertexShader:
    'varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
  fragmentShader:
    'varying vec2 vUv; uniform vec3 tint;void main(){float edge=pow(max(0.,1.-abs(vUv.x-.5)*2.),2.);float fade=smoothstep(0.,.18,vUv.y)*(1.-smoothstep(.8,1.,vUv.y));gl_FragColor=vec4(tint,edge*fade*.035);}',
});
for (const z of [-3, 1.2, 5.4]) {
  const a = v([-5.9, 4.2, z]),
    b = v([1.0, 0.15, z + 2.5]),
    d = b.clone().sub(a);
  const beamMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(2.5, d.length()),
    shaftMaterial,
  );
  beamMesh.position.copy(a.add(b).multiplyScalar(0.5));
  beamMesh.quaternion.setFromUnitVectors(up, d.normalize());
  scene.add(beamMesh);
}
const actors = new Batch(7000);
actors.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
const loader = new THREE.TextureLoader(),
  faceNames = [
    'yasser-face',
    'man-face',
    'elder-face',
    'woman-navy-face',
    'woman-cream-face',
    'toddler-face',
    'tag-child-face',
    'bead-child-face',
    'girl-face',
  ];
const textures = await Promise.all(
  faceNames.map(async (name) => {
    const texture = await loader.loadAsync(`./assets/${name}.webp`);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.magFilter = THREE.NearestFilter;
    texture.minFilter = THREE.NearestFilter;
    texture.generateMipmaps = false;
    return texture;
  }),
);
const faceBatches = Object.fromEntries(
  faceNames.map((name, i) => {
    const mesh = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshStandardMaterial({
        map: textures[i],
        roughness: 0.96,
        metalness: 0,
      }),
      32,
    );
    mesh.frustumCulled = false;
    mesh.count = 0;
    scene.add(mesh);
    return [name, { mesh, used: 0 }];
  }),
);
function addFace(name, p, q, scale) {
  const f = faceBatches[name];
  dummy.position.copy(p);
  dummy.quaternion.copy(q);
  dummy.scale.set(0.29 * scale, 0.31 * scale, 1);
  dummy.updateMatrix();
  f.mesh.setMatrixAt(f.used++, dummy.matrix);
}
function joint(a, b, L1, L2, pole) {
  const A = v(a),
    B = v(b),
    delta = B.clone().sub(A),
    distance = Math.max(0.0001, Math.min(L1 + L2 - 0.001, delta.length())),
    dir = delta.normalize();
  const x = (L1 * L1 - L2 * L2 + distance * distance) / (2 * distance),
    h = Math.sqrt(Math.max(0, L1 * L1 - x * x));
  const bend = v(pole).addScaledVector(dir, -v(pole).dot(dir)).normalize();
  return A.addScaledVector(dir, x).addScaledVector(bend, h).toArray();
}
function actorGeometry(config, p, tick) {
  const sc = config.scale ?? 1,
    yOffset = (1 - sc) * 0.025,
    yaw = p.yaw ?? 0,
    rootQ = new THREE.Quaternion().setFromAxisAngle(up, yaw),
    offset = v([p.x ?? config.x, yOffset, p.z ?? config.z]);
  const transform = (a) =>
    v(a).multiplyScalar(sc).applyQuaternion(rootQ).add(offset);
  const cube = (a, size, c, q = identity, ground = false) => {
    const pos = transform(a);
    const rotation = rootQ.clone().multiply(q);
    if (ground) {
      const e = new THREE.Matrix4().makeRotationFromQuaternion(
        rotation,
      ).elements;
      const reach =
        ((Math.abs(e[1]) * size[0] +
          Math.abs(e[5]) * size[1] +
          Math.abs(e[9]) * size[2]) *
          sc) /
        2;
      pos.y = Math.max(pos.y, 0.026 + reach);
    }
    actors.add(
      pos.toArray(),
      size.map((n) => n * sc),
      c,
      rotation,
    );
  };
  const segment = (a, b, w, d, c, ground = false) => {
    const A = v(a),
      B = v(b),
      D = B.clone().sub(A);
    cube(
      A.add(B).multiplyScalar(0.5).toArray(),
      [w, D.length(), d],
      c,
      new THREE.Quaternion().setFromUnitVectors(up, D.normalize()),
      ground,
    );
  };
  const female = config.gender === 'female',
    child = !!config.child,
    variant = config.variant ?? 0;
  const garment = config.imam
    ? '#3b2a22'
    : female
      ? ['#28354c', '#6b545b', '#4e655c', '#6b6262'][variant % 4]
      : child
        ? config.role === 'tag'
          ? '#9caa97'
          : '#e5dfcc'
        : ['#e5dfcc', '#cfc9b8', '#3d5364', '#7b806c'][variant % 4];
  const skin = config.imam
    ? '#b87f59'
    : child
      ? '#b9825f'
      : female
        ? ['#b48161', '#d0a080', '#b48161', '#d0a080'][variant % 4]
        : variant % 2
          ? '#bb936f'
          : '#a66e4d';
  const hood = config.imam
    ? '#eee8db'
    : female
      ? config.role === 'girl'
        ? '#9c8aab'
        : variant % 2
          ? '#ddd6c6'
          : '#27344e'
      : child
        ? config.role === 'toddler'
          ? '#eee8da'
          : '#302a25'
        : '#e4dfcf';
  const hf = child ? 0.95 : ADULT_HEAD_SCALE,
    hip = p.hip,
    shoulder = p.shoulder,
    head = [...p.head];
  head[1] +=
    0.171 * (hf - ADULT_HEAD_SCALE) * Math.max(0, -Math.sin(p.headPitch));
  const axis = v(shoulder).sub(v(hip)).normalize();
  const bodyQ = new THREE.Quaternion().setFromUnitVectors(up, axis);
  const breast = axis
    .clone()
    .multiplyScalar(TORSO_LENGTH / 2)
    .add(v(hip))
    .toArray();
  for (let band = 0; band < 6; band++) {
    const t = (band + 0.5) / 6,
      center = axis
        .clone()
        .multiplyScalar(TORSO_LENGTH * t)
        .add(v(hip));
    cube(
      center.toArray(),
      [(female ? 0.42 : 0.39) + 0.05 * t, TORSO_LENGTH / 6 + 0.008, 0.3],
      garment,
      bodyQ,
    );
  }
  // Cloth folds and front opening keep the body volumetric without stretching it.
  for (let i = -2; i <= 2; i++) {
    const local = v([i * 0.075, 0, -0.157])
      .applyQuaternion(bodyQ)
      .add(v(breast));
    cube(
      local.toArray(),
      [0.014, 0.57, 0.013],
      i % 2 ? '#8f7964' : garment,
      bodyQ,
    );
  }
  if (config.imam) {
    for (const s of [-1, 1]) {
      const pos = v([s * 0.18, 0, -0.164])
        .applyQuaternion(bodyQ)
        .add(v(breast));
      cube(pos.toArray(), [0.025, 0.6, 0.02], '#c5a054', bodyQ);
    }
    const center = v([0, 0, -0.158]).applyQuaternion(bodyQ).add(v(breast));
    cube(center.toArray(), [0.21, 0.61, 0.018], '#e9e3d4', bodyQ);
  }
  const sitting = p.kneeY < 0.2;
  if (!sitting && !p.beads) {
    for (let band = 0; band < 8; band++) {
      const t0 = band / 8,
        t1 = (band + 1) / 8;
      const a = [
          0,
          p.hipY + (0.13 - p.hipY) * t0,
          p.hipZ + (0.04 - p.hipZ) * t0,
        ],
        b = [0, p.hipY + (0.13 - p.hipY) * t1, p.hipZ + (0.04 - p.hipZ) * t1];
      segment(
        a,
        b,
        (female ? 0.45 : 0.39) + 0.09 * t1,
        0.28 + 0.08 * t1,
        garment,
        true,
      );
    }
    for (const s of [-1, 1])
      segment(
        [s * 0.16, p.hipY, p.hipZ - 0.18],
        [s * 0.19, 0.13, -0.14],
        0.016,
        0.018,
        config.imam ? '#bb9451' : garment,
        true,
      );
    if (config.imam)
      segment(
        [0, p.hipY, p.hipZ - 0.19],
        [0, 0.13, -0.15],
        0.23,
        0.022,
        '#e4ddcb',
        true,
      );
  } else if (!p.beads) {
    segment(
      [0, p.hipY, p.hipZ],
      [0, p.kneeY + 0.09, p.kneeZ],
      female ? 0.55 : 0.48,
      0.3,
      garment,
      true,
    );
    segment(
      [0, p.kneeY + 0.1, p.kneeZ],
      [0, 0.16, 0.06],
      female ? 0.53 : 0.46,
      0.25,
      garment,
      true,
    );
    cube(
      [0, p.kneeY + 0.05, p.kneeZ],
      [female ? 0.56 : 0.48, 0.16, 0.32],
      garment,
      identity,
      true,
    );
    for (const side of [-1, 1])
      cube([side * 0.14, 0.085, p.kneeZ], [0.2, 0.12, 0.2], garment);
  }
  if (p.beads) {
    for (const s of [-1, 1])
      segment(
        [s * 0.14, 0.28, 0],
        [s * 0.3, 0.1, -0.17],
        0.18,
        0.18,
        garment,
        true,
      );
    for (const s of [-1, 1])
      segment(
        [s * 0.3, 0.1, -0.17],
        [-s * 0.1, 0.09, -0.1],
        0.15,
        0.15,
        garment,
        true,
      );
  }
  for (const s of [-1, 1]) {
    const lift = p.walking
      ? Math.max(
          0,
          Math.sin(
            (tick / 12) * 3 + (config.phase ?? 0) + (s > 0 ? Math.PI : 0),
          ),
        ) * 0.1
      : 0;
    const footZ = p.walking
      ? -0.12 +
        Math.cos(
          (tick / 12) * 3 + (config.phase ?? 0) + (s > 0 ? Math.PI : 0),
        ) *
          0.12
      : -0.12;
    cube([s * 0.14, 0.0475 + lift, footZ], [0.105, 0.045, 0.09], skin);
    const heel = s < 0 ? p.heelL : p.heelR;
    segment(
      [s * 0.14, 0.055 + lift, footZ],
      [s * 0.14, 0.055 + 0.18 * heel + lift, 0.13 - 0.09 * heel],
      0.1,
      0.065,
      skin,
    );
    const side = s < 0 ? 'left' : 'right',
      hand = p[side + 'Hand'];
    const shoulderPoint = [s * 0.235, p.shoulder[1] - 0.04, p.shoulder[2]];
    const pole =
      p.pose === 'sujood' || p.nextPose === 'sujood'
        ? [s, 0.65, 0]
        : [s * 0.15, -1, 0];
    const elbow = joint(shoulderPoint, hand, 0.35, 0.35, pole);
    segment(shoulderPoint, elbow, 0.12, 0.12, garment);
    segment(elbow, hand, 0.105, 0.105, garment);
    const handQ = new THREE.Quaternion().setFromAxisAngle(
      new THREE.Vector3(1, 0, 0),
      p.handPitch,
    );
    cube(hand, [0.1, 0.13, 0.04], skin, handQ);
    for (let f = 0; f < 4; f++) {
      const finger = v([-0.033 + f * 0.022, 0.055, -0.002])
        .applyQuaternion(handQ)
        .add(v(hand));
      cube(finger.toArray(), [0.017, 0.045, 0.035], skin, handQ);
    }
  }
  const headQ = new THREE.Quaternion().setFromEuler(
    new THREE.Euler(p.headPitch, p.headYaw, 0, 'YXZ'),
  );
  cube(head, [0.29 * hf, 0.33 * hf, 0.29 * hf], skin, headQ);
  const point = (a) =>
    v(a).multiplyScalar(hf).applyQuaternion(headQ).add(v(head)).toArray();
  segment(p.shoulder, point([0, -0.13, 0]), 0.12, 0.12, skin);
  const headBox = (a, size, c) =>
    cube(
      point(a),
      size.map((n) => n * hf),
      c,
      headQ,
    );
  if (!child || female || config.role === 'toddler') {
    headBox([0, 0.18, 0.015], [0.34, 0.07, 0.32], hood);
    headBox([-0.17, 0.025, 0.025], [0.055, 0.36, 0.28], hood);
    headBox([0.17, 0.025, 0.025], [0.055, 0.36, 0.28], hood);
    headBox([0, 0.015, 0.155], [0.35, 0.37, 0.065], hood);
    for (let n = 0; n < 3; n++)
      headBox(
        [0, 0.2 + n * 0.014, 0.025],
        [0.29 - n * 0.035, 0.022, 0.27 - n * 0.035],
        hood,
      );
    const back = axis
      .clone()
      .multiplyScalar(0.08)
      .add(v(shoulder))
      .add(v([0, 0, 0.13]));
    segment(point([0, -0.1, 0.14]), back.toArray(), 0.3, 0.055, hood);
  } else {
    headBox([0, 0.175, 0.01], [0.31, 0.07, 0.3], '#302820');
    headBox([0, 0.04, 0.15], [0.3, 0.26, 0.04], '#322a25');
  }
  const name = config.imam
    ? 'yasser-face'
    : (config.face ??
      (female
        ? variant % 2
          ? 'woman-cream-face'
          : 'woman-navy-face'
        : variant % 2
          ? 'elder-face'
          : 'man-face'));
  const facePoint = transform(point([0, 0, -0.171]));
  const faceQ = rootQ
    .clone()
    .multiply(headQ)
    .multiply(new THREE.Quaternion().setFromAxisAngle(up, Math.PI));
  addFace(name, facePoint, faceQ, sc * hf);
  if (!female && !child)
    cube(
      point([0, -0.14, -0.145]),
      [0.19, 0.105, 0.035],
      variant % 2 && !config.imam ? '#73716b' : '#28231f',
      headQ,
    );
  if (p.beads) {
    for (let n = 0; n < 33; n++) {
      const a = (n / 33) * Math.PI * 2 + tick * 0.008;
      cube(
        [Math.cos(a) * 0.075, 0.425 + Math.sin(a) * 0.085, -0.19],
        [0.012, 0.012, 0.012],
        n % 5 ? '#65452e' : '#b89452',
      );
    }
  }
}
const people = [IMAM, ...MEN, ...WOMEN, ...CHILDREN];
let selectedActor = null,
  orbitAngle = 0,
  childMode = 'prayer';
const backgroundColor = scene.background;
function actorPose(person, tick) {
  if (person.child && childMode === 'prayer')
    return stateAtTick(tick, person.delay || 18);
  return person.child
    ? childState(person, tick)
    : stateAtTick(tick, person.delay);
}

let viewAngle =
  new URLSearchParams(location.search).get('angle') === 'bird'
    ? 'bird'
    : 'front';
let clock = 0,
  playing = !matchMedia('(prefers-reduced-motion: reduce)').matches,
  lastTime;
export function renderAt(seconds) {
  clock = Math.max(0, Math.min(DURATION, seconds));
  const tick = clock * FPS;
  actors.used = 0;
  for (const f of Object.values(faceBatches)) f.used = 0;
  for (const person of people.filter(
    (p) => !selectedActor || p.id === selectedActor,
  )) {
    const p = actorPose(person, tick);
    actorGeometry(
      selectedActor ? { ...person, x: 0, z: 0 } : person,
      selectedActor ? { ...p, x: 0, z: 0 } : p,
      tick,
    );
  }
  actors.finish();
  for (const f of Object.values(faceBatches)) {
    f.mesh.count = f.used;
    f.mesh.instanceMatrix.needsUpdate = true;
  }
  {
    const c = cameraAtTick(tick, viewAngle);
    roofFrame.mesh.visible = viewAngle !== 'bird';
    camera.up.set(...(viewAngle === 'bird' ? [0, 0, -1] : [0, 1, 0]));
    camera.position.set(...c.position);
    camera.lookAt(...c.target);
    const h = c.size,
      w = (h * 960) / 540;
    camera.left = -w / 2;
    camera.right = w / 2;
    camera.top = h / 2;
    camera.bottom = -h / 2;
    camera.updateProjectionMatrix();
  }
  const actorMeshes = new Set([
    actors.mesh,
    ...Object.values(faceBatches).map((f) => f.mesh),
  ]);
  for (const object of scene.children)
    if (object.isMesh && !actorMeshes.has(object))
      object.visible = !selectedActor;
  roofFrame.mesh.visible = !selectedActor && viewAngle !== 'bird';
  scene.background = selectedActor ? null : backgroundColor;
  renderer.setClearAlpha(selectedActor ? 0 : 1);
  if (selectedActor) {
    const a = (orbitAngle * Math.PI) / 180;
    camera.up.set(0, 1, 0);
    camera.position.set(Math.sin(a) * 5, 2.8, -Math.cos(a) * 5);
    camera.lookAt(0, 1.05, 0);
    camera.left = -1.3;
    camera.right = 1.3;
    camera.top = 1.95;
    camera.bottom = -1.95;
    camera.updateProjectionMatrix();
  }
  renderer.render(scene, camera);
  document.querySelector('#scrub').value = clock;
  document.querySelector('#status').textContent =
    `${caption(tick)} · ${clock.toFixed(1)} / ${DURATION} s`;
  return { seconds: clock, phase: caption(tick), people: people.length };
}
function animate(time) {
  if (lastTime !== undefined && playing) {
    clock = Math.min(DURATION, clock + Math.min(0.2, (time - lastTime) / 1000));
    if (clock === DURATION) {
      playing = false;
      document.querySelector('#play').textContent = 'Replay';
    }
  }
  lastTime = time;
  if (playing) renderAt(clock);
  requestAnimationFrame(animate);
}
document.querySelector('#play').onclick = () => {
  if (clock >= DURATION) clock = 0;
  playing = !playing;
  document.querySelector('#play').textContent = playing ? 'Pause' : 'Play';
};
document.querySelector('#scrub').oninput = (e) => {
  playing = false;
  document.querySelector('#play').textContent = 'Play';
  renderAt(Number(e.target.value));
};
document.querySelector('#angle').value = viewAngle;
document.querySelector('#angle').onchange = (e) => {
  viewAngle = e.target.value;
  renderAt(clock);
};
document.querySelector('#keyart').onclick = () =>
  window.open('./assets/mosque-key-art.webp', '_blank');
window.prayerScene = {
  get characters() {
    return people.map((p) => ({ ...p }));
  },
  selectActor(id = null) {
    if (id && !people.some((p) => p.id === id))
      throw new Error('Unknown actor');
    selectedActor = id;
    renderer.setSize(id ? 256 : 960, id ? 384 : 540, false);
    return renderAt(clock);
  },
  setOrbit(degrees) {
    orbitAngle = degrees;
    return renderAt(clock);
  },
  setChildren(mode) {
    childMode = mode;
    return renderAt(clock);
  },
  setAngle(angle) {
    if (!['front', 'bird'].includes(angle)) throw new Error('Unknown angle');
    viewAngle = angle;
    document.querySelector('#angle').value = angle;
    return renderAt(clock);
  },
  get angle() {
    return viewAngle;
  },
  renderAt(t) {
    playing = false;
    return renderAt(t);
  },
  get time() {
    return clock;
  },
  get playing() {
    return playing;
  },
  get renderer() {
    return renderer;
  },
  get camera() {
    return camera;
  },
  get scene() {
    return scene;
  },
  inspect(t) {
    return {
      imam: stateAtTick(t * FPS),
      adult: stateAtTick(t * FPS, 6),
      toddler: childState(CHILDREN[0], t * FPS),
      girl: childState(CHILDREN[4], t * FPS),
    };
  },
};
document.querySelector('#play').textContent = playing ? 'Pause' : 'Play';
window.prayerReady = true;
renderAt(0);
requestAnimationFrame(animate);

const pick = document.querySelector('#character');
for (const actor of people) {
  const option = document.createElement('option');
  option.value = actor.id;
  option.textContent = actor.id;
  pick.append(option);
}
pick.onchange = () => window.prayerScene.selectActor(pick.value || null);
document.querySelector('#orbit').oninput = (e) =>
  window.prayerScene.setOrbit(Number(e.target.value));
document.querySelector('#children').onchange = (e) =>
  window.prayerScene.setChildren(e.target.value);
window.addEventListener('message', (e) => {
  if (e.source !== parent || !e.data?.prayer) return;
  const { time, actor, angle } = e.data;
  if (actor !== undefined) window.prayerScene.selectActor(actor);
  if (angle !== undefined) window.prayerScene.setOrbit(angle);
  if (time !== undefined) window.prayerScene.renderAt(time);
});

if (parent !== window) parent.postMessage({ prayerReady: true }, '*');
