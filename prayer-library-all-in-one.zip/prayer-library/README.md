# Individual prayer characters and editable 3D component

DRAFT — awaiting review. Yasser Al-Dosari is the lead character. The latest
reference layout is used: men behind the imam, women behind a transverse carved
screen. There are 12 men, 12 women and five fictional children, plus Yasser.

## Artwork and individual exports

`artwork/` contains newly generated detailed character artwork, individual crops,
and the original source sheets. Yasser has eight turnaround directions and a
separate prayer pose sheet. Men and women each have twelve individual designs;
children have standing and prayer-pose artwork.

`characters/<id>/` contains the editable 3D component's rendered key poses:
8 directions at 45-degree intervals × 11 prayer poses = 88 transparent lossless WebPs per
character, 2,640 WebP images total. See `characters/manifest.json` for direction, pose time,
identity, size and delay metadata. These are key poses, not full frame strips.

The detailed generated artwork and the simpler articulated voxel motion study
are separate assets. The component uses genuine 3D geometry and pixel face
textures; it is not a fully rigged reproduction of every fold in the artwork.
No GLB/FBX skeletal model is claimed or included.

## Run and embed

Extract the component ZIP and run inside its folder:

```sh
python3 -m http.server 5184
```

Open http://localhost:5184. Use the character selector for individual people,
Rotate for all angles, Play/Pause and the timeline slider. The whole scene has
front-facing and bird's-eye cameras. Children follow the adults late by default;
the optional background mode restores beads, hijab adjustment and quiet tag.

Embed from a web server:

```html
<script type="module" src="./prayer-component.mjs"></script>
<prayer-animation id="prayer"></prayer-animation>
<script>
  // After the iframe finishes loading:
  // prayer.character('yasser-al-dosari');
  // prayer.rotate(135);
  // prayer.seek(23);
</script>
```

The animation is a finite, time-compressed 84-second sequence: takbir, folded
recitation, ruku, rising, two sujoods separated by sitting, a second rakah,
tashahhud, right/left salam, and a separate dua. Adult followers lag by half a
second; children follow later. Playback interpolates the deterministic 12 Hz
model, with a 240-tick chapter clock. The MP4 is recorded at 24 fps.

No synthetic speech or recitation is included. This is a silent draft visual
study; real licensed audio can be supplied separately. Main-world deployment
and approval metadata are unchanged.

## Source and checks

`scene.mjs`: geometry, inverse-kinematics limbs, lighting, camera and player.
`timeline.mjs`: all poses, interpolation, timing and actor configurations.
`prayer-component.mjs`: reusable web component wrapper.
`assets/`: generated pixel face textures and material/source atlases.
`vendor/`: Three.js 0.180.0 and its MIT license; no network is needed at runtime.

Run `node --test verify-timeline.mjs` for posture order, contacts, follower delay,
children's bounds, proportions and camera checks. Browser exports also verify
that all 30 characters and every pose render without script errors.

Each download ZIP is independent and strictly below 30,000,000 bytes. Character
ZIPs contain their own readme and source artwork; the component ZIP contains the
complete runnable animation. Keep the originals when editing.


## Combined one-file edition

All five original packs are combined here. Images use lossless WebP to meet the
30 MB file limit: decoded RGBA pixels were checked against every original PNG.
The browser component loads these WebP files directly. Artwork, 30 characters,
2,640 pose images, source code and the complete silent preview are included.
Original PNG downloads remain available separately if that format is needed.
