# Dar al-Salam: world designs and animation export

This archive contains the complete design and animation rework from commit
c98f2399caf1d6195670d17cf7ab2b0afa9bc1fd, before it was reverted.
Exporting this ZIP leaves the reverted app and GitHub branches unchanged.

## Contents

- rework-files/: all 97 added or modified files, preserving repository paths.
  Includes final transparent scenery PNGs; four waterfall frames; tram direction
  and door poses; taxi and ship direction poses; building/tile artwork; placement
  and import tools; procedural skyline/ground/sky sources; renderer effects;
  deterministic movement logic; preview controls; integration changes and tests.
- source-sheets/: all seven generated source sheets, including earlier landscape
  versions. original-filenames.json maps the filenames mentioned in the source
  documentation to the portable names in this folder.
- previews/animated-world.mp4: the full recorded in-app preview of six landscapes.
- previews/animated-world.gif: shorter animated highlights.
- previews/stills/, previews/design-details/, previews/overview.png: scene captures.
- patches/world-rework.patch: the complete Git binary patch for the rework.
- manifest.json and SHA256SUMS: file inventory and content checksums.

The rework-files folder is an integration pack for the Dar-al-Salam repository.
Use the existing project for its unchanged source, dependencies and characters.
The PNGs contain asset poses; movement, wind, weather, signals, wakes, smoke and
birds are evaluated in code. The MP4/GIF files show the rendered result.

## Main source files

- art/landscape/index.json: scenery metadata, dimensions, anchors and poses.
- packages/shared/world-life.ts: tram timetable/doors, taxi right of way, offshore
  ship routes, wind and shared world state.
- packages/shared/districts.ts: district boundaries, camera destinations, lighting.
- web/src/engine/Engine.ts and WorldEffects.ts: projection, animation, wet-light
  reflections, wind, birds, chimneys, traffic signals, catenary and ship wakes.
- web/src/ui/LandscapeExplorer.tsx and LivingWorldPanel.tsx: navigation and preview.
- tools/landscape/: sheet importers, forest composition, district placement and mist.
- tools/placeholder/modern.ts, tools/build/sky.ts and tools/build/index.ts: procedural
  artwork and the atlas/world build integration.

Animation uses a deterministic 12-tick-per-second, 240-frame (20-second) loop.
Trams stop before opening doors; taxis obey the crossing signals; ships follow
validated offshore courses. In the app, use Living world > Preview animation.
Preview/Pause and the top-bar Play/Pause button control the same world clock.
A reduced-motion preference starts the world paused.

## Restore later, only when wanted

The patch applies to the original pre-rework project tree at f87d1fb, including
the reverted tree at 4cf8fdc. Run these commands from that repository root,
replacing /path/to/export with the location where you extracted this ZIP:

    git apply --check /path/to/export/patches/world-rework.patch
    git apply /path/to/export/patches/world-rework.patch

Then, using Node 24 and pnpm 11.25.0:

    pnpm install --frozen-lockfile
    pnpm dev

For a compiled preview, run:

    pnpm build:preview

Normal builds use the included final PNGs and need no source-sheet reimport or
image-generation service. Generated atlases, world data and dist are rebuilt.
Repository character/content approval rules continue to apply.

Original source documentation retains the historical workspace source-sheet
paths; use source-sheets/original-filenames.json to find those sheets in this ZIP.
