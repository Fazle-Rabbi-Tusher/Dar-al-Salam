# Master-class prompt — Yasser Al-Dosari prayer scene

Create a serene 3D pixel-art isometric animation with retro-modern voxel graphics,
smooth cinematic lighting, soft volumetric glow, and the owner's saved character
style. Match Yasser Al-Dosari's supplied reference: white ghutra and thobe,
rectangular glasses, neat dark beard, and dark brown bisht with gold edging.
Keep his identity, outfit and material shading consistent. All adults must have
natural tall proportions: roughly 7.5–8 anatomical heads in total height, small
realistic heads, long legs and torso, natural shoulder width, slender robe
silhouettes and believable limb lengths. Avoid oversized heads, squat bodies,
short legs or chibi proportions. Children alone have age-appropriate shorter
stature. Do not vertically stretch a finished sprite to fake adult proportions.

Inside a magnificent, warmly lit modern mosque, combine cream stone arches,
traditional geometric architecture, bronze lamps, patterned carpets and a plain
mihrab niche. Yasser stands alone at the front on a decorative geometric prayer
rug, facing Qibla. Use the latest provided mosque reference arrangement: men's
rows behind the imam; women's rows farther behind a transverse carved wooden
lattice screen. All face Qibla. Give adults natural tall proportions and children
distinct age-appropriate stature. Export every character individually from eight
angles, plus key prayer poses and a complete editable 3D animation component.
Children pray with a gentle delay as they imitate the adults. Preserve the optional
subtle background interactions in a separate player mode.

## Main prayer sequence — smooth chronological flow

1. Intention and opening takbir: everyone faces Qibla. The imam raises both hands
   to shoulder/ear height, then folds his right hand over his left at the chest.
   The adult congregation follows him slightly later, never anticipating him.
2. Standing recitation and ruku: maintain calm folded hands and lowered gaze;
   transition smoothly into bowing with hands on knees, a level back and head
   aligned with the torso; rise upright again.
3. Sujood: descend through kneeling into prostration with forehead/nose, palms,
   knees and toes at ground contact. Keep men's elbows lifted and forearms off
   the floor. Sit briefly between the two prostrations, hands on thighs, then
   perform the second prostration before rising.
4. Continue into the next rak'ah with the same orderly sequence. After the final
   two prostrations, sit for tashahhud. Conclude with serene head turns to the
   right, then left, while the body remains seated and still.
5. After the closing salam, show a separate brief heartfelt dua, palms raised
   naturally, then settling. Do not insert expressive hand-waving into standing
   recitation or confuse the dua with the prayer postures.

Use an explicitly time-compressed visual sequence with peaceful holds, soft
weight transfer and articulated joint motion. Preserve contact points instead
of stretching a standing still into a bow or prostration. Adult worshippers
follow the imam with a small consistent delay.

## Children's background layer

Keep these small, warm and unobtrusive, near the back rows and far aisles, as
subtle details rewarded by close inspection or rewatching:

- A toddler in a tiny thawb stands beside his father. He peeks sideways to check
  the adults, then imitates ruku and sujood about a second later than them.
- In the far background aisle, two children quietly tiptoe in a gentle game of
  tag around the carpeted pillars. They occasionally duck behind a pillar,
  remain outside the prayer rows, and never bump into worshippers.
- Another child sits cross-legged near his father, quietly moving tasbih beads
  between his fingers while watching the imam. The movement is small and patient.
- A little girl on the women's side near the central partition adjusts the edge of her tiny hijab
  during standing, then copies her mother's prayer movements slightly late.

Keep the adults' prayer calm and uninterrupted. Avoid exaggerated comedy,
running, loud reactions, crowd clutter or children's behavior dominating the
main composition. Maintain modest dress and natural child proportions.

## Cinematic direction

Position the camera on the Qibla side, looking straight toward the imam and
congregation in the requested 180-degree front-facing view. Everyone faces
toward the camera/viewer. Use this as the primary cinematic angle. Also provide
a separate bird's-eye overhead view of the same scene and synchronized action,
clearly showing the rows, women's partition and the children's unobstructed aisle
paths. Keep an angle switch in the interactive preview. Do not replace the front
view with a rear view. Use gentle push-ins and pullbacks, a slightly elevated
wide view to reveal the orderly rows, restrained front close views of the imam,
and wider framing revealing the separated women's rows and the tiny children's
interactions. Cut away the camera-side Qibla wall for visibility; do not turn the
worshippers away from Qibla to obtain the shot. Use warm indirect light, soft
contact shadows, softly
lit geometric lattice patterns and subtle dust motes. Keep camera moves smooth,
with no abrupt zooms or clipping through architecture or people.

No generated Arabic lettering, calligraphy, sacred text, Qur'an pages, logos or
religious symbols are to appear in the artwork. Do not synthesize or imitate
Qur'an recitation or attribute invented speech to Yasser. Provide a silent visual
preview and an empty hook for real licensed recitation supplied separately.
Keep the scene marked as a draft awaiting review; the visual study is not a
religious ruling or an approved instructional depiction.
