import test from 'node:test';
import assert from 'node:assert/strict';
import {
  FPS,
  TORSO_LENGTH,
  ADULT_HEAD_SCALE,
  DURATION,
  MASTER_LOOP,
  FOLLOW_DELAY,
  KEYS,
  MEN,
  WOMEN,
  IMAM,
  CHILDREN,
  stateAtTick,
  childState,
  cameraAtTick,
} from './timeline.mjs';

test('two rakahs have two prostrations each, followed by seated salam and dua', () => {
  const holds = KEYS.filter(
    (key, i) => key[1] === 'sujood' && KEYS[i + 1]?.[1] === 'sujood',
  );
  assert.equal(holds.length, 4);
  for (const seconds of [23, 31, 55, 63]) {
    const state = stateAtTick(seconds * FPS);
    assert.equal(state.pose, 'sujood');
    assert.ok(Math.abs(state.foreheadHeight - 0.025) < 0.001);
    assert.equal(state.leftHand[1], 0.045);
    assert.equal(state.kneeY, 0.085);
  }
  assert.ok(stateAtTick(73 * FPS).headYaw < 0);
  assert.ok(stateAtTick(75 * FPS).headYaw > 0);
  assert.equal(stateAtTick(79 * FPS).pose, 'dua');
  assert.equal(stateAtTick(79 * FPS).completed, true);
});

test('adults follow the imam; toddler follows adults one additional second later', () => {
  for (const adult of [...MEN, ...WOMEN])
    assert.equal(adult.delay, FOLLOW_DELAY);
  assert.equal(IMAM.delay, 0);
  for (const seconds of [13, 21, 29, 45, 53, 61]) {
    const tick = seconds * FPS;
    const toddler = childState(CHILDREN[0], tick);
    assert.deepEqual(toddler.hip, stateAtTick(tick - FOLLOW_DELAY - FPS).hip);
  }
});

test('congregation follows imam with women behind screen and children near parents', () => {
  assert.ok(MEN.every(actor => actor.z > IMAM.z && actor.z < 3.4));
  assert.ok(WOMEN.every(actor => actor.z > 3.4));
  assert.ok(CHILDREN.find(actor => actor.role === 'girl').z > 3.4);
  for (const child of CHILDREN.filter((actor) => actor.parentId)) {
    const parent = [...MEN, ...WOMEN].find(
      (actor) => actor.id === child.parentId,
    );
    assert.ok(parent);
    assert.ok(Math.hypot(child.x - parent.x, child.z - parent.z) < 1.1);
  }
  const tags = CHILDREN.filter((actor) => actor.role === 'tag');
  for (let tick = 0; tick <= DURATION * FPS; tick++) {
    const states = tags.map((actor) => childState(actor, tick));
    for (const state of states) {
      assert.ok(state.x > 4.2 && state.x < 5.5);
      assert.ok(state.z > 7.7 && state.z < 9.5);
      assert.ok(Math.hypot(state.x - 4.85, state.z - 8.6) >= 0.61);
      assert.equal(state.pose, 'tiptoe');
    }
    assert.ok(
      Math.hypot(states[0].x - states[1].x, states[0].z - states[1].z) > 1.2,
    );
  }
});

test('bead child remains cross-legged; girl adjusts hijab only during standing holds', () => {
  const beads = CHILDREN.find((actor) => actor.role === 'beads');
  const girl = CHILDREN.find((actor) => actor.role === 'girl');
  for (const seconds of [0, 8, 23, 40, 63, 79]) {
    const state = childState(beads, seconds * FPS);
    assert.equal(state.pose, 'cross-legged');
    assert.equal(state.beads, true);
  }
  for (const seconds of [8, 40]) {
    const state = childState(girl, seconds * FPS);
    assert.equal(state.pose, 'folded');
    assert.ok(state.rightHand[1] > state.head[1] - 0.04);
  }
  assert.deepEqual(
    childState(girl, 23 * FPS).rightHand,
    stateAtTick(23 * FPS, girl.delay).rightHand,
  );
});

test('deterministic finite chapters preserve fixed toes and torso length through every transition', () => {
  for (let tick = 0; tick <= DURATION * FPS; tick += 0.5) {
    const state = stateAtTick(tick);
    assert.deepEqual(state.toes, [
      [-0.14, 0.025, -0.12],
      [0.14, 0.025, -0.12],
    ]);
    assert.ok(
      Math.abs(
        Math.hypot(...state.shoulder.map((v, i) => v - state.hip[i])) -
          TORSO_LENGTH,
      ) < 1e-8,
    );
    assert.deepEqual(stateAtTick(tick), state);
    assert.ok(cameraAtTick(tick).position.every(Number.isFinite));
  }
  assert.equal(stateAtTick(MASTER_LOOP).chapter, 1);
  assert.equal(stateAtTick(MASTER_LOOP).frame, 0);
  assert.notDeepEqual(stateAtTick(MASTER_LOOP).hip, stateAtTick(0).hip);
  assert.deepEqual(
    stateAtTick(DURATION * FPS + 999),
    stateAtTick(DURATION * FPS),
  );
});

test('camera stays straight-on in front of all worshippers for the whole film', () => {
  for (let tick = 0; tick <= DURATION * FPS; tick++) {
    const shot = cameraAtTick(tick);
    assert.equal(shot.position[0], shot.target[0]);
    assert.ok(shot.position[2] < -7.35);
    assert.ok(shot.target[2] > shot.position[2]);
  }
});

test('bird’s-eye view is vertical and covers the entire prayer hall', () => {
  for (const seconds of [0, 14, 23, 40, 69, 84]) {
    const shot = cameraAtTick(seconds * FPS, 'bird');
    assert.equal(shot.position[0], shot.target[0]);
    assert.equal(shot.position[2], shot.target[2]);
    assert.ok(shot.position[1] > 20);
    assert.ok(shot.size > 18);
  }
});

// Regression: the owner explicitly rejected squat / oversized-head adults.
test('adults have tall proportions and smaller heads, with longer legs and torso', () => {
  const p = stateAtTick(8 * FPS);
  const height = p.head[1] + 0.25 * ADULT_HEAD_SCALE;
  assert.ok(height / (0.33 * ADULT_HEAD_SCALE) > 7.5);
  assert.ok(height / (0.33 * ADULT_HEAD_SCALE) < 8.5);
  assert.ok(height / 0.54 > 3.7);
  assert.ok(p.hipY > 1);
  assert.equal(TORSO_LENGTH, 0.62);
});
