// Dependency-free web component; place this file alongside index.html.
export class PrayerAnimation extends HTMLElement {
  connectedCallback() {
    if (this.frame) return;
    this.frame = document.createElement('iframe');
    this.ready = new Promise((resolve) => {
      const listen = (e) => {
        if (e.source === this.frame.contentWindow && e.data?.prayerReady) {
          window.removeEventListener('message', listen);
          resolve();
        }
      };
      window.addEventListener('message', listen);
    });
    this.frame.title = '3D congregational prayer animation';
    this.frame.src = new URL('./index.html', import.meta.url).href;
    this.frame.style.cssText = 'width:100%;height:760px;border:0';
    this.append(this.frame);
  }
  seek(seconds) {
    this.ready.then(() =>
      this.frame.contentWindow.postMessage(
        { prayer: true, time: seconds },
        new URL(this.frame.src).origin,
      ),
    );
  }
  character(id = null) {
    this.ready.then(() =>
      this.frame.contentWindow.postMessage(
        { prayer: true, actor: id },
        new URL(this.frame.src).origin,
      ),
    );
  }
  rotate(degrees) {
    this.ready.then(() =>
      this.frame.contentWindow.postMessage(
        { prayer: true, angle: degrees },
        new URL(this.frame.src).origin,
      ),
    );
  }
}
if (!customElements.get('prayer-animation'))
  customElements.define('prayer-animation', PrayerAnimation);
