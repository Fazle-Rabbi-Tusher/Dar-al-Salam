// Finite cinematic timeline composed from the world's 12 Hz / 240-tick chapters.
export const FPS = 12,
  MASTER_LOOP = 240,
  DURATION = 84,
  FOLLOW_DELAY = 6;
export const ADULT_HEAD_SCALE = 0.81,
  TORSO_LENGTH = 0.62,
  HEAD_REACH = 0.87;
const rad = Math.PI / 180;
const base = {
  hipY: 1.06,
  hipZ: 0,
  lean: 0,
  headPitch: 0,
  headYaw: 0,
  kneeY: 0.56,
  kneeZ: 0,
  heelL: 0,
  heelR: 0,
  handPitch: 0,
  index: 0,
};
const poses = {
  stand: { ...base, arms: 'side' },
  takbir: { ...base, arms: 'raised' },
  folded: { ...base, arms: 'folded' },
  ruku: {
    ...base,
    hipY: 1.1,
    hipZ: 0.06,
    lean: 90 * rad,
    headPitch: -90 * rad,
    arms: 'knees',
  },
  kneel: {
    ...base,
    hipY: 0.4,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelL: 1,
    heelR: 1,
    arms: 'thighs',
  },
  sujood: {
    ...base,
    hipY: 0.55,
    hipZ: -0.1,
    lean: Math.acos((0.025 + 0.171 * ADULT_HEAD_SCALE - 0.55) / HEAD_REACH),
    headPitch: -90 * rad,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelL: 1,
    heelR: 1,
    handPitch: -90 * rad,
    arms: 'floor',
  },
  seated: {
    ...base,
    hipY: 0.36,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelR: 1,
    arms: 'thighs',
  },
  tashahhud: {
    ...base,
    hipY: 0.36,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelR: 1,
    index: 1,
    arms: 'thighs',
  },
  right: {
    ...base,
    hipY: 0.36,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelR: 1,
    headYaw: -55 * rad,
    arms: 'thighs',
  },
  left: {
    ...base,
    hipY: 0.36,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelR: 1,
    headYaw: 55 * rad,
    arms: 'thighs',
  },
  dua: {
    ...base,
    hipY: 0.36,
    hipZ: -0.1,
    kneeY: 0.085,
    kneeZ: -0.28,
    heelR: 1,
    handPitch: 90 * rad,
    arms: 'dua',
  },
};
// Duplicate keys create quiet holds; transitions use zero-velocity/acceleration ends.
export const KEYS = [
  [0, 'stand'],
  [1.8, 'stand'],
  [3, 'takbir'],
  [3.6, 'takbir'],
  [4.6, 'folded'],
  [12, 'folded'],
  [13.3, 'ruku'],
  [16, 'ruku'],
  [17.3, 'stand'],
  [19, 'stand'],
  [20, 'kneel'],
  [21.3, 'sujood'],
  [25, 'sujood'],
  [26.3, 'seated'],
  [28, 'seated'],
  [29.3, 'sujood'],
  [33, 'sujood'],
  [34.3, 'kneel'],
  [36, 'folded'],
  [44, 'folded'],
  [45.3, 'ruku'],
  [48, 'ruku'],
  [49.3, 'stand'],
  [51, 'stand'],
  [52, 'kneel'],
  [53.3, 'sujood'],
  [57, 'sujood'],
  [58.3, 'seated'],
  [60, 'seated'],
  [61.3, 'sujood'],
  [65, 'sujood'],
  [66.3, 'seated'],
  [67, 'tashahhud'],
  [71, 'tashahhud'],
  [72.8, 'right'],
  [73.2, 'right'],
  [74.8, 'left'],
  [75.2, 'left'],
  [76, 'seated'],
  [77.6, 'dua'],
  [81, 'dua'],
  [82.5, 'seated'],
  [84, 'seated'],
];
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const smoother = (x) => {
  x = clamp(x);
  return x * x * x * (x * (x * 6 - 15) + 10);
};
const lerp = (a, b, t) => a + (b - a) * t;
function hands(p, s) {
  switch (p.arms) {
    case 'raised':
      return [s * 0.29, 1.88, -0.12];
    case 'folded':
      return [
        s > 0 ? -0.035 : 0.035,
        p.hipY + 0.39 + (s > 0 ? 0.025 : 0),
        p.hipZ - 0.19 - (s > 0 ? 0.035 : 0),
      ];
    case 'knees':
      return [s * 0.16, p.kneeY + 0.055, p.kneeZ - 0.075];
    case 'floor':
      return [s * 0.26, 0.045, -0.81];
    case 'thighs':
      return [s * 0.15, p.hipY + 0.09, p.kneeZ + 0.03];
    case 'dua':
      return [s * 0.14, p.hipY + 0.48, p.hipZ - 0.22];
    default:
      return [s * 0.28, p.hipY + 0.1, p.hipZ - 0.02];
  }
}
export function stateAtTick(input, delay = 0) {
  const tick = clamp(input - delay, 0, DURATION * FPS),
    seconds = tick / FPS;
  let i = 0;
  while (i < KEYS.length - 2 && seconds >= KEYS[i + 1][0]) i++;
  const [start, name] = KEYS[i],
    [end, next] = KEYS[i + 1],
    t = smoother((seconds - start) / Math.max(0.0001, end - start));
  const a = poses[name],
    b = poses[next],
    state = {
      tick,
      seconds,
      chapter: Math.floor(tick / MASTER_LOOP),
      frame: Math.floor(tick) % MASTER_LOOP,
      pose: name,
      nextPose: next,
      blend: t,
    };
  for (const key of Object.keys(base)) state[key] = lerp(a[key], b[key], t);
  for (const [side, s] of [
    ['left', -1],
    ['right', 1],
  ]) {
    const x = hands(a, s),
      y = hands(b, s);
    state[side + 'Hand'] = x.map((v, j) => lerp(v, y[j], t));
  }
  const theta = state.lean;
  state.hip = [0, state.hipY, state.hipZ];
  state.shoulder = [
    0,
    state.hipY + TORSO_LENGTH * Math.cos(theta),
    state.hipZ - TORSO_LENGTH * Math.sin(theta),
  ];
  state.head = [
    0,
    state.hipY + HEAD_REACH * Math.cos(theta),
    state.hipZ - HEAD_REACH * Math.sin(theta),
  ];
  state.foreheadHeight =
    state.head[1] +
    0.075 * ADULT_HEAD_SCALE * Math.cos(state.headPitch) +
    0.171 * ADULT_HEAD_SCALE * Math.sin(state.headPitch);
  state.toes = [
    [-0.14, 0.025, -0.12],
    [0.14, 0.025, -0.12],
  ];
  state.rakah = seconds < 36 ? 1 : 2;
  state.completed = seconds >= 76;
  return state;
}
export const MEN = Array.from({ length: 12 }, (_, i) => ({
  id: `prayer-man-${String(i + 1).padStart(2, '0')}`,
  // Camera looks along +Z: positive world X is the viewer’s LEFT.
  x: ((i % 6) - 2.5) * 0.78,
  z: -1.5 + Math.floor(i / 6) * 2.6,
  gender: 'male',
  variant: i % 4,
  delay: FOLLOW_DELAY,
}));
export const WOMEN = Array.from({ length: 12 }, (_, i) => ({
  id: `prayer-woman-${String(i + 1).padStart(2, '0')}`,
  x: ((i % 4) - 1.5) * 0.8,
  z: 4.5 + Math.floor(i / 4) * 1.9,
  gender: 'female',
  variant: i % 4,
  delay: FOLLOW_DELAY,
}));
export const IMAM = {
  id: 'yasser-al-dosari',
  x: 0,
  z: -4,
  gender: 'male',
  variant: 0,
  imam: true,
  delay: 0,
  panelApproved: false,
};
export const PARTITION_X = 0;
export const PARTITION_START_Z = -2.6;
export const PARTITION_END_Z = 8.6;
export function caption(tick) {
  const t = tick / FPS;
  if (t < 4.6) return 'Intention and opening takbir';
  if (t < 12 || (t >= 36 && t < 44)) return 'Standing recitation';
  if (t < 16 || (t >= 44 && t < 48)) return 'Bowing · ruku';
  if (t < 19 || (t >= 48 && t < 51)) return 'Standing upright';
  if (
    t < 25 ||
    (t >= 28 && t < 33) ||
    (t >= 51 && t < 57) ||
    (t >= 60 && t < 65)
  )
    return 'Prostration · sujood';
  if (t < 28 || (t >= 57 && t < 60)) return 'Sitting between prostrations';
  if (t < 36) return 'Rising for the second rak‘ah';
  if (t < 71) return 'Final sitting · tashahhud';
  if (t < 76) return 'Closing head turns · salam';
  return 'Dua after prayer';
}
// Straight-on front view: camera always stays on the Qibla side, x aligned
// with its target. A small elevation reveals the rows without orbiting behind.
const cameras = [
  [0, [0, 6.8, -18], [0, 1.0, 1.5], 10.4],
  [12, [0, 5.8, -17], [0, 0.9, 0.8], 9.7],
  [28, [0, 6.8, -18], [0, 0.8, 1.8], 10.4],
  [39, [0, 6.0, -17], [0, 0.9, 1.2], 9.2],
  [45, [0, 5.0, -17], [0, 0.8, -0.5], 8.8],
  [63, [0, 6.2, -18], [0, 0.7, 1.4], 10],
  [69, [0, 5.8, -17], [0, 0.8, 1.2], 9.2],
  [77, [0, 5.8, -17], [0, 0.8, 0.7], 9.5],
  [84, [0, 6.8, -18], [0, 1.0, 1.5], 10.4],
];
export function cameraAtTick(tick, angle = 'front') {
  if (angle === 'bird')
    return { position: [0, 24, 1.2], target: [0, 0, 1.2], size: 19.6 };
  const seconds = clamp(tick / FPS, 0, DURATION);
  let i = 0;
  while (i < cameras.length - 2 && seconds >= cameras[i + 1][0]) i++;
  const [a, p, target, size] = cameras[i],
    [b, q, other, nextSize] = cameras[i + 1],
    t = smoother((seconds - a) / (b - a));
  return {
    position: p.map((v, j) => lerp(v, q[j], t)),
    target: target.map((v, j) => lerp(v, other[j], t)),
    size: lerp(size, nextSize, t),
  };
}
export const CHILDREN = [
  {
    id: 'prayer-toddler',
    x: 2.65,
    z: 1.14,
    parentId: 'prayer-man-12',
    gender: 'male',
    child: true,
    scale: 0.43,
    role: 'toddler',
    face: 'toddler-face',
    delay: FOLLOW_DELAY + 12,
  },
  {
    id: 'aisle-child-a',
    x: 4.85,
    z: 8.6,
    gender: 'male',
    child: true,
    scale: 0.53,
    role: 'tag',
    face: 'tag-child-face',
    phase: 0,
    delay: 0,
  },
  {
    id: 'aisle-child-b',
    x: 4.85,
    z: 8.6,
    gender: 'male',
    child: true,
    scale: 0.5,
    role: 'tag',
    face: 'bead-child-face',
    phase: 2.7,
    delay: 0,
  },
  {
    id: 'bead-child',
    x: -2.65,
    z: 1.4,
    parentId: 'prayer-man-07',
    gender: 'male',
    child: true,
    scale: 0.46,
    role: 'beads',
    face: 'bead-child-face',
    delay: 0,
  },
  {
    id: 'partition-girl',
    x: -1.85,
    z: 4.5,
    parentId: 'prayer-woman-01',
    gender: 'female',
    child: true,
    scale: 0.49,
    role: 'girl',
    face: 'girl-face',
    delay: FOLLOW_DELAY + 4,
  },
];
const pulse = (t, a, b) =>
  t < a || t > b ? 0 : Math.sin((Math.PI * (t - a)) / (b - a)) ** 2;
export function childState(actor, tick) {
  const p = stateAtTick(tick, actor.delay),
    t = tick / FPS;
  if (actor.role === 'toddler')
    p.headYaw += 0.48 * (pulse(t, 9, 10.2) + pulse(t, 41, 42.2));
  if (actor.role === 'girl') {
    const weight = Math.max(pulse(t, 7, 9), pulse(t, 39, 41));
    p.rightHand = p.rightHand.map(
      (v, i) => v + ([0.2, p.head[1] - 0.03, p.head[2] - 0.1][i] - v) * weight,
    );
  }
  if (actor.role === 'beads') {
    Object.assign(p, {
      hipY: 0.25,
      hipZ: 0,
      lean: 0,
      headPitch: 0,
      headYaw: 0,
      kneeY: 0.09,
      kneeZ: -0.16,
      heelL: 0,
      heelR: 0,
      handPitch: 0,
      index: 0,
      pose: 'cross-legged',
      beads: true,
    });
    p.hip = [0, 0.25, 0];
    p.shoulder = [0, 0.25 + TORSO_LENGTH, 0];
    p.head = [0, 0.25 + HEAD_REACH, 0];
    p.leftHand = [-0.07, 0.46, -0.18];
    p.rightHand = [0.07 + 0.012 * Math.sin(t * 1.4), 0.46, -0.18];
  }
  if (actor.role === 'tag') {
    const angle = (t * Math.PI) / 12 + (actor.phase ?? 0),
      duck = 0.22 * pulse((t + (actor.phase ?? 0) * 2) % 24, 8, 12);
    Object.assign(p, {
      hipY: 0.94 - duck,
      hipZ: 0,
      lean: 0.06,
      headPitch: 0,
      headYaw: 0,
      kneeY: 0.5 - duck * 0.45,
      kneeZ: -0.02,
      heelL: 0.7,
      heelR: 0.7,
      handPitch: 0,
      index: 0,
      pose: 'tiptoe',
      walking: true,
    });
    p.hip = [0, p.hipY, 0];
    p.shoulder = [0, p.hipY + TORSO_LENGTH, -0.03];
    p.head = [0, p.hipY + HEAD_REACH, -0.04];
    p.leftHand = [-0.25, p.hipY + 0.12, -0.06 + 0.06 * Math.sin(t * 3)];
    p.rightHand = [0.25, p.hipY + 0.12, -0.06 - 0.06 * Math.sin(t * 3)];
    p.x = 4.85 + 0.62 * Math.cos(angle);
    p.z = 8.6 + 0.82 * Math.sin(angle);
    p.yaw = Math.atan2(0.62 * Math.sin(angle), -0.82 * Math.cos(angle));
    p.gait = Math.sin(t * 3);
  }
  return p;
}
