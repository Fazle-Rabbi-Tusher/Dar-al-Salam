// Procedural placeholder art for the modern district: architecture, interiors and street furniture.
// Content rule: no text, numerals, logos, calligraphy or religious symbols anywhere in this art.
import { Pixels, type PixelImage } from '../../packages/shared/pixels';
import { png, readJson, writeJson } from '../build/io';
import type { ObjectArt } from './objects';
import {
  darker,
  detailPass,
  groundShadow,
  lighter,
  isoCanvas,
  mirror,
  type DetailOptions,
  type IsoCanvas,
  type Material,
} from './iso-draw';

/** Every colour this module paints. Keys are descriptive; values are the palette. */
const C = {
  edge: '#493C35',
  ink: '#2A2E33',
  charcoal: '#3A3F44',
  slate: '#5E6668',
  grey: '#8E9796',
  silver: '#B9C0BE',
  pale: '#DADFDC',
  offwhite: '#EEF0EC',
  white: '#FBFBF7',
  ivory: '#F5EEDB',
  paper: '#EDE6CE',
  stone: '#D7DCD2',
  stoneShade: '#B5C3BA',
  stoneLine: '#8B9D96',
  steelLight: '#E2E6E8',
  steel: '#B8C0C6',
  steelDark: '#88939B',
  glassLight: '#CDE9F2',
  glass: '#9FD0E3',
  glassDark: '#6BAAC6',
  glassDeep: '#4A87A8',
  teal: '#4FB3A9',
  tealDark: '#2E8C86',
  turquoise: '#79B6B2',
  deepTeal: '#377D79',
  mint: '#B7E4D3',
  mintDark: '#7FC7AE',
  red: '#E05A4F',
  redDark: '#B23A35',
  orange: '#F08A3C',
  orangeDark: '#C2632A',
  yellow: '#F5C842',
  yellowDark: '#C99A22',
  gold: '#D8AD57',
  green: '#5DBB63',
  greenDark: '#3A8C48',
  lime: '#A6D65A',
  blue: '#3E7DD8',
  blueDark: '#2A57A0',
  navy: '#243A66',
  purple: '#8A63C9',
  purpleDark: '#5E3F96',
  pink: '#EE8FB0',
  pinkDark: '#C2607F',
  woodLight: '#E0B98A',
  wood: '#C08A5A',
  woodDark: '#8A5A36',
  oak: '#D9A86C',
  carpet: '#9E2F3A',
  carpetDark: '#7A1F2B',
  carpetGreen: '#2F6E4F',
  carpetGreenDark: '#1F4F38',
  carpetGold: '#E8C77A',
  terracotta: '#C9704E',
  terracottaDark: '#9C4E33',
  terracottaLight: '#E0916A',
  asphalt: '#5B5F63',
  asphaltDark: '#474A4E',
  asphaltLight: '#6C7176',
  screen: '#1E2A3A',
  glow: '#7FE3D2',
  beat: '#6CF08A',
  leafLight: '#8CC46A',
  leaf: '#5E9E4A',
  leafDark: '#3F7A3A',
  trunk: '#7A5638',
  soil: '#6B4A33',
  concrete: '#E6E4DE',
  concreteShade: '#CFCCC3',
  concreteLine: '#BDB9AE',
  warmGrey: '#C9C3B8',
  warmGreyLight: '#DAD5CB',
  warmGreyDark: '#A9A296',
  labTile: '#F4F6F5',
  labLine: '#D3DBD8',
  vinyl: '#CDEBDF',
  vinylLight: '#DDF2EA',
  vinylDark: '#A9D6C4',
  water: '#A3CFBE',
  waterLight: '#D4EEF0',
  rice: '#F3E3A6',
  cream: '#F7EBD0',
  // Football stadium.
  pitchLight: '#74B95B',
  pitch: '#5FA64C',
  pitchDark: '#4A8B3E',
  line: '#F4F7EE',
  net: '#D9DEDA',
  netShade: '#AEB6B2',
  fanSkin1: '#E5BF92',
  fanSkin2: '#BA8D63',
  fanSkin3: '#875E42',
  fanSkin4: '#593E30',
  fanHair: '#3B322E',
  lamp: '#FFF6C8',
  lampGlow: '#FFE88A',
  seatGrey: '#9AA3A6',
  // New York City and the Michigan rally.
  limestoneLight: '#EFE3C6',
  limestone: '#D6C49C',
  limestoneDark: '#B39E74',
  windowLit: '#FFE29A',
  brownstoneLight: '#A8644C',
  brownstone: '#85493A',
  brownstoneDark: '#62352B',
  brickLight: '#C9674B',
  brick: '#AE4F3A',
  brickDark: '#86392C',
  taxiShade: '#B98A1F',
  stageNavy: '#1D2E55',
  // Garden grass and water (already in the world palette).
  grassLight: '#C1C7A2',
  grass: '#A3B086',
  grassMid: '#75966B',
  grassDark: '#487359',
  // Bangladesh block (all already in the world palette).
  creamShade: '#E4D5B9',
  rose: '#EBAAB6',
  sand: '#DCCBAA',
  sandShade: '#C8B99C',
  sandDark: '#B69872',
  clay: '#B08A6E',
  flagRed: '#C93A3A',
} as const;
/** Colours for the nature pass (trees, water, rocks): add here, not to C. */
const NC = {
  // Broadleaf foliage, light to dark.
  leaf0: '#B5DA6A',
  leaf1: '#86C14F',
  leaf2: '#5FA23F',
  leaf3: '#3F8036',
  leaf4: '#2B5E33',
  leaf5: '#1C3F2C',
  // Oak: warmer, olive greens.
  oak0: '#A9C95B',
  oak1: '#7EAE47',
  oak2: '#5A8E3C',
  oak3: '#3E6E34',
  oak4: '#2A4F2D',
  oak5: '#1A3424',
  // Pine: cool blue-greens.
  pine0: '#8FBF7A',
  pine1: '#5E9A66',
  pine2: '#3F7A57',
  pine3: '#2B5C47',
  pine4: '#1C4236',
  pine5: '#122D27',
  // Cherry blossom.
  blossom0: '#FCE8EE',
  blossom1: '#F6C9D6',
  blossom2: '#EBA3BA',
  blossom3: '#D07F9C',
  blossom4: '#A85F80',
  blossom5: '#764563',
  // Birch: light yellow-greens.
  birch0: '#D8E98A',
  birch1: '#B4D46A',
  birch2: '#8DBA52',
  birch3: '#6A9A44',
  birch4: '#4A7536',
  // Bark.
  bark0: '#A4805A',
  bark1: '#7E5C3E',
  bark2: '#5A402C',
  bark3: '#3A2A1F',
  birchBark0: '#F2EFE6',
  birchBark1: '#D4CFC2',
  birchMark: '#3A3530',
  palm0: '#B89565',
  palm1: '#957347',
  palm2: '#6F5434',
  coconut: '#6E4A2C',
  // Blue-grey rock and moss.
  rock0: '#B9C3CE',
  rock1: '#8F9BAA',
  rock2: '#6B7787',
  rock3: '#4D5868',
  rock4: '#353E4C',
  rock5: '#232A35',
  moss0: '#7FA04A',
  moss1: '#5C8040',
  moss2: '#3F6436',
  // Falling water and foam, bright to deep.
  water0: '#F4FCFF',
  water1: '#CFEFFA',
  water2: '#9DD7EE',
  water3: '#62AFD6',
  water4: '#3D86B5',
  water5: '#2A628C',
  water6: '#1D4566',
  // Sea.
  sea0: '#E9F6FB',
  sea1: '#9CCDE6',
  sea2: '#5E9DC9',
  sea3: '#3B76A8',
  sea4: '#285887',
  sea5: '#1B3F66',
  // Ship: sailcloth and hull.
  sail0: '#F7F4EA',
  sail1: '#E2DCCB',
  sail2: '#C4BCA7',
  sail3: '#9E957F',
  hull0: '#B07A4A',
  hull1: '#6B4426',
  hull2: '#4A2E1A',
} as const;
/** Colours for the city pass (towers, lights, street furniture). */
const CC: Record<string, string> = {
  nightGlass: '#1D2E55',
  duskGlass: '#2A3552',
  skyGlass: '#36557A',
  skyGlassLight: '#46709F',
  amberLit: '#F7A653',
  blossomLight: '#F8D3DD',
  blossom: '#D07A8D',
  blossomDeep: '#A4536A',
};
export const MODERN_COLOURS: string[] = [
  ...new Set([...Object.values(C), ...Object.values(NC), ...Object.values(CC)]),
];

type Ramp = [string, string, string];
const M = {
  white: { top: C.white, front: C.offwhite, side: C.pale, edge: C.silver },
  stone: {
    top: C.ivory,
    front: C.stone,
    side: C.stoneShade,
    edge: C.stoneLine,
  },
  steel: {
    top: C.steelLight,
    front: C.steel,
    side: C.steelDark,
    edge: C.slate,
  },
  dark: { top: C.slate, front: C.charcoal, side: C.ink, edge: C.ink },
  wood: { top: C.woodLight, front: C.wood, side: C.woodDark, edge: C.woodDark },
  oak: { top: C.oak, front: C.wood, side: C.woodDark, edge: C.woodDark },
  concrete: {
    top: C.concrete,
    front: C.concreteShade,
    side: C.concreteLine,
    edge: C.grey,
  },
  teal: { top: C.teal, front: C.tealDark, side: C.deepTeal, edge: C.deepTeal },
  orange: {
    top: C.orange,
    front: C.orangeDark,
    side: C.terracottaDark,
    edge: C.edge,
  },
} satisfies Record<string, Material>;
const R = {
  leaf: [C.leafLight, C.leaf, C.leafDark] as Ramp,
  steel: [C.steelLight, C.steel, C.steelDark] as Ramp,
  white: [C.white, C.offwhite, C.pale] as Ramp,
  stone: [C.ivory, C.stone, C.stoneShade] as Ramp,
  teal: [C.teal, C.tealDark, C.deepTeal] as Ramp,
  terracotta: [C.terracottaLight, C.terracotta, C.terracottaDark] as Ramp,
  dark: [C.slate, C.charcoal, C.ink] as Ramp,
  glass: [C.glassLight, C.glass, C.glassDark] as Ramp,
  blue: [C.glass, C.blue, C.blueDark] as Ramp,
};
const accents = [
  C.red,
  C.blue,
  C.yellow,
  C.green,
  C.purple,
  C.orange,
  C.teal,
  C.pink,
  C.navy,
];

type Spec = {
  footprint: [number, number];
  /** Tallest point above the floor, in pixels. */
  h: number;
  pad?: number;
  frames?: number;
  /** Frames per animation cycle on the 240-frame master clock (default 60). */
  period?: number;
  floor?: boolean;
  side?: boolean;
  /** Finishing pass options; `false` leaves the art exactly as drawn. */
  detail?: DetailOptions | false;
  /** Soft ground shadow under the footprint (off for raised pieces). */
  shadow?: boolean;
  draw: (c: IsoCanvas, f: number) => void;
};

/** Small helper: a stick of a given colour between two tile-space points. */
function post(
  c: IsoCanvas,
  x: number,
  y: number,
  z: number,
  h: number,
  col: string,
  w = 1,
) {
  const [px, py] = c.at(x, y, z);
  c.p.rect(px, py - h, w, h, col);
}
function screen(
  c: IsoCanvas,
  x: number,
  y: number,
  w: number,
  z: number,
  h: number,
  f = 0,
) {
  c.faceX(x, y, w, z, h, C.ink);
  c.faceX(x + 0.04, y + 0.01, w - 0.08, z + 2, h - 4, C.screen);
  const n = Math.max(2, Math.floor(w * 7));
  for (let i = 0; i < n; i++) {
    const bh = 2 + ((i * 5 + f * 3) % Math.max(3, h - 9));
    c.faceX(
      x + 0.1 + (i * (w - 0.2)) / n,
      y + 0.02,
      Math.max(0.05, (w - 0.2) / n - 0.04),
      z + 4,
      Math.min(bh, h - 8),
      accents[(i + f) % accents.length],
    );
  }
}
function shoe(c: IsoCanvas, x: number, y: number, z: number, col: string) {
  const [px, py] = c.at(x, y, z);
  c.p.rect(px, py - 2, 4, 2, col);
  c.p.rect(px + 5, py - 1, 4, 2, col);
  c.p.pixel(px, py - 2, C.white);
  c.p.pixel(px + 5, py - 1, C.white);
}
function book(
  c: IsoCanvas,
  x: number,
  y: number,
  z: number,
  h: number,
  col: string,
) {
  const [px, py] = c.at(x, y, z);
  c.p.rect(px, py - h, 2, h, col);
  c.p.pixel(px, py - h + 1, C.white);
}
function wallBase(c: IsoCanvas, h: number, m: Material, depth = 0.35) {
  c.box(0, 0, 8, depth, h, m);
}
/**
 * Block courses (ashlar, brick, panels) on a front (+y) face between x0 and
 * x1: joint lines every `row` px, staggered head joints every `block` tiles,
 * and an optional lit line along the top of each block.
 */
function coursesFront(
  c: IsoCanvas,
  x0: number,
  x1: number,
  y: number,
  z0: number,
  z1: number,
  row: number,
  block: number,
  joint: string,
  light?: string,
) {
  for (let z = z0, r = 0; z < z1; z += row, r++) {
    const top = Math.min(z + row, z1);
    if (light && top - z > 3) c.edge([x0, y, top - 1], [x1, y, top - 1], light);
    if (z > z0) c.edge([x0, y, z], [x1, y, z], joint);
    for (let u = x0 + block * (r % 2 ? 0.5 : 1); u < x1 - 0.04; u += block)
      c.edge([u, y, z], [u, y, top - 1], joint);
  }
}
/** The same courses on a side (+x) face between y0 and y1. */
function coursesSide(
  c: IsoCanvas,
  x: number,
  y0: number,
  y1: number,
  z0: number,
  z1: number,
  row: number,
  block: number,
  joint: string,
  light?: string,
) {
  for (let z = z0, r = 0; z < z1; z += row, r++) {
    const top = Math.min(z + row, z1);
    if (light && top - z > 3) c.edge([x, y0, top - 1], [x, y1, top - 1], light);
    if (z > z0) c.edge([x, y0, z], [x, y1, z], joint);
    for (let v = y0 + block * (r % 2 ? 0.5 : 1); v < y1 - 0.04; v += block)
      c.edge([x, v, z], [x, v, top - 1], joint);
  }
}
type Sash = {
  frame: string;
  glass: string;
  /** Shadow cast into the reveal by the head and the left jamb. */
  shade: string;
  glint?: string;
  sill?: string;
  /** Glazing bars: a cross for sash windows. */
  bars?: boolean;
  /** Something seen inside (curtain, plant, lamp), drawn low in the pane. */
  inside?: string;
};
/** A framed window with reveal shadow, glint, glazing bars and sill on a front face. */
function sashFront(
  c: IsoCanvas,
  x: number,
  y: number,
  w: number,
  z: number,
  h: number,
  o: Sash,
) {
  c.faceX(x - 0.03, y, w + 0.06, z - 1, h + 2, o.frame);
  c.faceX(x, y + 0.001, w, z, h, o.glass);
  c.faceX(x, y + 0.002, w, z + h - 2, 2, o.shade);
  c.faceX(x, y + 0.002, Math.min(0.05, w * 0.2), z, h, o.shade);
  if (o.inside)
    c.faceX(x + w * 0.55, y + 0.002, w * 0.4, z, h * 0.45, o.inside);
  if (o.glint)
    c.edge(
      [x + w * 0.25, y + 0.003, z + 2],
      [x + w * 0.6, y + 0.003, z + h - 3],
      o.glint,
    );
  if (o.bars) {
    c.edge(
      [x + w / 2, y + 0.003, z],
      [x + w / 2, y + 0.003, z + h - 1],
      o.frame,
    );
    c.edge([x, y + 0.003, z + h / 2], [x + w, y + 0.003, z + h / 2], o.frame);
  }
  if (o.sill) c.faceX(x - 0.05, y + 0.004, w + 0.1, z - 2, 2, o.sill);
}
/** The same window on a side (+x) face. */
function sashSide(
  c: IsoCanvas,
  x: number,
  y: number,
  w: number,
  z: number,
  h: number,
  o: Sash,
) {
  c.faceY(x, y - 0.03, w + 0.06, z - 1, h + 2, o.frame);
  c.faceY(x + 0.001, y, w, z, h, o.glass);
  c.faceY(x + 0.002, y, w, z + h - 2, 2, o.shade);
  c.faceY(x + 0.002, y, Math.min(0.05, w * 0.2), z, h, o.shade);
  if (o.inside) c.faceY(x + 0.002, y + w * 0.5, w * 0.4, z, h * 0.45, o.inside);
  if (o.glint)
    c.edge(
      [x + 0.003, y + w * 0.25, z + 2],
      [x + 0.003, y + w * 0.6, z + h - 3],
      o.glint,
    );
  if (o.bars) {
    c.edge(
      [x + 0.003, y + w / 2, z],
      [x + 0.003, y + w / 2, z + h - 1],
      o.frame,
    );
    c.edge([x + 0.003, y, z + h / 2], [x + 0.003, y + w, z + h / 2], o.frame);
  }
  if (o.sill) c.faceY(x + 0.004, y - 0.05, w + 0.1, z - 2, 2, o.sill);
}
/**
 * Pointed arch window on a front (+y) or side (+x) face at `at`: frame,
 * glass, reveal shade down the left jamb, and a glint.
 */
function arch(
  c: IsoCanvas,
  side: boolean,
  u: number,
  at: number,
  w: number,
  z: number,
  h: number,
  frame: string,
  glass: string,
  shade: string,
  glint: string,
) {
  const pt = (a: number, d: number, zz: number): [number, number, number] =>
      side ? [at + d, a, zz] : [a, at + d, zz],
    rise = Math.min(12, h * 0.3);
  c.poly(
    [
      pt(u - 0.08, 0, z - 2),
      pt(u + w + 0.08, 0, z - 2),
      pt(u + w + 0.08, 0, z + h - rise),
      pt(u + w / 2, 0, z + h + 3),
      pt(u - 0.08, 0, z + h - rise),
    ],
    frame,
  );
  c.poly(
    [
      pt(u, 0.001, z),
      pt(u + w, 0.001, z),
      pt(u + w, 0.001, z + h - rise),
      pt(u + w / 2, 0.001, z + h),
      pt(u, 0.001, z + h - rise),
    ],
    glass,
  );
  c.edge(pt(u + 0.01, 0.002, z), pt(u + 0.01, 0.002, z + h - rise), shade);
  c.edge(pt(u + 0.01, 0.002, z + h - rise), pt(u + w / 2, 0.002, z + h), shade);
  c.edge(
    pt(u + w * 0.3, 0.003, z + 3),
    pt(u + w * 0.6, 0.003, z + h * 0.6),
    glint,
  );
}

/** Warm village architecture shares the existing cutaway wall footprints. */
function villageFlowerBox(
  c: IsoCanvas,
  x: number,
  y: number,
  z: number,
  w: number,
  seed = 0,
) {
  c.box(x, y, w, 0.23, 5, M.wood, z);
  c.faceX(x + 0.02, y + 0.231, w - 0.04, z + 1, 1, C.woodDark);
  c.edge([x, y + 0.232, z + 4], [x + w, y + 0.232, z + 4], C.woodLight);
  for (let i = 0; i < Math.ceil(w * 17); i++) {
    const u = x + 0.03 + (((i * 11 + seed * 3) % 31) / 31) * (w - 0.06);
    const [px, py] = c.at(u, y + 0.12, z + 7 + (i % 3));
    c.p.ellipse(px, py, 3, 2, i % 3 ? NC.leaf3 : NC.leaf1);
    if (i % 2) {
      const col = [C.terracottaLight, C.pink, C.ivory, C.yellow][
        (i + seed) % 4
      ];
      c.p.rect(px, py - 2, 2, 2, col);
      c.p.pixel(px + 1, py - 1, C.yellow);
    }
    if (i % 5 === 0)
      c.edge(
        [u, y + 0.24, z + 5],
        [u + 0.05, y + 0.24, z - 3 - (i % 4)],
        NC.leaf3,
      );
  }
}

/** A narrow tiled overhang, leaving every occupied room open to the viewer. */
function villageEaves(c: IsoCanvas, w: number, z: number) {
  const back = -0.2,
    front = 0.66;
  c.poly(
    [
      [-0.18, back, z + 7],
      [w + 0.18, back, z + 7],
      [w + 0.18, front, z],
      [-0.18, front, z],
    ],
    C.terracotta,
  );
  for (let row = 0; row < 4; row++) {
    const y = back + (row * (front - back)) / 4,
      h = z + 7 - (row * 7) / 4;
    c.edge(
      [-0.18, y, h],
      [w + 0.18, y, h],
      row % 2 ? C.terracottaDark : C.terracottaLight,
    );
    for (let x = -0.18 + (row % 2) * 0.17; x < w + 0.18; x += 0.34) {
      c.edge(
        [x, y, h],
        [x, y + (front - back) / 4, h - 7 / 4],
        C.terracottaDark,
      );
      c.edge(
        [x + 0.035, y, h],
        [x + 0.035, y + 0.15, h - 1.2],
        C.terracottaLight,
      );
    }
  }
  c.faceX(-0.19, front + 0.01, w + 0.38, z - 3, 3, C.woodDark);
  c.edge(
    [-0.19, front + 0.02, z],
    [w + 0.19, front + 0.02, z],
    C.terracottaLight,
  );
  for (let x = 0.1; x < w; x += 0.8)
    c.edge([x, 0.37, z - 9], [x, front, z - 3], C.wood);
}

function villageWall(c: IsoCanvas, glazed = false) {
  wallBase(c, 92, {
    top: C.cream,
    front: C.ivory,
    side: C.creamShade,
    edge: C.woodDark,
  });
  c.faceX(0, 0.351, 8, 0, 15, C.sandShade);
  coursesFront(c, 0, 8, 0.352, 0, 15, 5, 0.52, C.clay, C.sand);
  // Small hand-laid stones and worn lime plaster, all from the locked palette.
  for (let i = 0; i < 92; i++) {
    const x = ((i * 29) % 157) / 20,
      z = 17 + ((i * 19) % 72);
    c.faceX(
      x,
      0.352,
      0.05 + (i % 3) * 0.03,
      z,
      1,
      i % 3 ? C.paper : C.creamShade,
    );
  }
  c.faceX(0, 0.353, 8, 15, 4, C.woodDark);
  c.edge([0, 0.354, 19], [8, 0.354, 19], C.woodLight);
  for (let x = 0; x <= 8; x += 2) {
    c.faceX(Math.min(x, 7.88), 0.355, 0.12, 15, 77, C.woodDark);
    c.edge(
      [Math.min(x, 7.88) + 0.025, 0.356, 20],
      [Math.min(x, 7.88) + 0.025, 0.356, 91],
      C.wood,
    );
  }
  for (let bay = 0; bay < 4; bay++) {
    const x = bay * 2 + 0.48,
      y = 0.357;
    const w = glazed ? 1.2 : 1.02,
      z = glazed ? 31 : 37,
      h = glazed ? 43 : 34;
    // Diagonal framing, carved sills and a recessed wooden sash.
    c.edge([bay * 2 + 0.18, y, 20], [bay * 2 + 0.55, y, 36], C.woodDark);
    c.edge([bay * 2 + 1.85, y, 20], [bay * 2 + 1.47, y, 36], C.woodDark);
    sashFront(c, x, y + 0.001, w, z, h, {
      frame: C.woodDark,
      glass: C.glassDeep,
      shade: C.navy,
      glint: C.glassLight,
      sill: C.woodLight,
      bars: true,
      inside: C.cream,
    });
    c.faceX(x + 0.07, y + 0.005, 0.12, z + 4, h - 7, C.paper);
    c.faceX(x + w - 0.2, y + 0.005, 0.12, z + 4, h - 7, C.paper);
    for (const u of [x - 0.22, x + w + 0.02]) {
      c.faceX(u, y + 0.006, 0.17, z + 1, h - 2, C.deepTeal);
      for (let j = 0; j < 4; j++)
        c.edge(
          [u + 0.02, y + 0.007, z + 5 + j * 7],
          [u + 0.15, y + 0.007, z + 5 + j * 7],
          C.turquoise,
        );
    }
    villageFlowerBox(c, x - 0.08, y + 0.015, z - 5, w + 0.16, bay);
    c.edge(
      [bay * 2 + 0.18, y + 0.008, 88],
      [bay * 2 + 0.54, y + 0.008, 77],
      C.woodDark,
    );
    c.edge(
      [bay * 2 + 1.85, y + 0.008, 88],
      [bay * 2 + 1.5, y + 0.008, 77],
      C.woodDark,
    );
  }
  c.faceX(0, 0.37, 8, 87, 5, C.woodDark);
  c.edge([0, 0.371, 88], [8, 0.371, 88], C.wood);
  villageEaves(c, 8, 93);
}

const objects: Record<string, Spec> = {
  'm-glasswall': {
    footprint: [8, 0.35],
    h: 100,
    side: true,
    draw(c) {
      villageWall(c, true);
    },
  },
  'm-whitewall': {
    footprint: [8, 0.35],
    h: 100,
    side: true,
    draw(c) {
      villageWall(c);
    },
  },
  'm-archwall': {
    footprint: [8, 0.35],
    h: 114,
    side: true,
    draw(c) {
      wallBase(c, 110, M.stone);
      // Dressed-stone courses, then a darker plinth with a lit top edge.
      coursesFront(c, 0, 8, 0.351, 8, 96, 8, 0.55, C.stoneShade, C.ivory);
      c.faceX(0, 0.351, 8, 0, 8, C.stoneShade);
      c.edge([0, 0.352, 8], [8, 0.352, 8], C.ivory);
      c.edge([0, 0.352, 1], [8, 0.352, 1], C.stoneLine);
      for (let i = 0; i < 4; i++) {
        const u = 0.55 + i * 2;
        // Recess shadow, frame, then the glazing.
        c.poly(
          [
            [u - 0.06, 0.352, 14],
            [u + 1.1, 0.352, 14],
            [u + 1.1, 0.352, 77],
            [u + 0.5, 0.352, 99],
            [u - 0.06, 0.352, 79],
          ],
          C.stoneShade,
        );
        c.poly(
          [
            [u - 0.12, 0.352, 16],
            [u + 1.02, 0.352, 16],
            [u + 1.02, 0.352, 78],
            [u + 0.45, 0.352, 96],
            [u - 0.12, 0.352, 78],
          ],
          C.tealDark,
        );
        c.poly(
          [
            [u, 0.353, 20],
            [u + 0.9, 0.353, 20],
            [u + 0.9, 0.353, 76],
            [u + 0.45, 0.353, 90],
            [u, 0.353, 76],
          ],
          C.glass,
        );
        c.faceX(u, 0.354, 0.9, 20, 28, C.glassDark);
        // Reveal shadow down the left jamb and under the arch.
        c.faceX(u, 0.354, 0.08, 20, 56, C.glassDeep);
        c.edge([u + 0.1, 0.354, 76], [u + 0.45, 0.354, 88], C.glassDeep);
        c.edge([u + 0.45, 0.355, 20], [u + 0.45, 0.355, 88], C.white);
        c.edge([u, 0.355, 50], [u + 0.9, 0.355, 50], C.white);
        c.edge([u, 0.355, 34], [u + 0.9, 0.355, 34], C.glass);
        c.edge([u + 0.14, 0.355, 56], [u + 0.32, 0.355, 74], C.glassLight);
        c.edge([u + 0.6, 0.355, 24], [u + 0.74, 0.355, 40], C.glassLight);
        // Keystone at the apex and a projecting sill with its shadow.
        c.box(u + 0.37, 0.33, 0.16, 0.06, 7, M.stone, 92);
        c.box(u - 0.15, 0.3, 1.2, 0.25, 3, M.stone, 14);
        c.faceX(u - 0.12, 0.552, 1.16, 11, 2, C.stoneShade);
        // Lattice panel between windows, framed and shadowed.
        if (i === 3) continue;
        c.faceX(u + 1.12, 0.352, 0.76, 28, 48, C.stoneShade);
        c.faceX(u + 1.15, 0.352, 0.7, 30, 44, C.ivory);
        for (let z = 34; z < 72; z += 6)
          for (let k = 0; k < 3; k++)
            c.top(u + 1.22 + k * 0.2, 0.352, 0.1, 0.01, z, C.turquoise);
        c.edge([u + 1.15, 0.353, 30], [u + 1.15, 0.353, 73], C.stoneLine);
      }
      // Cornice: dentil course under a teal frieze.
      c.faceX(0, 0.352, 8, 95, 5, C.stoneShade);
      for (let u = 0.04; u < 8; u += 0.22)
        c.faceX(u, 0.353, 0.13, 96, 3, C.ivory);
      c.faceX(0, 0.352, 8, 100, 4, C.teal);
      c.edge([0, 0.353, 103], [8, 0.353, 103], C.turquoise);
      c.box(-0.05, -0.05, 8.1, 0.45, 5, M.stone, 106);
      villageEaves(c, 8, 107);
      for (let i = 0; i < 4; i++)
        villageFlowerBox(c, 0.6 + i * 2, 0.36, 9, 1.1, i);
    },
  },
  'm-dome': {
    footprint: [4, 4],
    h: 140,
    draw(c) {
      c.box(0, 0, 4, 4, 40, M.stone);
      coursesFront(c, 0, 4, 4.001, 2, 32, 6, 0.6, C.stoneShade, C.ivory);
      coursesSide(c, 4.001, 0, 4, 2, 32, 6, 0.6, C.stoneLine);
      c.faceX(0, 4.001, 4, 0, 2, C.stoneShade);
      c.faceY(4.001, 0, 4, 0, 2, C.stoneLine);
      // Arched windows around the prayer-hall base.
      for (let k = 0; k < 4; k++) {
        arch(
          c,
          false,
          0.3 + k * 0.95,
          4.002,
          0.36,
          8,
          18,
          C.tealDark,
          C.glassDark,
          C.glassDeep,
          C.glassLight,
        );
        arch(
          c,
          true,
          0.3 + k * 0.95,
          4.002,
          0.36,
          8,
          18,
          C.deepTeal,
          C.glassDeep,
          C.ink,
          C.glass,
        );
      }
      c.faceX(0, 4.001, 4, 32, 4, C.teal);
      c.faceY(4.001, 0, 4, 32, 4, C.deepTeal);
      c.edge([0, 4.002, 35], [4, 4.002, 35], C.turquoise);
      c.edge([0, 4.002, 36], [4, 4.002, 36], C.ivory);
      const [cx, cy] = c.at(2, 2, 40);
      // Drum: stone ring with tall arched lights.
      c.cylinder(2, 2, 40, 40, 26, R.stone, C.ivory);
      for (let k = 0; k < 9; k++) {
        const u = -0.85 + k * 0.21,
          x = cx + u * 40,
          y = cy + 20 * Math.sqrt(1 - u * u);
        c.p.rect(x - 3, y - 21, 6, 14, u < 0.3 ? C.stoneShade : C.stoneLine);
        c.p.rect(x - 2, y - 20, 4, 12, C.glassDark);
        c.p.rect(x - 1, y - 22, 2, 2, C.glassDark);
        c.p.rect(x - 1, y - 19, 1, 6, C.glassLight);
        c.p.rect(x + 1, y - 9, 1, 1, C.glassDeep);
      }
      c.p.ellipse(cx, cy - 26, 41, 20, C.teal);
      c.p.ellipse(cx, cy - 27, 39, 19, C.tealDark);
      // Shallow dome, softly dithered from the lit upper left.
      const top = cy - 26;
      for (let j = top - 64; j <= top; j++)
        for (let i = cx - 38; i <= cx + 38; i++) {
          const u = (i - cx) / 38,
            v = (top - j) / 64;
          if (u * u + v * v > 1) continue;
          const shade = u - v * 0.4 + ((i + j) % 2 ? 0.05 : -0.05);
          c.p.pixel(
            i,
            j,
            shade < -0.5
              ? C.white
              : shade < 0.12
                ? C.offwhite
                : shade < 0.5
                  ? C.pale
                  : shade < 0.8
                    ? C.silver
                    : C.stoneLine,
          );
        }
      // Ribs, lighter on the lit side.
      for (let k = 1; k < 8; k++) {
        const u = -0.9 + k * 0.225;
        for (let j = top - 62; j <= top; j++) {
          const v = (top - j) / 64,
            w = Math.sqrt(Math.max(0, 1 - v * v));
          c.p.pixel(cx + u * 38 * w, j, u < -0.2 ? C.pale : C.stoneShade);
        }
      }
      // Specular highlight high on the lit side.
      c.p.ellipse(cx - 16, top - 44, 5, 8, C.white);
      c.p.ellipse(cx, top, 38, 4, C.tealDark);
      c.p.ellipse(cx, top + 1, 36, 3, C.deepTeal);
      // Plain finial: drum, rod and knob.
      c.p.rect(cx - 4, top - 65, 8, 3, C.pale);
      c.p.rect(cx - 2, top - 70, 4, 7, C.gold);
      c.p.rect(cx + 1, top - 70, 1, 7, darker(C.gold));
      c.p.ellipse(cx, top - 71, 3, 3, C.gold);
      c.p.pixel(cx - 1, top - 72, C.yellow);
    },
  },
  'm-minaret': {
    footprint: [1, 1],
    h: 240,
    draw(c) {
      c.box(0, 0, 1, 1, 10, M.stone);
      coursesFront(c, 0, 1, 1.001, 0, 10, 5, 0.34, C.stoneShade, C.ivory);
      coursesSide(c, 1.001, 0, 1, 0, 10, 5, 0.34, C.stoneLine);
      c.box(0.15, 0.15, 0.7, 0.7, 168, M.white, 10);
      coursesFront(c, 0.15, 0.85, 0.851, 10, 176, 8, 0.35, C.pale);
      coursesSide(c, 0.851, 0.15, 0.85, 10, 176, 8, 0.35, C.silver);
      for (const z of [60, 120]) {
        c.box(0.12, 0.12, 0.76, 0.76, 4, M.teal, z);
        c.edge([0.12, 0.882, z + 3], [0.88, 0.882, z + 3], C.turquoise);
      }
      for (const z of [24, 84, 140]) {
        arch(
          c,
          false,
          0.38,
          0.852,
          0.24,
          z,
          22,
          C.tealDark,
          C.glassDark,
          C.glassDeep,
          C.glassLight,
        );
        arch(
          c,
          true,
          0.38,
          0.852,
          0.24,
          z,
          22,
          C.deepTeal,
          C.glassDeep,
          C.ink,
          C.glass,
        );
      }
      // Stepped corbels carry the balcony.
      for (let k = 0; k < 3; k++)
        c.box(
          0.15 - k * 0.07,
          0.15 - k * 0.07,
          0.7 + k * 0.14,
          0.7 + k * 0.14,
          2,
          M.stone,
          170 + k * 2,
        );
      c.box(-0.05, -0.05, 1.1, 1.1, 5, M.stone, 176);
      c.edge([-0.05, 1.05, 180], [1.05, 1.05, 180], C.ivory);
      for (let u = 0; u <= 1.1; u += 0.18) {
        post(c, u - 0.05, 1.05, 181, 9, C.stoneLine);
        post(c, 1.05, u - 0.05, 181, 9, C.stoneShade);
      }
      c.box(-0.05, -0.05, 1.1, 1.1, 2, M.stone, 190);
      c.box(0.22, 0.22, 0.56, 0.56, 22, M.white, 181);
      arch(
        c,
        false,
        0.4,
        0.782,
        0.2,
        185,
        12,
        C.tealDark,
        C.glassDark,
        C.glassDeep,
        C.glassLight,
      );
      arch(
        c,
        true,
        0.4,
        0.782,
        0.2,
        185,
        12,
        C.deepTeal,
        C.glassDeep,
        C.ink,
        C.glass,
      );
      c.poly(
        [
          [0.2, 1.0, 203],
          [0.5, 0.5, 236],
          [1.0, 1.0, 203],
        ],
        C.teal,
      );
      c.poly(
        [
          [1.0, 1.0, 203],
          [0.5, 0.5, 236],
          [1.0, 0.2, 203],
        ],
        C.deepTeal,
      );
      // Tile courses on the roof cone and a lit ridge.
      for (let z = 208; z < 234; z += 5) {
        const t = (z - 203) / 33;
        c.edge(
          [0.2 + 0.3 * t, 1.0 - 0.5 * t, z],
          [1.0 - 0.5 * t, 1.0 - 0.5 * t, z],
          C.tealDark,
        );
        c.edge(
          [1.0 - 0.5 * t, 1.0 - 0.5 * t, z],
          [1.0 - 0.5 * t, 0.2 + 0.3 * t, z],
          C.ink,
        );
      }
      c.edge([1.0, 1.0, 203], [0.5, 0.5, 236], C.turquoise);
      c.box(0.2, 0.2, 0.8, 0.8, 3, M.stone, 200);
      const [x, y] = c.at(0.5, 0.5, 236);
      // Plain round knob (solid, so it never reads as a sign).
      c.p.rect(x, y - 4, 1, 3, darker(C.gold));
      c.p.rect(x - 1, y - 8, 3, 4, C.gold);
      c.p.pixel(x - 1, y - 8, C.yellow);
    },
  },
  'm-wudu': {
    footprint: [3, 1],
    h: 46,
    draw(c) {
      c.box(0, 0, 3, 0.25, 44, M.white);
      for (let u = 0; u < 3; u += 0.25)
        for (let z = 10; z < 44; z += 8)
          c.edge([u, 0.251, z], [u + 0.25, 0.251, z], C.labLine);
      c.faceX(0, 0.251, 3, 34, 6, C.turquoise);
      c.box(0, 0.25, 3, 0.4, 12, M.stone);
      c.top(0.08, 0.3, 2.84, 0.3, 12, C.water);
      c.edge([0.1, 0.45, 12], [2.9, 0.45, 12], C.waterLight);
      for (let i = 0; i < 4; i++) {
        const u = 0.35 + i * 0.75,
          [x, y] = c.at(u, 0.26, 26);
        c.p.rect(x, y, 3, 2, C.steel);
        c.p.rect(x + 2, y + 2, 1, 2, C.steelDark);
        c.p.pixel(x, y, C.white);
        c.p.rect(x + 2, y + 5, 1, 3 + i, C.glass);
        const [sx, sy] = c.at(u + 0.1, 0.82, 0);
        c.cylinder(u + 0.1, 0.82, 0, 4, 8, R.steel);
        c.p.pixel(sx - 2, sy - 9, C.white);
      }
    },
  },
  'm-shoe-rack': {
    footprint: [2, 0.6],
    h: 24,
    draw(c) {
      c.box(0, 0, 2, 0.6, 22, M.oak);
      for (let r = 0; r < 3; r++) {
        const z = 2 + r * 7;
        c.faceX(0.06, 0.601, 1.88, z, 5, C.woodDark);
        for (let i = 0; i < 4; i++)
          shoe(
            c,
            0.12 + i * 0.46,
            0.602,
            z,
            accents[(i + r * 3) % accents.length],
          );
      }
    },
  },
  'm-hall-carpet': {
    footprint: [10, 6],
    h: 2,
    floor: true,
    draw(c) {
      c.top(0, 0, 10, 6, 0, C.carpetDark);
      c.top(0.12, 0.12, 9.76, 5.76, 0, C.carpetGold);
      c.top(0.2, 0.2, 9.6, 5.6, 0, C.carpet);
      for (let x = 0.2; x < 9.8; x += 1.2)
        c.top(x, 0.2, 0.03, 5.6, 0, C.carpetDark);
      for (let y = 1.5; y < 6; y += 1.5) {
        c.top(0.2, y - 0.08, 9.6, 0.16, 0, C.carpetGreen);
        c.top(0.2, y - 0.03, 9.6, 0.06, 0, C.carpetGold);
      }
      for (let x = 0.4; x < 9.7; x += 0.4) {
        c.top(x, 0.04, 0.2, 0.05, 0, C.carpetGreen);
        c.top(x, 5.91, 0.2, 0.05, 0, C.carpetGreen);
      }
    },
  },
  'm-lab-bench': {
    footprint: [3, 1.5],
    h: 52,
    draw(c) {
      c.box(0, 0, 3, 1.5, 20, M.white);
      for (let u = 0.05; u < 3; u += 0.75) {
        c.edge([u, 1.501, 2], [u, 1.501, 19], C.silver);
        c.faceX(u + 0.3, 1.502, 0.15, 15, 1, C.steelDark);
      }
      c.faceY(3.001, 0, 1.5, 2, 16, C.pale);
      c.box(-0.03, -0.03, 3.06, 1.56, 2, M.dark, 20);
      // Microscope.
      c.box(0.3, 0.5, 0.4, 0.35, 3, M.white, 22);
      const [mx, my] = c.at(0.5, 0.6, 25);
      c.thick([mx + 2, my], [mx + 3, my - 14], 1, C.charcoal);
      c.thick([mx + 3, my - 14], [mx - 1, my - 19], 1, C.charcoal);
      c.p.rect(mx - 2, my - 19, 3, 6, C.steelDark);
      c.p.rect(mx - 2, my - 22, 3, 3, C.ink);
      c.p.rect(mx - 2, my - 6, 6, 1, C.steelDark);
      // Flasks with coloured liquid.
      for (const [x, y, col] of [
        [1.2, 0.5, C.purple],
        [1.5, 0.9, C.lime],
        [1.0, 1.0, C.orange],
      ] as [number, number, string][]) {
        const [fx, fy] = c.at(x, y, 22);
        c.p.poly(
          [
            [fx - 4, fy],
            [fx + 4, fy],
            [fx + 1, fy - 7],
            [fx - 1, fy - 7],
          ],
          C.glassLight,
        );
        c.p.poly(
          [
            [fx - 4, fy],
            [fx + 4, fy],
            [fx + 2, fy - 4],
            [fx - 2, fy - 4],
          ],
          col,
        );
        c.p.rect(fx - 1, fy - 11, 2, 4, C.glassLight);
        c.p.pixel(fx - 2, fy - 2, C.white);
      }
      // Test-tube rack.
      c.box(1.9, 0.4, 0.5, 0.2, 4, M.wood, 22);
      for (let i = 0; i < 4; i++) {
        const [tx, ty] = c.at(1.96 + i * 0.12, 0.5, 26);
        c.p.rect(tx, ty - 8, 2, 8, C.glassLight);
        c.p.rect(tx, ty - 3, 2, 3, [C.red, C.blue, C.yellow, C.green][i]);
      }
      // Monitor.
      c.box(2.5, 0.2, 0.2, 0.15, 6, M.dark, 22);
      screen(c, 2.25, 0.3, 0.7, 28, 22);
    },
  },
  'm-fume-hood': {
    footprint: [2, 1],
    h: 92,
    draw(c) {
      c.box(0, 0, 2, 1, 30, M.white);
      c.edge([1, 1.001, 2], [1, 1.001, 28], C.silver);
      c.box(0, 0, 2, 1, 56, M.steel, 30);
      c.faceX(0.12, 1.001, 1.76, 34, 36, C.mint);
      c.faceX(0.12, 1.001, 1.76, 58, 12, C.glow);
      for (let i = 0; i < 5; i++) {
        const [bx, by] = c.at(0.3 + i * 0.32, 1.002, 34);
        c.p.rect(bx, by - 10 - (i % 2) * 3, 3, 10 + (i % 2) * 3, accents[i]);
        c.p.rect(bx + 1, by - 13 - (i % 2) * 3, 1, 3, C.glassLight);
      }
      c.edge([0.2, 1.003, 40], [0.6, 1.003, 66], C.white);
      c.faceX(0.12, 1.003, 1.76, 70, 2, C.steelDark);
      c.box(0.6, 0.3, 0.8, 0.4, 6, M.steel, 86);
    },
  },
  'm-robot-arm': {
    footprint: [1, 1],
    h: 70,
    frames: 4,
    draw(c, f) {
      c.box(0.15, 0.15, 0.7, 0.7, 6, M.dark);
      c.cylinder(0.5, 0.5, 6, 9, 10, [
        C.orange,
        C.orangeDark,
        C.terracottaDark,
      ]);
      const swing = [0, 2, 4, 2][f];
      const [bx, by] = c.at(0.5, 0.5, 16);
      const elbow: [number, number] = [bx - 6 + swing, by - 26];
      const wrist: [number, number] = [bx + 12 + swing * 1.5, by - 34 + swing];
      c.thick([bx, by], elbow, 3, C.orangeDark);
      c.thick([bx - 1, by - 1], [elbow[0] - 1, elbow[1]], 2, C.orange);
      c.thick(elbow, wrist, 2.5, C.orangeDark);
      c.thick(
        [elbow[0], elbow[1] - 1],
        [wrist[0], wrist[1] - 1],
        1.5,
        C.orange,
      );
      c.p.ellipse(elbow[0], elbow[1], 4, 4, C.charcoal);
      c.p.ellipse(elbow[0], elbow[1], 2, 2, C.silver);
      c.p.ellipse(wrist[0], wrist[1], 3, 3, C.charcoal);
      c.p.rect(wrist[0] + 2, wrist[1] - 1, 2, 7, C.steel);
      c.p.rect(wrist[0] - 2, wrist[1] + 2, 2, 6, C.steel);
      c.p.pixel(bx - 2, by - 5, C.yellow);
    },
  },
  'm-server-rack': {
    footprint: [1, 1],
    h: 92,
    frames: 4,
    draw(c, f) {
      c.box(0.1, 0.1, 0.8, 0.8, 90, M.dark);
      for (let k = 0; k < 10; k++) {
        const z = 6 + k * 8;
        c.faceX(0.14, 0.901, 0.72, z, 6, C.ink);
        for (let i = 0; i < 5; i++) {
          const on = (k * 3 + i * 5 + f) % 4 !== 0;
          const [lx, ly] = c.at(0.2 + i * 0.12, 0.902, z + 3);
          c.p.pixel(
            lx,
            ly,
            on ? [C.beat, C.glow, C.yellow, C.blue][(k + i) % 4] : C.slate,
          );
        }
        c.edge([0.84, 0.902, z + 1], [0.84, 0.902, z + 5], C.slate);
      }
      c.faceY(0.901, 0.1, 0.8, 2, 86, C.charcoal);
      for (let z = 8; z < 88; z += 6)
        c.edge([0.902, 0.2, z], [0.902, 0.8, z], C.ink);
    },
  },
  'm-computer-desk': {
    footprint: [2, 1],
    h: 52,
    draw(c) {
      for (const [x, y] of [
        [0.05, 0.05],
        [1.85, 0.05],
        [0.05, 0.85],
        [1.85, 0.85],
      ])
        c.box(x, y, 0.1, 0.1, 20, M.steel);
      c.box(0, 0, 2, 1, 2, M.oak, 20);
      // Potted plant.
      c.pot(0.25, 0.25, 22, 3, 5, R.white, C.soil);
      c.greenery(0.25, 0.25, 34, 6, R.leaf);
      // Monitor and keyboard.
      c.box(0.95, 0.2, 0.15, 0.1, 6, M.dark, 22);
      screen(c, 0.55, 0.32, 0.95, 26, 24);
      c.top(0.6, 0.55, 0.7, 0.18, 22, C.charcoal);
      for (let u = 0.65; u < 1.25; u += 0.1)
        c.top(u, 0.58, 0.06, 0.12, 22.5, C.slate);
      c.top(1.4, 0.6, 0.12, 0.18, 22, C.white);
      // Mug.
      c.cylinder(1.75, 0.55, 22, 2, 5, [C.red, C.red, C.redDark]);
    },
  },
  'm-whiteboard': {
    footprint: [2, 0.3],
    h: 76,
    draw(c) {
      for (const u of [0.15, 1.85]) {
        c.box(u - 0.05, 0.05, 0.1, 0.2, 72, M.steel);
        c.box(u - 0.15, -0.05, 0.3, 0.4, 2, M.steel);
      }
      c.faceX(-0.05, 0.25, 2.1, 30, 42, C.slate);
      c.faceX(0, 0.251, 2, 32, 38, C.white);
      const pt = (u: number, z: number) => c.at(u, 0.252, z);
      // Molecule: circles linked by bonds.
      const atoms: [number, number, string][] = [
        [0.3, 56, C.red],
        [0.6, 62, C.charcoal],
        [0.9, 55, C.blue],
        [0.6, 46, C.charcoal],
        [0.35, 40, C.green],
      ];
      for (const [i, j] of [
        [0, 1],
        [1, 2],
        [1, 3],
        [3, 4],
      ])
        c.line(
          pt(atoms[i][0], atoms[i][1]),
          pt(atoms[j][0], atoms[j][1]),
          C.slate,
        );
      for (const [u, z, col] of atoms) {
        const [x, y] = pt(u, z);
        c.p.ellipse(x, y, 2, 2, col);
      }
      // Graph: axes and a rising line.
      c.line(pt(1.15, 36), pt(1.15, 64), C.charcoal);
      c.line(pt(1.15, 36), pt(1.9, 36), C.charcoal);
      let prev = pt(1.15, 38);
      for (let k = 1; k <= 6; k++) {
        const next = pt(1.15 + k * 0.12, 38 + k * 3 + (k % 2) * 3);
        c.line(prev, next, C.blue);
        prev = next;
      }
      c.faceX(0.2, 0.253, 0.5, 31, 1, C.red);
    },
  },
  'm-screen-wall': {
    footprint: [3, 0.3],
    h: 80,
    draw(c) {
      for (const u of [0.4, 2.6]) c.box(u - 0.06, 0.05, 0.12, 0.2, 40, M.dark);
      c.faceX(-0.05, 0.25, 3.1, 36, 42, C.ink);
      c.faceX(0.02, 0.251, 2.96, 38, 38, C.navy);
      for (let i = 0; i < 8; i++)
        c.faceX(
          0.15 + i * 0.16,
          0.252,
          0.1,
          42,
          6 + ((i * 7) % 22),
          accents[i],
        );
      let prev = c.at(1.6, 0.252, 44);
      for (let k = 1; k <= 10; k++) {
        const next = c.at(1.6 + k * 0.13, 0.252, 44 + ((k * 13) % 9) + k * 2);
        c.line(prev, next, C.glow);
        prev = next;
      }
      for (let k = 0; k < 9; k++) {
        const [x, y] = c.at(
          1.7 + (k % 5) * 0.25,
          0.252,
          66 + Math.floor(k / 5) * 5,
        );
        c.p.rect(x, y, 2, 2, [C.yellow, C.pink, C.lime][k % 3]);
      }
      c.faceX(0.02, 0.252, 2.96, 38, 2, C.blueDark);
    },
  },
  'm-hospital-bed': {
    footprint: [2, 1],
    h: 34,
    draw(c) {
      for (const [x, y] of [
        [0.1, 0.1],
        [1.8, 0.1],
        [0.1, 0.8],
        [1.8, 0.8],
      ]) {
        c.box(x, y, 0.1, 0.1, 10, M.steel);
        const [wx, wy] = c.at(x + 0.05, y + 0.05, 0);
        c.p.rect(wx - 1, wy - 2, 3, 2, C.charcoal);
      }
      c.box(0, 0, 2, 1, 3, M.steel, 10);
      c.box(0.03, 0.03, 1.94, 0.94, 5, M.white, 13);
      c.box(
        0.6,
        0.02,
        1.38,
        0.96,
        1,
        { top: C.glassLight, front: C.glass, side: C.glassDark },
        17,
      );
      c.edge([0.6, 0.98, 18], [1.98, 0.98, 18], C.white);
      for (let u = 0.8; u < 1.9; u += 0.3)
        c.edge([u, 0.1, 18], [u + 0.05, 0.95, 18], C.glass);
      c.box(0.08, 0.15, 0.45, 0.7, 4, M.white, 18);
      c.box(-0.08, 0, 0.1, 1, 26, M.steel, 0);
      c.faceY(0.021, 0.05, 0.9, 12, 16, C.teal);
      // Side rail.
      c.edge([0.7, 1.02, 22], [1.7, 1.02, 22], C.steelDark);
      for (const u of [0.75, 1.65])
        c.edge([u, 1.02, 16], [u, 1.02, 22], C.steelDark);
    },
  },
  'm-iv-stand': {
    footprint: [0.5, 0.5],
    h: 76,
    draw(c) {
      const [x, y] = c.at(0.25, 0.25, 0);
      for (const d of [-5, -2, 2, 5])
        c.p.rect(x + d, y - 1 + Math.abs(d) / 3, 1, 2, C.charcoal);
      c.p.rect(x - 5, y - 2, 11, 1, C.steelDark);
      c.p.rect(x, y - 70, 1, 68, C.steel);
      c.p.rect(x - 4, y - 71, 9, 1, C.steelDark);
      c.p.rect(x + 2, y - 68, 5, 9, C.waterLight);
      c.p.rect(x + 3, y - 64, 3, 4, C.glass);
      c.p.pixel(x + 2, y - 68, C.white);
      c.line([x + 4, y - 59], [x + 6, y - 30], C.glassLight);
    },
  },
  'm-monitor-cart': {
    footprint: [1, 1],
    h: 64,
    frames: 4,
    draw(c, f) {
      c.box(0.2, 0.2, 0.6, 0.6, 3, M.dark, 3);
      for (const [x, y] of [
        [0.25, 0.25],
        [0.75, 0.25],
        [0.25, 0.75],
        [0.75, 0.75],
      ]) {
        const [wx, wy] = c.at(x, y, 0);
        c.p.rect(wx - 1, wy - 3, 3, 3, C.ink);
      }
      c.box(0.45, 0.45, 0.1, 0.1, 30, M.steel, 6);
      c.box(0.15, 0.35, 0.7, 0.35, 4, M.white, 36);
      c.box(0.2, 0.4, 0.6, 0.15, 20, M.white, 40);
      c.faceX(0.24, 0.551, 0.52, 43, 15, C.screen);
      const pts: [number, number][] = [];
      for (let k = 0; k <= 12; k++) {
        const phase = (k + f * 3) % 12,
          z = phase === 4 ? 56 : phase === 5 ? 45 : phase === 6 ? 52 : 50;
        pts.push(c.at(0.26 + k * 0.04, 0.552, z));
      }
      for (let k = 1; k < pts.length; k++) c.line(pts[k - 1], pts[k], C.beat);
      const [lx, ly] = c.at(0.7, 0.552, 45);
      c.p.pixel(lx, ly, f % 2 ? C.red : C.yellow);
    },
  },
  'm-curtain': {
    footprint: [3, 0.3],
    h: 80,
    draw(c) {
      for (const u of [0, 3]) c.box(u - 0.05, 0.1, 0.1, 0.1, 78, M.steel);
      c.faceX(0, 0.15, 3, 76, 2, C.steelDark);
      for (let k = 0; k < 15; k++) {
        const u = 0.04 + k * 0.196;
        c.faceX(u, 0.16, 0.196, 8, 64, k % 2 ? C.mintDark : C.mint);
        c.faceX(u, 0.161, 0.04, 8, 64, k % 2 ? C.deepTeal : C.vinylLight);
        const [hx, hy] = c.at(u + 0.1, 0.16, 74);
        c.p.pixel(hx, hy, C.steelDark);
      }
      c.faceX(0.04, 0.162, 2.94, 8, 2, C.tealDark);
    },
  },
  'm-waiting-chairs': {
    footprint: [3, 1],
    h: 34,
    draw(c) {
      c.box(0.1, 0.4, 2.8, 0.15, 3, M.steel, 8);
      for (const u of [0.25, 2.65]) c.box(u, 0.4, 0.1, 0.15, 8, M.steel);
      for (let i = 0; i < 3; i++) {
        const u = 0.12 + i * 0.95;
        c.box(u, 0.2, 0.8, 0.65, 3, M.teal, 11);
        c.box(u + 0.02, 0.15, 0.76, 0.1, 18, M.teal, 14);
        c.edge([u + 0.08, 0.25, 30], [u + 0.72, 0.25, 30], C.mint);
      }
    },
  },
  'm-reception': {
    footprint: [3, 1],
    h: 56,
    draw(c) {
      c.box(0, 0, 3, 1, 26, M.white);
      c.faceX(0, 1.001, 3, 6, 4, C.teal);
      c.faceY(3.001, 0, 1, 6, 4, C.tealDark);
      c.faceX(0.2, 1.002, 2.6, 12, 10, C.offwhite);
      for (let u = 0.3; u < 2.8; u += 0.3)
        c.edge([u, 1.003, 12], [u, 1.003, 21], C.pale);
      c.box(-0.05, -0.05, 3.1, 1.1, 2, M.oak, 26);
      c.box(1.2, 0.2, 0.12, 0.1, 6, M.dark, 28);
      screen(c, 0.9, 0.32, 0.8, 32, 20, 1);
      c.pot(2.5, 0.5, 28, 4, 8, R.terracotta, C.soil);
      c.greenery(2.5, 0.5, 44, 9, R.leaf, C.yellow);
    },
  },
  'm-drafting-table': {
    footprint: [2, 1.5],
    h: 64,
    draw(c) {
      for (const [x, y] of [
        [0.1, 0.2],
        [1.8, 0.2],
        [0.1, 1.2],
        [1.8, 1.2],
      ])
        c.box(x, y, 0.08, 0.08, 22, M.steel);
      c.edge([0.15, 0.3, 8], [1.85, 0.3, 8], C.steelDark);
      c.poly(
        [
          [0, 0.1, 42],
          [2, 0.1, 42],
          [2, 1.4, 24],
          [0, 1.4, 24],
        ],
        C.white,
      );
      c.poly(
        [
          [0, 1.4, 24],
          [2, 1.4, 24],
          [2, 1.4, 21],
          [0, 1.4, 21],
        ],
        C.pale,
      );
      c.poly(
        [
          [0.15, 0.25, 40],
          [1.85, 0.25, 40],
          [1.85, 1.25, 26],
          [0.15, 1.25, 26],
        ],
        C.blue,
      );
      const pt = (x: number, t: number) => c.at(x, 0.25 + t, 40 - t * 14);
      for (let k = 0; k < 4; k++)
        c.line(
          pt(0.3, 0.15 + k * 0.22),
          pt(1.7, 0.15 + k * 0.22),
          C.glassLight,
        );
      for (let k = 0; k < 6; k++)
        c.line(pt(0.3 + k * 0.28, 0.1), pt(0.3 + k * 0.28, 0.85), C.glass);
      c.line(pt(0.5, 0.2), pt(1.2, 0.8), C.white);
      c.line(pt(1.2, 0.2), pt(0.5, 0.8), C.white);
      c.edge([0, 1.42, 24], [2, 1.42, 24], C.slate);
      // Ruler and lamp.
      c.edge([0.1, 1.2, 27], [1.9, 1.2, 27], C.yellow);
      const [lx, ly] = c.at(1.9, 0.15, 42);
      c.thick([lx, ly], [lx - 4, ly - 16], 0.5, C.charcoal);
      c.thick([lx - 4, ly - 16], [lx - 12, ly - 10], 0.5, C.charcoal);
      c.p.poly(
        [
          [lx - 16, ly - 8],
          [lx - 10, ly - 13],
          [lx - 8, ly - 8],
        ],
        C.red,
      );
      c.p.pixel(lx - 12, ly - 7, C.yellow);
    },
  },
  'm-tower-model': {
    footprint: [1, 1],
    h: 104,
    draw(c) {
      c.box(0.05, 0.05, 0.9, 0.9, 16, M.oak);
      c.faceX(0.05, 0.951, 0.9, 10, 2, C.woodDark);
      const base = 0.28,
        topS = 0.17,
        z0 = 16,
        z1 = 96;
      const s = (z: number) => base + ((topS - base) * (z - z0)) / (z1 - z0);
      const corners = (z: number) => {
        const k = s(z);
        return { a: 0.5 - k, b: 0.5 + k };
      };
      const b0 = corners(z0),
        b1 = corners(z1);
      c.poly(
        [
          [b0.a, b0.b, z0],
          [b0.b, b0.b, z0],
          [b1.b, b1.b, z1],
          [b1.a, b1.b, z1],
        ],
        C.charcoal,
      );
      c.poly(
        [
          [b0.b, b0.b, z0],
          [b0.b, b0.a, z0],
          [b1.b, b1.a, z1],
          [b1.b, b1.b, z1],
        ],
        C.ink,
      );
      c.top(b1.a, b1.a, b1.b - b1.a, b1.b - b1.a, z1, C.slate);
      for (let z = z0; z < z1; z += 4) {
        const k = corners(z);
        c.edge([k.a, k.b + 0.001, z], [k.b, k.b + 0.001, z], C.slate);
      }
      for (let z = z0; z < z1 - 1; z += 20) {
        const lo = corners(z),
          hi = corners(z + 20);
        c.edge([lo.a, lo.b + 0.002, z], [hi.b, hi.b + 0.002, z + 20], C.silver);
        c.edge([lo.b, lo.b + 0.002, z], [hi.a, hi.b + 0.002, z + 20], C.silver);
        c.edge(
          [lo.b + 0.002, lo.b, z],
          [hi.b + 0.002, hi.a, z + 20],
          C.steelDark,
        );
        c.edge(
          [lo.b + 0.002, lo.a, z],
          [hi.b + 0.002, hi.b, z + 20],
          C.steelDark,
        );
        c.edge([lo.a, lo.b + 0.002, z], [lo.b, lo.b + 0.002, z], C.white);
      }
      for (const d of [-0.05, 0.05]) {
        const [x, y] = c.at(0.5 + d, 0.5 + d, z1);
        c.p.rect(x, y - 8, 1, 8, C.silver);
      }
    },
  },
  'm-wave-model': {
    footprint: [2, 1],
    h: 42,
    draw(c) {
      for (const [x, y] of [
        [0.05, 0.05],
        [1.85, 0.05],
        [0.05, 0.85],
        [1.85, 0.85],
      ])
        c.box(x, y, 0.1, 0.1, 20, M.wood);
      c.box(0, 0, 2, 1, 2, M.white, 20);
      c.top(0.1, 0.1, 1.8, 0.8, 22, C.mint);
      for (let ribbon = 0; ribbon < 2; ribbon++) {
        const height = (t: number) =>
          3 +
          Math.sin(t * Math.PI) * (11 - ribbon * 4) +
          Math.sin(t * 7 + ribbon) * 2;
        for (let t = 0; t <= 1; t += 0.008) {
          const x = 0.2 + t * 1.6,
            y = 0.32 + ribbon * 0.32 + Math.sin(t * 4 + ribbon) * 0.1,
            h = height(t),
            slope = height(t + 0.01) - h;
          const [px, py] = c.at(x, y, 22);
          c.p.rect(
            px,
            py - h,
            1,
            h,
            slope > 0.05 ? C.white : slope < -0.05 ? C.pale : C.offwhite,
          );
          c.p.pixel(px, py - h, C.white);
          c.p.pixel(px, py - h - 1, C.silver);
          c.p.pixel(px, py, C.silver);
        }
      }
    },
  },
  'm-kitchen-counter': {
    footprint: [3, 1],
    h: 70,
    frames: 4,
    draw(c, f) {
      c.box(0, 0, 3, 1, 22, M.steel);
      for (let u = 0.1; u < 3; u += 1) {
        c.faceX(u, 1.001, 0.8, 3, 16, C.steelLight);
        c.faceX(u + 0.3, 1.002, 0.2, 15, 1, C.slate);
      }
      c.box(-0.03, -0.03, 3.06, 1.06, 2, M.steel, 22);
      const pots: [number, number, number, string][] = [
        [0.5, 0.5, 9, C.orange],
        [1.5, 0.5, 8, C.yellowDark],
        [2.45, 0.5, 7, C.red],
      ];
      for (const [x, y, r, food] of pots) {
        c.cylinder(x, y, 24, r, r + 3, R.steel);
        const [cx, cy] = c.at(x, y, 27 + r);
        c.p.ellipse(cx, cy, r - 1, (r - 1) / 2, food);
        c.p.rect(cx - r - 2, cy + 3, 3, 2, C.charcoal);
        c.p.rect(cx + r, cy + 3, 3, 2, C.charcoal);
        for (let k = 0; k < 4; k++) {
          const drift = (f + k) % 4;
          c.p.pixel(
            cx - 3 + k * 2 + (drift % 2),
            cy - 4 - drift * 4 - k,
            C.white,
          );
          c.p.pixel(cx - 2 + k * 2, cy - 6 - drift * 4 - k, C.pale);
        }
      }
      const [lx, ly] = c.at(1.5, 0.5, 35);
      c.line([lx + 2, ly], [lx + 8, ly - 14], C.steelDark);
    },
  },
  'm-dining-table': {
    footprint: [4, 1],
    h: 32,
    draw(c) {
      for (const [x, y] of [
        [0.1, 0.1],
        [3.8, 0.1],
        [0.1, 0.8],
        [3.8, 0.8],
      ])
        c.box(x, y, 0.1, 0.1, 18, M.wood);
      c.box(0, 0, 4, 1, 3, M.oak, 18);
      c.top(0.1, 0.35, 3.8, 0.3, 21, C.red);
      c.edge([0.1, 0.5, 21], [3.9, 0.5, 21], C.yellow);
      const foods = [C.rice, C.green, C.orange, C.yellow, C.red, C.lime];
      for (let i = 0; i < 6; i++) {
        for (const y of [0.22, 0.78]) {
          const [x, py] = c.at(0.35 + i * 0.6, y, 21);
          c.p.ellipse(x, py, 5, 2, C.white);
          c.p.ellipse(
            x,
            py - 1,
            3,
            1,
            foods[(i + (y > 0.5 ? 2 : 0)) % foods.length],
          );
          c.p.pixel(x - 1, py - 2, C.cream);
        }
        if (i % 2 === 0) {
          const [bx, by] = c.at(0.65 + i * 0.6, 0.5, 21);
          c.p.ellipse(bx, by - 2, 4, 3, C.teal);
          c.p.ellipse(bx, by - 4, 3, 1, [C.orange, C.green, C.rice][i / 2]);
        } else {
          c.cylinder(0.65 + i * 0.6, 0.5, 21, 2, 8, R.glass);
        }
      }
      for (let i = 0; i < 8; i++)
        c.cylinder(0.25 + i * 0.5, 0.06 + (i % 2) * 0.88, 21, 1.5, 3, R.white);
    },
  },
  'm-food-shelf': {
    footprint: [3, 0.7],
    h: 64,
    side: true,
    draw(c) {
      for (const u of [0, 2.94]) c.box(u, 0, 0.06, 0.7, 62, M.steel);
      for (let r = 0; r < 4; r++) {
        const z = 2 + r * 15;
        c.box(0, 0, 3, 0.7, 1, M.steel, z);
        let u = 0.1;
        let k = r * 5;
        while (u < 2.85) {
          const kind = k % 4;
          if (kind === 0) {
            c.box(
              u,
              0.15,
              0.32,
              0.45,
              10,
              {
                top: C.cream,
                front: accents[k % accents.length],
                side: C.woodDark,
              },
              z + 1,
            );
            u += 0.36;
          } else if (kind === 1) {
            for (let j = 0; j < 3; j++)
              c.cylinder(u + 0.08 + j * 0.13, 0.5, z + 1, 2, 6, [
                C.steelLight,
                accents[(k + j) % accents.length],
                C.steelDark,
              ]);
            u += 0.42;
          } else if (kind === 2) {
            const [sx, sy] = c.at(u + 0.2, 0.5, z + 1);
            c.p.ellipse(sx, sy - 5, 6, 6, C.rice);
            c.p.rect(sx - 6, sy - 5, 12, 5, C.rice);
            c.p.rect(sx - 6, sy - 6, 3, 6, C.cream);
            c.p.rect(sx + 3, sy - 6, 3, 6, C.woodLight);
            c.p.rect(sx - 3, sy - 5, 6, 2, accents[k % accents.length]);
            u += 0.45;
          } else {
            for (let j = 0; j < 2; j++) {
              const [bx, by] = c.at(u + 0.1 + j * 0.15, 0.5, z + 1);
              c.p.rect(bx, by - 9, 3, 9, j ? C.glass : C.green);
              c.p.rect(bx + 1, by - 12, 1, 3, C.charcoal);
              c.p.pixel(bx, by - 8, C.white);
            }
            u += 0.36;
          }
          k++;
        }
      }
    },
  },
  'm-fridge': {
    footprint: [1, 1],
    h: 76,
    draw(c) {
      c.box(0.1, 0.1, 0.8, 0.8, 74, M.steel);
      c.edge([0.1, 0.901, 46], [0.9, 0.901, 46], C.slate);
      c.faceX(0.75, 0.902, 0.05, 50, 18, C.charcoal);
      c.faceX(0.75, 0.902, 0.05, 28, 14, C.charcoal);
      c.edge([0.15, 0.902, 72], [0.4, 0.902, 72], C.white);
      c.faceX(0.25, 0.902, 0.15, 60, 6, C.yellow);
      c.faceX(0.45, 0.902, 0.12, 56, 7, C.pink);
    },
  },
  'm-bookshelf': {
    footprint: [3, 0.6],
    h: 68,
    side: true,
    draw(c) {
      c.box(0, 0, 3, 0.6, 66, M.white);
      for (let r = 0; r < 4; r++) {
        const z = 4 + r * 15.5;
        c.faceX(0.06, 0.601, 2.88, z, 13, C.pale);
        let u = 0.1;
        let k = r * 7;
        while (u < 2.8) {
          if (k % 11 === 5) {
            c.pot(u + 0.1, 0.5, z, 3, 5, R.terracotta, C.soil);
            c.greenery(u + 0.1, 0.5, z + 10, 5, R.leaf);
            u += 0.3;
          } else if (k % 17 === 9) {
            const [gx, gy] = c.at(u + 0.12, 0.6, z);
            c.p.rect(gx, gy - 2, 1, 2, C.woodDark);
            c.p.ellipse(gx, gy - 7, 4, 4, C.blue);
            c.p.rect(gx - 2, gy - 9, 3, 2, C.green);
            c.p.rect(gx, gy - 5, 2, 2, C.green);
            u += 0.3;
          } else {
            book(
              c,
              u,
              0.602,
              z,
              7 + ((k * 5) % 6),
              accents[k % accents.length],
            );
            u += 0.13;
          }
          k++;
        }
        c.faceX(0, 0.603, 3, z - 2, 2, C.offwhite);
      }
    },
  },
  'm-kids-table': {
    footprint: [2, 2],
    h: 30,
    draw(c) {
      const [cx, cy] = c.at(1, 1, 12);
      for (const [dx, dy] of [
        [-12, 0],
        [12, 0],
        [0, 6],
        [0, -6],
      ])
        c.p.rect(cx + dx, cy + dy, 2, 12, C.steelDark);
      c.p.ellipse(cx, cy + 2, 24, 12, C.yellowDark);
      c.p.ellipse(cx, cy, 24, 12, C.yellow);
      c.p.ellipse(cx - 4, cy - 2, 16, 7, C.cream);
      // Small laptops.
      for (const [x, y, col] of [
        [0.6, 0.7, C.blue],
        [1.4, 1.2, C.pink],
      ] as [number, number, string][]) {
        c.top(x - 0.2, y - 0.1, 0.4, 0.25, 12, C.silver);
        c.faceX(x - 0.2, y - 0.1, 0.4, 12, 9, col);
        c.faceX(x - 0.17, y - 0.099, 0.34, 13, 7, C.screen);
        c.faceX(x - 0.1, y - 0.098, 0.15, 15, 3, C.glow);
      }
      // Robotics kit.
      c.box(1.1, 0.45, 0.35, 0.3, 5, M.orange, 12);
      for (const [x, y] of [
        [1.12, 0.78],
        [1.4, 0.78],
      ]) {
        const [wx, wy] = c.at(x, y, 13);
        c.p.ellipse(wx, wy, 2, 2, C.ink);
      }
      const [ax, ay] = c.at(1.27, 0.6, 17);
      c.p.rect(ax, ay - 5, 1, 5, C.charcoal);
      c.p.pixel(ax, ay - 6, C.red);
      c.p.ellipse(
        c.at(0.6, 1.35, 13)[0],
        c.at(0.6, 1.35, 13)[1],
        3,
        2,
        C.green,
      );
    },
  },
  'm-solar-panel': {
    footprint: [2, 2],
    h: 40,
    draw(c) {
      for (const [x, y, h] of [
        [0.2, 0.3, 34],
        [1.8, 0.3, 34],
        [0.2, 1.7, 12],
        [1.8, 1.7, 12],
      ])
        c.box(x - 0.04, y - 0.04, 0.08, 0.08, h, M.steel);
      c.poly(
        [
          [0, 0.15, 36],
          [2, 0.15, 36],
          [2, 1.85, 12],
          [0, 1.85, 12],
        ],
        C.steel,
      );
      c.poly(
        [
          [0.06, 0.2, 35],
          [1.94, 0.2, 35],
          [1.94, 1.8, 13],
          [0.06, 1.8, 13],
        ],
        C.navy,
      );
      const pt = (x: number, t: number) => c.at(x, 0.2 + t * 1.6, 35 - t * 22);
      for (let k = 1; k < 6; k++)
        c.line(pt(0.06, k / 6), pt(1.94, k / 6), C.blueDark);
      for (let k = 1; k < 8; k++)
        c.line(pt(0.06 + k * 0.235, 0), pt(0.06 + k * 0.235, 1), C.blue);
      c.line(pt(0.3, 0.05), pt(0.9, 0.5), C.glassDark);
      c.line(pt(0.35, 0.05), pt(0.95, 0.5), C.glassDark);
      c.edge([0, 1.86, 12], [2, 1.86, 12], C.silver);
    },
  },
  'm-bike-rack': {
    footprint: [3, 1],
    h: 30,
    draw(c) {
      c.box(0.05, 0.45, 2.9, 0.1, 2, M.steel);
      for (let i = 0; i < 3; i++) {
        const u = 0.4 + i * 1,
          col = [C.red, C.teal, C.yellow][i];
        const [fx, fy] = c.at(u, 0.55, 0);
        const back: [number, number] = [fx - 10, fy - 4],
          front: [number, number] = [fx + 6, fy + 4];
        for (const w of [back, front]) {
          c.p.ellipse(w[0], w[1] - 7, 6, 7, C.ink);
          c.p.ellipse(w[0], w[1] - 7, 4, 5, C.pale);
          c.p.ellipse(w[0], w[1] - 7, 3, 4, C.ink);
          c.p.ellipse(w[0], w[1] - 7, 2, 3, C.pale);
          c.p.pixel(w[0], w[1] - 7, C.slate);
        }
        const seat: [number, number] = [back[0] + 5, back[1] - 17],
          bar: [number, number] = [front[0] - 1, front[1] - 20];
        c.thick([back[0], back[1] - 7], [seat[0], seat[1]], 0.6, col);
        c.thick([seat[0], seat[1] + 2], [bar[0], bar[1] + 4], 0.6, col);
        c.thick([front[0], front[1] - 7], [bar[0], bar[1]], 0.6, col);
        c.thick([back[0], back[1] - 7], [front[0] - 6, front[1] - 9], 0.6, col);
        c.thick([front[0] - 6, front[1] - 9], [seat[0], seat[1] + 2], 0.6, col);
        c.p.rect(seat[0] - 2, seat[1] - 1, 5, 2, C.charcoal);
        c.p.rect(bar[0] - 2, bar[1] - 1, 5, 1, C.charcoal);
      }
      for (const u of [0.1, 2.9])
        c.box(u - 0.03, 0.47, 0.06, 0.06, 14, M.steel);
    },
  },
  'm-street-lamp': {
    footprint: [0.5, 0.5],
    h: 100,
    draw(c) {
      c.box(0.1, 0.1, 0.3, 0.3, 6, M.dark);
      const [x, y] = c.at(0.25, 0.25, 6);
      c.p.rect(x - 1, y - 82, 3, 82, C.slate);
      c.p.rect(x - 1, y - 82, 1, 82, C.grey);
      c.p.rect(x, y - 82, 12, 2, C.slate);
      c.p.rect(x + 6, y - 81, 8, 3, C.charcoal);
      c.p.rect(x + 7, y - 78, 6, 2, C.yellow);
      c.p.pixel(x + 9, y - 77, C.white);
      c.p.poly(
        [
          [x - 9, y - 88],
          [x + 3, y - 94],
          [x + 7, y - 88],
          [x - 5, y - 82],
        ],
        C.navy,
      );
      c.line([x - 7, y - 87], [x + 4, y - 92], C.blue);
      c.line([x - 3, y - 85], [x + 6, y - 89], C.blue);
      c.p.rect(x - 1, y - 30, 3, 6, C.teal);
    },
  },
  'm-bench': {
    footprint: [2, 1],
    h: 32,
    draw(c) {
      for (const u of [0.2, 1.8]) {
        c.box(u - 0.04, 0.3, 0.08, 0.5, 13, M.dark);
        c.box(u - 0.04, 0.2, 0.08, 0.1, 30, M.dark);
      }
      for (let k = 0; k < 3; k++)
        c.box(0, 0.32 + k * 0.17, 2, 0.13, 2, M.oak, 13);
      for (let k = 0; k < 2; k++) c.box(0, 0.2, 2, 0.06, 4, M.oak, 18 + k * 7);
    },
  },
  'm-cafe-table': {
    footprint: [1, 1],
    h: 32,
    draw(c) {
      const chair = (x: number, y: number, col: string, back: boolean) => {
        c.box(
          x - 0.15,
          y - 0.15,
          0.3,
          0.3,
          2,
          { top: col, front: C.charcoal, side: C.ink },
          12,
        );
        for (const [dx, dy] of [
          [-0.12, -0.12],
          [0.12, 0.12],
          [-0.12, 0.12],
          [0.12, -0.12],
        ]) {
          const [lx, ly] = c.at(x + dx, y + dy, 0);
          c.p.rect(lx, ly - 12, 1, 12, C.charcoal);
        }
        if (back) c.faceX(x - 0.15, y - 0.15, 0.3, 14, 12, col);
      };
      chair(0.18, 0.5, C.red, false);
      const [cx, cy] = c.at(0.5, 0.5, 0);
      c.p.rect(cx - 1, cy - 20, 2, 20, C.charcoal);
      c.p.ellipse(cx, cy - 1, 5, 2, C.charcoal);
      c.p.ellipse(cx, cy - 20, 11, 6, C.slate);
      c.p.ellipse(cx, cy - 21, 11, 5, C.white);
      for (const [dx, col] of [
        [-4, C.woodDark],
        [4, C.teal],
      ] as [number, string][]) {
        c.p.rect(cx + dx - 1, cy - 25, 3, 3, C.white);
        c.p.rect(cx + dx - 1, cy - 25, 3, 1, col);
        c.p.pixel(cx + dx + 2, cy - 24, C.pale);
      }
      chair(0.82, 0.5, C.yellow, true);
    },
  },
  'm-coffee-cart': {
    footprint: [2, 1],
    h: 70,
    draw(c) {
      for (const [x, y] of [
        [0.3, 0.9],
        [1.7, 0.9],
      ]) {
        const [wx, wy] = c.at(x, y, 4);
        c.p.ellipse(wx, wy, 4, 4, C.ink);
        c.p.ellipse(wx, wy, 2, 2, C.silver);
      }
      c.box(
        0,
        0,
        2,
        1,
        24,
        { top: C.woodLight, front: C.teal, side: C.tealDark, edge: C.deepTeal },
        4,
      );
      c.faceX(0.1, 1.001, 1.8, 12, 4, C.cream);
      c.box(0.3, 0.2, 0.7, 0.5, 14, M.steel, 28);
      c.faceX(0.4, 0.701, 0.5, 34, 5, C.charcoal);
      c.faceX(0.5, 0.702, 0.1, 30, 4, C.slate);
      c.cylinder(1.4, 0.5, 28, 3, 6, R.white);
      c.cylinder(1.65, 0.5, 28, 3, 5, [C.woodLight, C.wood, C.woodDark]);
      for (const u of [0.05, 1.95])
        c.box(u - 0.03, 0.85, 0.06, 0.06, 36, M.steel, 28);
      for (let i = 0; i < 8; i++) {
        c.top(i * 0.25 - 0.05, -0.1, 0.25, 1.2, 64, i % 2 ? C.white : C.red);
        c.faceX(
          i * 0.25 - 0.05,
          1.1,
          0.25,
          58,
          6,
          i % 2 ? C.offwhite : C.redDark,
        );
      }
    },
  },
  'm-tree': {
    footprint: [1, 1],
    h: 106,
    pad: 28,
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      c.p.ellipse(x, y, 7, 3, C.soil);
      c.p.poly(
        [
          [x - 3, y],
          [x + 3, y],
          [x + 2, y - 50],
          [x - 2, y - 50],
        ],
        C.trunk,
      );
      c.p.rect(x - 2, y - 48, 1, 46, C.woodDark);
      c.line([x, y - 38], [x - 10, y - 56], C.trunk);
      c.line([x + 1, y - 34], [x + 12, y - 52], C.trunk);
      c.greenery(0.5, 0.5, 70, 28, R.leaf, C.lime);
      c.greenery(0.3, 0.7, 56, 20, R.leaf);
      c.greenery(0.7, 0.3, 84, 18, R.leaf, C.leafLight);
    },
  },
  'm-planter-box': {
    footprint: [2, 1],
    h: 36,
    draw(c) {
      c.box(0, 0, 2, 1, 12, M.concrete);
      c.top(0.08, 0.08, 1.84, 0.84, 12, C.soil);
      for (let i = 0; i < 26; i++) {
        const x = 0.15 + ((i * 7) % 18) * 0.095,
          y = 0.15 + ((i * 5) % 7) * 0.1,
          [px, py] = c.at(x, y, 12),
          h = 6 + ((i * 3) % 9);
        c.line(
          [px, py],
          [px + ((i % 3) - 1) * 2, py - h],
          i % 2 ? C.leaf : C.leafDark,
        );
        if (i % 3 === 0) {
          const col = [C.pink, C.yellow, C.purple, C.red, C.white][i % 5];
          c.p.rect(px + ((i % 3) - 1) * 2 - 1, py - h - 1, 3, 2, col);
        }
      }
    },
  },
  'm-fountain': {
    footprint: [3, 3],
    h: 52,
    frames: 4,
    draw(c, f) {
      c.box(0, 0, 3, 3, 9, M.stone);
      c.top(0.2, 0.2, 2.6, 2.6, 9, C.tealDark);
      c.top(0.3, 0.3, 2.4, 2.4, 9, C.turquoise);
      for (let k = 0; k < 5; k++) {
        const r = 0.2 + ((k + f) % 5) * 0.22;
        c.edge([1.5 - r, 1.5, 9], [1.5, 1.5 - r, 9], C.waterLight);
        c.edge([1.5 + r, 1.5, 9], [1.5, 1.5 + r, 9], C.water);
      }
      c.box(1.2, 1.2, 0.6, 0.6, 16, M.white, 9);
      c.top(1.25, 1.25, 0.5, 0.5, 25, C.turquoise);
      const [cx, cy] = c.at(1.5, 1.5, 25);
      for (let j = 0; j < 4; j++) {
        const a = (j / 4) * Math.PI * 2 + 0.6,
          tx = Math.cos(a) * 22,
          ty = Math.sin(a) * 11;
        for (let k = 0; k < 10; k++) {
          const t = k / 10,
            h = Math.sin(t * Math.PI) * (16 + (f % 2) * 2);
          c.p.pixel(
            cx + tx * t,
            cy + ty * t - h,
            (k + f) % 3 ? C.waterLight : C.white,
          );
        }
      }
      for (let k = 0; k < 6; k++)
        c.p.pixel(
          cx + ((k * 3) % 5) - 2,
          cy - 16 - ((k * 5 + f * 3) % 10),
          C.white,
        );
      c.p.rect(cx, cy - 22, 1, 22, C.waterLight);
    },
  },
  'm-bus-shelter': {
    footprint: [3, 1],
    h: 76,
    draw(c) {
      for (const [x, y] of [
        [0.05, 0.1],
        [2.95, 0.1],
        [2.95, 0.9],
      ])
        c.box(x - 0.04, y - 0.04, 0.08, 0.08, 70, M.dark);
      c.faceX(0.05, 0.1, 2.9, 6, 60, C.glassLight);
      for (let u = 0.3; u < 2.9; u += 0.7)
        c.edge([u, 0.101, 12], [u + 0.3, 0.101, 50], C.white);
      c.box(0.3, 0.25, 2.2, 0.3, 2, M.oak, 13);
      for (const u of [0.4, 2.4]) c.box(u, 0.3, 0.06, 0.2, 13, M.dark);
      // Abstract route map on the side panel.
      c.faceY(2.96, 0.15, 0.7, 10, 54, C.white);
      c.edge([2.961, 0.25, 20], [2.961, 0.7, 56], C.red);
      c.edge([2.961, 0.2, 40], [2.961, 0.8, 30], C.blue);
      c.edge([2.961, 0.3, 54], [2.961, 0.75, 18], C.green);
      for (const [y, z] of [
        [0.45, 36],
        [0.6, 46],
        [0.35, 28],
      ]) {
        const [px, py] = c.at(2.961, y, z);
        c.p.rect(px - 1, py - 1, 3, 3, C.charcoal);
      }
      c.box(
        -0.1,
        -0.05,
        3.2,
        1.1,
        4,
        { top: C.white, front: C.teal, side: C.tealDark, edge: C.deepTeal },
        70,
      );
    },
  },
  'm-water-cooler': {
    footprint: [0.5, 0.5],
    h: 52,
    draw(c) {
      c.box(0.05, 0.05, 0.4, 0.4, 32, M.white);
      c.faceX(0.12, 0.451, 0.26, 18, 6, C.charcoal);
      const [tx, ty] = c.at(0.18, 0.452, 22);
      c.p.pixel(tx, ty, C.blue);
      c.p.pixel(tx + 3, ty, C.red);
      c.cylinder(0.25, 0.25, 32, 5, 14, R.glass, C.glassLight);
      c.cylinder(0.25, 0.25, 46, 2, 3, R.blue);
      const [bx, by] = c.at(0.25, 0.25, 36);
      c.p.rect(bx - 4, by - 8, 1, 6, C.white);
    },
  },
  'm-desk-plant': {
    footprint: [0.5, 0.5],
    h: 50,
    pad: 14,
    draw(c) {
      c.pot(0.25, 0.25, 0, 6, 12, R.white, C.soil);
      const [x, y] = c.at(0.25, 0.25, 12);
      for (const [dx, dy, r] of [
        [-8, -18, 7],
        [7, -22, 7],
        [-3, -30, 6],
        [5, -10, 6],
        [-9, -8, 5],
        [1, -38, 5],
      ]) {
        c.line([x, y], [x + dx * 0.6, y + dy * 0.6], C.leafDark);
        c.p.ellipse(x + dx, y + dy, r, r * 0.6, C.leaf);
        c.p.ellipse(x + dx - 1, y + dy - 1, r * 0.6, r * 0.3, C.leafLight);
        c.line([x + dx - r + 2, y + dy], [x + dx + r - 2, y + dy], C.leafDark);
      }
    },
  },
};

/* ───────────── Football stadium ───────────── */
const fanSkins = [C.fanSkin1, C.fanSkin2, C.fanSkin3, C.fanSkin4];
const kit = [
  C.white,
  C.red,
  C.blue,
  C.yellow,
  C.green,
  C.navy,
  C.orange,
  C.purple,
  C.teal,
  C.pink,
  C.charcoal,
];
/** A point on a tile-space circle, plotted as an iso pixel. */
function arc(
  c: IsoCanvas,
  cx: number,
  cy: number,
  r: number,
  from: number,
  to: number,
  col: string,
) {
  const n = Math.ceil(r * 64);
  for (let k = 0; k <= n; k++) {
    const a = from + ((to - from) * k) / n,
      [x, y] = c.at(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    c.p.pixel(x, y, col);
    c.p.pixel(x + 1, y, col);
  }
}
function goal(c: IsoCanvas, postX: number, backX: number) {
  const H = 22,
    backH = 15;
  const grid = (a: [number, number, number], b: [number, number, number]) =>
    c.edge(a, b, C.net);
  // Net: back, sides and roof as a see-through grid.
  for (let y = 0; y <= 4.001; y += 0.5) grid([backX, y, 0], [backX, y, backH]);
  for (let z = 0; z <= backH; z += 5) grid([backX, 0, z], [backX, 4, z]);
  for (const y of [0, 4]) {
    for (let t = 0; t <= 1.001; t += 0.5) {
      const x = postX + (backX - postX) * t;
      grid([x, y, 0], [x, y, H + (backH - H) * t]);
    }
    for (let z = 0; z <= H; z += 5)
      grid([postX, y, Math.min(z, H)], [backX, y, Math.min(z, backH)]);
  }
  for (let y = 0; y <= 4.001; y += 0.5) grid([postX, y, H], [backX, y, backH]);
  c.edge([backX, 0, backH], [backX, 4, backH], C.netShade);
  c.edge([backX, 0, 0], [backX, 4, 0], C.netShade);
  // Posts and crossbar.
  for (const y of [0, 4]) {
    const [x0, y0] = c.at(postX, y, 0);
    c.p.rect(x0 - 1, y0 - H, 3, H + 1, C.white);
    c.p.rect(x0 + 1, y0 - H, 1, H + 1, C.pale);
  }
  const a = c.at(postX, 0, H),
    b = c.at(postX, 4, H);
  c.thick(a, b, 1, C.white);
  c.line([a[0], a[1] + 1], [b[0], b[1] + 1], C.pale);
}
const stadium: Record<string, Spec> = {
  'm-pitch': {
    footprint: [24, 16],
    h: 2,
    floor: true,
    draw(c) {
      c.top(0, 0, 24, 16, 0, C.pitchDark);
      for (let i = 0; i < 16; i++)
        c.top(i * 1.5, 0.05, 1.5, 15.9, 0, i % 2 ? C.pitch : C.pitchLight);
      const L = C.line,
        ln = (x1: number, y1: number, x2: number, y2: number) => {
          c.edge([x1, y1, 0], [x2, y2, 0], L);
          const a = c.at(x1, y1),
            b = c.at(x2, y2);
          c.line([a[0] + 1, a[1]], [b[0] + 1, b[1]], L);
        },
        rectL = (x: number, y: number, w: number, d: number) => {
          ln(x, y, x + w, y);
          ln(x + w, y, x + w, y + d);
          ln(x + w, y + d, x, y + d);
          ln(x, y + d, x, y);
        };
      rectL(0.5, 0.5, 23, 15);
      ln(12, 0.5, 12, 15.5);
      arc(c, 12, 8, 2.2, 0, Math.PI * 2, L);
      for (const x of [0.5, 20.3]) rectL(x, 4, 3.2, 8);
      for (const x of [0.5, 22.4]) rectL(x, 6, 1.1, 4);
      arc(c, 2.6, 8, 2.2, -0.93, 0.93, L);
      arc(c, 21.4, 8, 2.2, Math.PI - 0.93, Math.PI + 0.93, L);
      for (const [x, y] of [
        [12, 8],
        [2.6, 8],
        [21.4, 8],
      ]) {
        const [px, py] = c.at(x, y);
        c.p.rect(px - 1, py - 1, 3, 2, L);
      }
      for (const [x, y, a] of [
        [0.5, 0.5, 0],
        [23.5, 0.5, Math.PI / 2],
        [23.5, 15.5, Math.PI],
        [0.5, 15.5, -Math.PI / 2],
      ])
        arc(c, x, y, 0.45, a, a + Math.PI / 2, L);
    },
  },
  'm-goal-west': {
    footprint: [1, 4],
    h: 26,
    draw(c) {
      goal(c, 1, 0.15);
    },
  },
  'm-goal-east': {
    footprint: [1, 4],
    h: 26,
    draw(c) {
      goal(c, 0, 0.85);
    },
  },
  'm-stand': {
    footprint: [8, 3],
    h: 100,
    side: true,
    frames: 4,
    draw(c, f) {
      const tiers = 6,
        step = 12,
        depth = 3 / tiers;
      // Back wall and roof canopy.
      c.faceX(0, 0, 8, 0, tiers * step + 14, C.concreteShade);
      c.faceY(8, 0, 0.15, 0, tiers * step + 14, C.concreteLine);
      // Roof supports behind the tiers.
      for (const x of [0, 4, 7.88])
        c.box(x, -0.12, 0.12, 0.12, tiers * step + 14, M.steel);
      for (let i = tiers - 1; i >= 0; i--) {
        const y = 3 - (i + 1) * depth,
          z = (i + 1) * step;
        c.box(0, y, 8, depth, z, M.concrete);
        // Seats along the tread, with a fan in most of them.
        for (let k = 0; k < 24; k++) {
          const x = 0.17 + k * 0.33,
            n = k * 7 + i * 13,
            [px, py] = c.at(x, y + depth * 0.55, z),
            seat = [C.red, C.blue, C.teal, C.yellow][
              (i + Math.floor(k / 6)) % 4
            ];
          c.p.rect(px - 2, py - 4, 4, 4, seat);
          c.p.rect(px - 2, py - 1, 4, 1, C.charcoal);
          if (n % 9 === 4) continue;
          const shirt = kit[n % kit.length],
            skin = fanSkins[(n * 3) % 4],
            cheer = (n + f * 3 + Math.floor(k / 4)) % 6 < 2,
            bob = cheer ? 1 : 0;
          c.p.rect(px - 1, py - 8 - bob, 3, 5, shirt);
          c.p.pixel(px + 1, py - 4 - bob, C.edge);
          c.p.rect(px - 1, py - 11 - bob, 3, 3, skin);
          c.p.rect(
            px - 1,
            py - 12 - bob,
            3,
            1,
            n % 4 ? C.fanHair : kit[(n + 3) % kit.length],
          );
          if (cheer) {
            c.p.rect(px - 2, py - 13 - bob, 1, 4, skin);
            c.p.rect(px + 2, py - 13 - bob, 1, 4, skin);
            if (n % 5 === 0)
              c.p.rect(px - 2, py - 14 - bob, 5, 1, kit[(n + 5) % kit.length]);
          }
          if (n % 23 === 0) {
            // A plain flag on a short pole.
            c.p.rect(px + 2, py - 20, 1, 12, C.woodDark);
            c.p.rect(
              px + 3,
              py - 20 + (f % 2),
              5,
              4,
              kit[(n + 1) % kit.length],
            );
            c.p.rect(
              px + 3,
              py - 18 + (f % 2),
              5,
              1,
              kit[(n + 2) % kit.length],
            );
          }
        }
        c.edge([0, y + depth, z], [8, y + depth, z], C.stoneLine);
      }
      // Stairway aisles.
      for (const x of [2.6, 5.3])
        for (let i = 0; i < tiers; i++)
          c.top(
            x,
            3 - (i + 1) * depth,
            0.18,
            depth,
            (i + 1) * step + 0.5,
            C.warmGreyLight,
          );
      // Front wall with drainage stains and a lit coping.
      c.faceX(0, 3.001, 8, 0, step - 1, C.concreteShade);
      for (let u = 0.3; u < 8; u += 1.1)
        c.faceX(u, 3.002, 0.05, 1, step - 3, C.concreteLine);
      c.edge([0, 3.002, step - 1], [8, 3.002, step - 1], C.concrete);
      c.box(-0.05, -0.25, 8.1, 0.6, 4, M.teal, tiers * step + 14);
      c.edge(
        [-0.05, 0.35, tiers * step + 17],
        [8.05, 0.35, tiers * step + 17],
        C.turquoise,
      );
      c.box(-0.05, 0.3, 8.1, 0.12, 2, M.white, tiers * step + 12);
    },
  },
  'm-ad-boards': {
    footprint: [8, 0.3],
    h: 14,
    side: true,
    draw(c) {
      c.box(0, 0, 8, 0.3, 10, M.dark);
      const panels = [
        C.red,
        C.blue,
        C.yellow,
        C.green,
        C.orange,
        C.purple,
        C.teal,
        C.navy,
      ];
      for (let i = 0; i < 8; i++) {
        const col = panels[i % panels.length];
        c.faceX(i + 0.04, 0.301, 0.92, 1.5, 7.5, col);
        c.faceX(i + 0.15, 0.302, 0.4, 3.5, 3, C.white);
        c.faceX(i + 0.6, 0.302, 0.28, 3, 4, panels[(i + 3) % panels.length]);
      }
    },
  },
  'm-floodlight': {
    footprint: [1, 1],
    h: 232,
    draw(c) {
      const H = 200,
        legs: [number, number][] = [
          [0.1, 0.1],
          [0.9, 0.1],
          [0.9, 0.9],
          [0.1, 0.9],
        ];
      const pt = (i: number, z: number): [number, number, number] => {
        const t = z / H,
          [x, y] = legs[i];
        return [x + (0.5 - x) * t * 0.7, y + (0.5 - y) * t * 0.7, z];
      };
      c.box(0, 0, 1, 1, 6, M.concrete);
      for (const i of [0, 1, 3, 2])
        c.edge(pt(i, 6), pt(i, H), i === 2 ? C.steelDark : C.steel);
      for (let z = 6; z < H; z += 18)
        for (const [a, b] of [
          [3, 2],
          [1, 2],
          [0, 3],
          [0, 1],
        ]) {
          c.edge(pt(a, z), pt(b, z + 18), C.steelDark);
          c.edge(pt(b, z), pt(a, z + 18), C.steel);
          c.edge(pt(a, z), pt(b, z), C.steelDark);
        }
      c.box(0.2, 0.2, 0.6, 0.6, 4, M.steel, H);
      // Lamp bank facing the pitch.
      c.faceX(-0.3, 0.6, 1.6, H + 4, 26, C.charcoal);
      for (let r = 0; r < 3; r++)
        for (let k = 0; k < 5; k++) {
          const [px, py] = c.at(-0.2 + k * 0.3 + 0.1, 0.601, H + 8 + r * 8);
          c.p.rect(px - 2, py - 5, 5, 5, C.lampGlow);
          c.p.rect(px - 1, py - 4, 3, 3, C.lamp);
        }
      c.edge([-0.3, 0.6, H + 30], [1.3, 0.6, H + 30], C.slate);
    },
  },
  'm-scoreboard': {
    footprint: [3, 0.4],
    h: 92,
    draw(c) {
      for (const x of [0.3, 2.5]) c.box(x, 0.1, 0.2, 0.2, 50, M.steel);
      c.box(0, 0, 3, 0.4, 40, M.dark, 46);
      c.faceX(0.1, 0.401, 2.8, 50, 32, C.screen);
      // Abstract blocks only: two colour panels, bars and a progress strip.
      c.faceX(0.25, 0.402, 0.9, 64, 14, C.red);
      c.faceX(1.85, 0.402, 0.9, 64, 14, C.blue);
      c.faceX(1.3, 0.402, 0.4, 66, 10, C.white);
      for (let k = 0; k < 6; k++)
        c.faceX(
          0.3 + k * 0.42,
          0.402,
          0.28,
          54,
          3 + ((k * 5) % 7),
          [C.glow, C.yellow, C.beat][k % 3],
        );
      c.faceX(0.25, 0.402, 2.5, 52, 1, C.slate);
      c.faceX(0.25, 0.402, 1.6, 52, 1, C.yellow);
    },
  },
  'm-dugout': {
    footprint: [3, 1],
    h: 40,
    draw(c) {
      c.box(0, 0, 3, 0.25, 30, M.white);
      c.box(0.1, 0.3, 2.8, 0.35, 7, M.dark);
      for (let k = 0; k < 7; k++)
        c.box(0.15 + k * 0.4, 0.3, 0.32, 0.3, 3, M.teal, 7);
      for (const x of [0.02, 2.93])
        c.faceY(x + 0.05, 0.25, 0.75, 0, 28, C.glassLight);
      // Curved clear roof from the back wall to the front edge.
      for (let k = 0; k <= 10; k++) {
        const t = k / 10,
          z = 30 - t * t * 12;
        c.top(0, t * 0.95, 3, 0.11, z, k % 3 ? C.glass : C.glassLight);
      }
      c.edge([0, 0.95, 18], [3, 0.95, 18], C.tealDark);
      c.edge([3, 0, 30], [3, 0.95, 18], C.tealDark);
    },
  },
  'm-corner-flag': {
    footprint: [0.3, 0.3],
    h: 30,
    draw(c, f) {
      const [x, y] = c.at(0.15, 0.15);
      c.p.rect(x, y - 24, 1, 24, C.white);
      c.p.pixel(x, y, C.slate);
      c.p.poly(
        [
          [x + 1, y - 24],
          [x + 8, y - 22 + f],
          [x + 1, y - 18],
        ],
        C.yellow,
      );
      c.p.rect(x + 1, y - 23, 3, 1, C.red);
    },
  },
  'm-ball-rack': {
    footprint: [1, 0.6],
    h: 22,
    draw(c) {
      for (const [x, y] of [
        [0.05, 0.05],
        [0.95, 0.05],
        [0.95, 0.55],
        [0.05, 0.55],
      ])
        c.box(x - 0.03, y - 0.03, 0.06, 0.06, 12, M.steel);
      c.top(0, 0, 1, 0.6, 2, C.slate);
      for (let k = 0; k < 6; k++) {
        const [px, py] = c.at(
          0.2 + (k % 3) * 0.3,
          0.15 + Math.floor(k / 3) * 0.3,
          6 + (k % 2) * 4,
        );
        c.p.ellipse(px, py, 3, 3, C.white);
        c.p.rect(px - 1, py - 1, 2, 2, C.charcoal);
        c.p.pixel(px + 2, py + 1, C.silver);
        c.p.pixel(px - 2, py + 2, C.charcoal);
      }
      c.edge([0, 0.6, 12], [1, 0.6, 12], C.steelDark);
      c.edge([1, 0, 12], [1, 0.6, 12], C.steelDark);
    },
  },
};
Object.assign(objects, stadium);

/* ───────────── Fight arena: octagon and boxing ring ───────────── */
// Structures are split into a flat floor-baked base plus thin wall pieces, so
// fighters standing inside sort between the back and front walls. Wall pieces
// are drawn with their foot on the anchor; the room lifts them with object z.
type T2 = [number, number];
const lerp2 = (a: T2, b: T2, t: number): T2 => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
];
/** Plot a tile-space circle at height z (2 px wide, like pitch lines). */
function ring(
  c: IsoCanvas,
  cx: number,
  cy: number,
  r: number,
  z: number,
  col: string,
) {
  const n = Math.ceil(r * 64);
  for (let k = 0; k <= n; k++) {
    const a = (Math.PI * 2 * k) / n,
      [x, y] = c.at(cx + Math.cos(a) * r, cy + Math.sin(a) * r, z);
    c.p.pixel(x, y, col);
    c.p.pixel(x + 1, y, col);
  }
}
/** Padded cage post at a tile point. */
function cagePost(c: IsoCanvas, at: T2, h: number) {
  const [x, y] = c.at(at[0], at[1], 0);
  c.p.rect(x - 1, y - h - 2, 4, h + 3, C.ink);
  c.p.rect(x - 1, y - h - 2, 1, h + 3, C.slate);
  c.p.rect(x - 1, y - h - 3, 4, 2, C.charcoal);
  c.p.rect(x, y - h + 4, 2, 1, C.red);
}
/** See-through chain-link panel between two tile points (a sparse lattice). */
function cagePanel(c: IsoCanvas, a: T2, b: T2, h = 36) {
  const len = Math.hypot(b[0] - a[0], b[1] - a[1]) * 18;
  const sa = c.at(a[0], a[1]),
    sb = c.at(b[0], b[1]);
  const n = Math.max(
    2,
    Math.ceil(Math.hypot(sb[0] - sa[0], sb[1] - sa[1]) * 2),
  );
  for (let k = 0; k <= n; k++) {
    const t = k / n,
      along = t * len,
      [x, y] = c.at(...lerp2(a, b, t));
    for (let up = 3; up < h - 3; up++) {
      const d1 = (((along + up) % 9) + 9) % 9,
        d2 = (((along - up) % 9) + 9) % 9;
      if (d1 < 0.55 || d2 < 0.55)
        c.p.pixel(Math.round(x), Math.round(y - up), C.charcoal);
    }
  }
  // Bottom band and padded top rail with a thin colour stripe.
  const rail = (up: number, r: number, col: string) =>
    c.thick([sa[0], sa[1] - up], [sb[0], sb[1] - up], r, col);
  rail(1, 1, C.ink);
  rail(h - 1, 1.6, C.ink);
  c.line([sa[0], sa[1] - h + 1], [sb[0], sb[1] - h + 1], C.red);
  c.line([sa[0], sa[1] - h - 1], [sb[0], sb[1] - h - 1], C.slate);
  cagePost(c, a, h);
  cagePost(c, b, h);
}
const OCT: T2[] = [
  [1.5, 0],
  [4.5, 0],
  [6, 1.5],
  [6, 4.5],
  [4.5, 6],
  [1.5, 6],
  [0, 4.5],
  [0, 1.5],
];
/** Octagon outline scaled about its centre (3, 3). */
const octScaled = (k: number): T2[] =>
  OCT.map(([x, y]) => [3 + (x - 3) * k, 3 + (y - 3) * k]);
const arena: Record<string, Spec> = {
  'm-octagon-mat': {
    footprint: [6, 6],
    h: 6,
    floor: true,
    draw(c) {
      const Z = 4;
      // Apron side faces, then the canvas on top.
      for (let i = 0; i < OCT.length; i++) {
        const a = OCT[i],
          b = OCT[(i + 1) % OCT.length];
        c.poly(
          [
            [a[0], a[1], 0],
            [b[0], b[1], 0],
            [b[0], b[1], Z],
            [a[0], a[1], Z],
          ],
          b[0] + b[1] > a[0] + a[1] || a[0] > 5 ? C.ink : C.charcoal,
        );
      }
      const top = (pts: T2[], col: string) =>
        c.poly(
          pts.map(([x, y]) => [x, y, Z] as [number, number, number]),
          col,
        );
      top(OCT, C.charcoal);
      top(octScaled(0.94), C.slate);
      top(octScaled(0.88), C.silver);
      top(octScaled(0.82), C.pale);
      // Subtle canvas texture and a faint centre circle.
      for (let k = 0; k < 40; k++) {
        const [x, y] = c.at(
          1 + ((k * 7) % 40) / 10,
          1 + ((k * 13) % 40) / 10,
          Z,
        );
        c.p.pixel(x, y, C.offwhite);
      }
      ring(c, 3, 3, 1.1, Z, C.silver);
      ring(c, 3, 3, 0.25, Z, C.silver);
      // Fighters' corner marks (plain colour).
      for (const [x, y, col] of [
        [1.4, 1.4, C.red],
        [4.6, 4.6, C.blue],
      ] as [number, number, string][]) {
        const [px, py] = c.at(x, y, Z);
        c.p.rect(px - 3, py - 1, 6, 2, col);
      }
    },
  },
  'm-cage-straight': {
    shadow: false,
    footprint: [3, 0.3],
    h: 42,
    side: true,
    draw(c) {
      cagePanel(c, [0, 0.15], [3, 0.15]);
    },
  },
  'm-cage-diag-a': {
    shadow: false,
    footprint: [1.5, 1.5],
    h: 42,
    draw(c) {
      cagePanel(c, [0, 1.5], [1.5, 0]);
    },
  },
  'm-cage-diag-b': {
    shadow: false,
    footprint: [1.5, 1.5],
    h: 42,
    draw(c) {
      cagePanel(c, [0, 0], [1.5, 1.5]);
    },
  },
  'm-ring-base': {
    footprint: [6, 6],
    h: 10,
    floor: true,
    draw(c) {
      const Z = 8;
      // Skirt on the visible faces, with vertical folds and a trim band.
      c.faceX(0, 6, 6, 0, Z, C.navy);
      c.faceY(6, 0, 6, 0, Z, C.blueDark);
      for (let u = 0.25; u < 6; u += 0.5) {
        c.edge([u, 6, 0], [u, 6, Z - 2], C.blueDark);
        c.edge([6, u, 0], [6, u, Z - 2], C.navy);
      }
      c.edge([0, 6, Z - 1], [6, 6, Z - 1], C.blue);
      c.edge([6, 0, Z - 1], [6, 6, Z - 1], C.blue);
      c.edge([0, 6, 0], [6, 6, 0], C.ink);
      c.edge([6, 0, 0], [6, 6, 0], C.ink);
      // Canvas: apron border outside the ropes, then the fighting area.
      c.top(0, 0, 6, 6, Z, C.silver);
      c.top(0.2, 0.2, 5.6, 5.6, Z, C.offwhite);
      c.top(0.6, 0.6, 4.8, 4.8, Z, C.white);
      for (let k = 0; k < 36; k++) {
        const [x, y] = c.at(
          0.8 + ((k * 7) % 44) / 10,
          0.8 + ((k * 11) % 44) / 10,
          Z,
        );
        c.p.pixel(x, y, C.pale);
      }
      c.edge([0, 6, Z], [6, 6, Z], C.pale);
      c.edge([6, 0, Z], [6, 6, Z], C.pale);
      // Corner pads on the canvas: red and blue corners, two neutral.
      for (const [x, y, col] of [
        [0.35, 0.35, C.red],
        [5.65, 5.65, C.blue],
        [5.65, 0.35, C.white],
        [0.35, 5.65, C.white],
      ] as [number, number, string][]) {
        const [px, py] = c.at(x, y, Z);
        c.p.rect(px - 2, py - 1, 5, 2, col);
      }
    },
  },
  'm-ring-ropes': {
    shadow: false,
    footprint: [6, 0.3],
    h: 36,
    side: true,
    draw(c) {
      const v = 0.15,
        ropes: [number, string, string][] = [
          [26, C.red, C.redDark],
          [18, C.white, C.silver],
          [10, C.blue, C.blueDark],
        ];
      for (const [z, col, shade] of ropes) {
        const pts: T2[] = [];
        for (let k = 0; k <= 24; k++) {
          const u = (6 * k) / 24,
            sag = Math.sin((Math.PI * k) / 24) * 1.5;
          pts.push(c.at(u, v, z - sag));
        }
        for (let k = 0; k < pts.length - 1; k++) {
          c.line(pts[k], pts[k + 1], col);
          c.line(
            [pts[k][0], pts[k][1] + 1],
            [pts[k + 1][0], pts[k + 1][1] + 1],
            shade,
          );
        }
      }
      // Padded corner posts at both ends with turnbuckle covers.
      for (const u of [0, 6]) {
        const [x, y] = c.at(u, v, 0);
        c.p.rect(x - 2, y - 30, 5, 31, C.steelDark);
        c.p.rect(x - 2, y - 30, 2, 31, C.steel);
        c.p.rect(x - 3, y - 31, 7, 2, C.slate);
        for (const [z] of ropes) {
          c.p.rect(x - 3, y - z - 2, 7, 4, C.offwhite);
          c.p.rect(x + 2, y - z - 2, 2, 4, C.pale);
        }
      }
    },
  },
  'm-ring-steps': {
    footprint: [1, 1],
    h: 26,
    draw(c) {
      for (let k = 0; k < 3; k++)
        c.box(0.1, k / 3, 0.8, 1 / 3, 9 - k * 3, M.steel);
      for (const x of [0.08, 0.92]) {
        const [px, py] = c.at(x, 0.95);
        c.p.rect(px, py - 18, 1, 18, C.steelDark);
        const [qx, qy] = c.at(x, 0.05, 9);
        c.line([px, py - 18], [qx, qy - 12], C.steelDark);
      }
    },
  },
  'm-corner-stool': {
    footprint: [0.5, 0.5],
    h: 20,
    draw(c) {
      for (const [x, y] of [
        [0.08, 0.08],
        [0.42, 0.08],
        [0.08, 0.42],
        [0.42, 0.42],
      ]) {
        const [px, py] = c.at(x, y);
        c.p.rect(px, py - 11, 1, 11, C.slate);
      }
      c.cylinder(0.25, 0.25, 11, 6, 2, [C.redDark, C.red, C.redDark], C.red);
      // Bucket beside the stool.
      c.cylinder(
        0.45,
        0.5,
        0,
        4,
        6,
        [C.steelLight, C.steel, C.steelDark],
        C.glass,
      );
    },
  },
  'm-ringside-seats': {
    // Person-scale ringside chairs (seat ~14 px); seat real characters on them.
    footprint: [4, 1],
    h: 30,
    side: true,
    draw(c) {
      for (const x of [0.5, 1.5, 2.5, 3.5]) {
        c.box(x - 0.35, 0.12, 0.7, 0.12, 26, M.dark);
        c.top(x - 0.33, 0.13, 0.66, 0.1, 26, C.red);
        c.box(x - 0.35, 0.24, 0.7, 0.55, 3, M.dark, 12);
        c.top(x - 0.3, 0.28, 0.6, 0.46, 15, C.charcoal);
        for (const [dx, dy] of [
          [-0.3, 0.75],
          [0.3, 0.75],
          [-0.3, 0.3],
          [0.3, 0.3],
        ]) {
          const [px, py] = c.at(x + dx, dy);
          c.p.rect(px, py - 12, 1, 12, C.slate);
        }
      }
    },
  },
  'm-commentary-desk': {
    footprint: [3, 1],
    h: 40,
    draw(c) {
      c.box(0, 0.2, 3, 0.8, 20, M.dark);
      c.faceX(0.1, 1.001, 2.8, 4, 12, C.navy);
      for (let k = 0; k < 6; k++)
        c.faceX(0.25 + k * 0.45, 1.002, 0.3, 7, 2 + ((k * 5) % 6), accents[k]);
      for (const x of [0.4, 1.8]) {
        screen(c, x, 0.4, 0.8, 22, 14, x > 1 ? 1 : 0);
        // Headset microphone on the desk.
        const [hx, hy] = c.at(x + 0.6, 0.85, 21);
        c.p.rect(hx - 3, hy - 4, 7, 1, C.ink);
        c.p.rect(hx - 3, hy - 4, 2, 4, C.ink);
        c.p.rect(hx + 2, hy - 4, 2, 4, C.ink);
        c.line([hx - 2, hy], [hx - 5, hy + 2], C.slate);
        c.p.pixel(hx - 5, hy + 2, C.red);
      }
    },
  },
  'm-arena-banner': {
    footprint: [3, 0.3],
    h: 92,
    draw(c) {
      c.box(0, 0, 3, 0.3, 4, M.dark);
      const panels: [string, string][] = [
        [C.red, C.yellow],
        [C.navy, C.teal],
        [C.purple, C.pink],
      ];
      panels.forEach(([bg, fg], i) => {
        const x = 0.1 + i,
          w = 0.8;
        c.faceX(x, 0.15, w, 6, 80, C.ink);
        c.faceX(x + 0.04, 0.16, w - 0.08, 8, 76, bg);
        // Abstract graphics: chevrons, bars and a circle.
        for (let k = 0; k < 4; k++) {
          const [px, py] = c.at(x + w / 2, 0.17, 20 + k * 9);
          c.line([px - 5, py], [px, py - 4], fg);
          c.line([px, py - 4], [px + 5, py], fg);
        }
        const [cx, cy] = c.at(x + w / 2, 0.17, 66);
        c.p.ellipse(cx, cy, 5, 5, fg);
        c.p.ellipse(cx, cy, 3, 3, bg);
        c.faceX(x + 0.1, 0.17, w - 0.2, 12, 3, C.white);
      });
    },
  },
};
Object.assign(objects, arena);

/* ───────────── New York City and the Michigan rally ───────────── */
const NM = {
  limestone: {
    top: CC.skyGlassLight,
    front: CC.duskGlass,
    side: CC.nightGlass,
    edge: C.screen,
  },
  brownstone: {
    top: CC.skyGlass,
    front: CC.duskGlass,
    side: CC.nightGlass,
    edge: C.screen,
  },
  brick: {
    top: CC.skyGlass,
    front: CC.duskGlass,
    side: CC.nightGlass,
    edge: C.screen,
  },
  glass: {
    top: C.glassLight,
    front: C.glass,
    side: C.glassDark,
    edge: C.glassDeep,
  },
  green: {
    top: C.greenDark,
    front: C.green,
    side: C.greenDark,
    edge: C.leafDark,
  },
  taxi: {
    top: C.yellow,
    front: C.yellowDark,
    side: C.taxiShade,
    edge: C.edge,
  },
  navy: { top: C.navy, front: C.navy, side: C.stageNavy, edge: C.ink },
} satisfies Record<string, Material>;
/** Deterministic "is this window lit" pattern. */
const lit = (i: number, j: number) => (i * 7 + j * 13 + i * j) % 5 < 2;
/** Grid of windows on a front (+y) face. */
function windowsFront(
  c: IsoCanvas,
  x0: number,
  x1: number,
  y: number,
  z0: number,
  z1: number,
  step: number,
  row: number,
  w = step * 0.5,
  h = row * 0.55,
  dark: string = C.slate,
) {
  let i = 0;
  for (let u = x0; u + w <= x1 + 1e-6; u += step, i++) {
    let j = 0;
    for (let z = z0; z + h <= z1; z += row, j++)
      c.faceX(u, y, w, z, h, lit(i, j) ? C.windowLit : dark);
  }
}
/** Grid of windows on a side (+x) face. */
function windowsSide(
  c: IsoCanvas,
  x: number,
  y0: number,
  y1: number,
  z0: number,
  z1: number,
  step: number,
  row: number,
  w = step * 0.5,
  h = row * 0.55,
  dark: string = C.charcoal,
) {
  let i = 0;
  for (let v = y0; v + w <= y1 + 1e-6; v += step, i++) {
    let j = 0;
    for (let z = z0; z + h <= z1; z += row, j++)
      c.faceY(x, v, w, z, h, lit(i + 3, j) ? C.yellowDark : dark);
  }
}
/** A setback tier of the art-deco tower: limestone box with piers and windows. */
function decoTier(c: IsoCanvas, o: number, size: number, z: number, h: number) {
  c.box(o, o, size, size, h, NM.limestone, z);
  // Evening: whole floors lit warm or cool, the rest dark glass.
  nightWindowsFront(
    c,
    o + 0.08,
    o + size - 0.05,
    o + size + 0.002,
    z + 4,
    z + h - 3,
    0.22,
    6,
    0.1,
    4,
    z,
  );
  nightWindowsSide(
    c,
    o + size + 0.002,
    o + 0.08,
    o + size - 0.05,
    z + 4,
    z + h - 3,
    0.22,
    6,
    0.1,
    4,
    z,
  );
  // Piers between window columns catch the light; spandrels sit in shade.
  for (let u = o + 0.2; u < o + size - 0.1; u += 0.22) {
    c.edge(
      [u, o + size + 0.003, z + 3],
      [u, o + size + 0.003, z + h - 3],
      CC.skyGlassLight,
    );
    c.edge(
      [o + size + 0.003, u, z + 3],
      [o + size + 0.003, u, z + h - 3],
      CC.skyGlass,
    );
  }
  for (let zz = z + 3; zz < z + h - 3; zz += 6) {
    c.edge(
      [o + 0.05, o + size + 0.003, zz],
      [o + size, o + size + 0.003, zz],
      C.stageNavy,
    );
    c.edge(
      [o + size + 0.003, o + 0.05, zz],
      [o + size + 0.003, o + size, zz],
      C.navy,
    );
  }
  // Lit parapet and a soft shadow where the next tier sits on this roof.
  c.edge([o, o + size, z + h], [o + size, o + size, z + h], CC.skyGlassLight);
  c.edge(
    [o, o + size, z + h - 1],
    [o + size, o + size, z + h - 1],
    CC.skyGlassLight,
  );
  c.faceX(o, o + size + 0.004, size, z + h - 3, 1, C.stageNavy);
}
/** Checkerboard a colour over part of a front (+y) face: soft gradients. */
function ditherFront(
  c: IsoCanvas,
  x0: number,
  x1: number,
  y: number,
  z0: number,
  z1: number,
  col: string,
  density = 0.5,
) {
  const [sx0] = c.at(x0, y, 0),
    [sx1] = c.at(x1, y, 0);
  for (let px = Math.ceil(sx0); px < sx1; px++) {
    const u = x0 + (px - sx0) / 16,
      [, top] = c.at(u, y, z1),
      [, bottom] = c.at(u, y, z0);
    for (let py = Math.ceil(top); py < bottom; py++) {
      const k = (py - top) / Math.max(1, bottom - top);
      const on =
        density >= 0.5
          ? (px + py) % 2 === 0 || ((px + py) % 4 === 1 && k < density - 0.5)
          : px % 2 === 0 && py % 2 === 0 && k < density * 2;
      if (on && c.p.data[(py * c.p.width + px) * 4 + 3]) c.p.pixel(px, py, col);
    }
  }
}
/** A waving flag on a pole. `paint(x, y)` returns the colour of flag pixel (x, y). */
function flag(
  c: IsoCanvas,
  f: number,
  paint: (x: number, y: number, w: number, h: number) => string,
  w = 34,
  h = 21,
) {
  const [px, py] = c.at(0.25, 0.25, 0);
  c.p.rect(px, py - 84, 2, 84, C.silver);
  c.p.rect(px + 1, py - 84, 1, 84, C.steelDark);
  c.p.rect(px - 2, py - 2, 6, 2, C.steelDark);
  c.p.ellipse(px + 1, py - 86, 2.5, 2.5, C.gold);
  const top = py - 82;
  for (let x = 0; x < w; x++) {
    const phase = Math.sin(x * 0.28 + f * Math.PI),
      wave = Math.round(phase * 2 * (x / w));
    for (let y = 0; y < h; y++)
      c.p.pixel(px + 2 + x, top + y + wave, paint(x, y, w, h));
    // A darker hem in the folds.
    if (phase < -0.6) c.p.pixel(px + 2 + x, top + h - 1 + wave, C.edge);
  }
}
const nyc: Record<string, Spec> = {
  'm-skyscraper-deco': {
    footprint: [3, 3],
    h: 292,
    draw(c) {
      c.box(0, 0, 3, 3, 34, NM.limestone);
      // Ground-floor lobby, lit warm behind the glass.
      c.faceX(0.3, 3.002, 2.4, 2, 20, CN.warm);
      c.faceX(0.3, 3.002, 2.4, 16, 4, CN.amber);
      c.faceY(3.002, 0.3, 2.4, 2, 20, CN.warmSide);
      for (let u = 0.45; u < 2.7; u += 0.45) {
        c.faceX(u, 3.003, 0.06, 2, 20, CC.skyGlassLight);
        c.faceY(3.003, u, 0.06, 2, 20, CC.skyGlass);
      }
      c.faceX(0.3, 3.003, 2.4, 14, 1, CC.skyGlassLight);
      c.faceY(3.003, 0.3, 2.4, 14, 1, CC.skyGlass);
      c.edge([0.35, 3.004, 4], [0.7, 3.004, 18], C.lamp);
      c.faceX(0, 3.003, 3, 26, 3, C.gold);
      decoTier(c, 0.25, 2.5, 34, 104);
      decoTier(c, 0.55, 1.9, 138, 58);
      decoTier(c, 0.85, 1.3, 196, 36);
      // Crown with glowing bands, then the needle spire.
      c.box(1.1, 1.1, 0.8, 0.8, 22, NM.limestone, 232);
      for (let z = 236; z < 252; z += 5) {
        c.faceX(1.12, 1.902, 0.76, z, 2, C.windowLit);
        c.faceY(1.902, 1.12, 0.76, z, 2, C.yellow);
      }
      c.cylinder(1.5, 1.5, 254, 4, 14, [
        CC.skyGlassLight,
        CC.skyGlass,
        C.stageNavy,
      ]);
      const [mx, my] = c.at(1.5, 1.5, 268);
      c.p.rect(mx - 1, my - 22, 2, 22, C.silver);
      c.p.rect(mx, my - 22, 1, 22, C.steelDark);
      aircraftLight(c, 1.5, 1.5, 292);
    },
  },
  'm-skyscraper-glass': {
    footprint: [3, 3],
    h: 246,
    draw(c) {
      // Night glass tower: lit window grid in deep blue glass.
      const top = nightTower(c, 0.2, 2.6, 216, 5);
      // Window-cleaning cradle hanging on two cables.
      const [g0x, g0y] = c.at(1.7, 2.9, 168),
        [t0x, t0y] = c.at(1.7, 2.9, top);
      c.line([g0x, g0y], [t0x, t0y], C.steelDark);
      c.line([g0x + 14, g0y + 7], [t0x + 14, t0y + 7], C.steelDark);
      c.box(1.65, 2.82, 0.95, 0.12, 4, M.steel, 162);
      c.edge([1.65, 2.94, 168], [2.6, 2.94, 168], C.steelLight);
      // Rooftop plant room with a lit doorway, vents and a mast.
      c.box(0.9, 0.9, 1.2, 1.2, 10, M.steel, top);
      for (let u = 1.0; u < 2.05; u += 0.15)
        c.edge([u, 2.102, top + 2], [u, 2.102, top + 8], C.slate);
      c.faceY(2.102, 1.2, 0.25, top, 6, CN.warm);
      c.box(0.35, 0.35, 0.3, 0.3, 4, M.steel, top);
      c.box(2.3, 0.4, 0.3, 0.4, 3, M.steel, top);
      const [ax, ay] = c.at(1.5, 1.5, top + 10);
      c.p.rect(ax, ay - 6, 1, 6, C.charcoal);
      aircraftLight(c, 1.5, 1.5, top + 17);
    },
  },
  'm-brownstone': {
    footprint: [4, 2],
    h: 104,
    side: true,
    draw(c) {
      c.box(0, 0, 4, 1.5, 90, NM.brownstone);
      // Dressed brownstone courses on both faces.
      coursesFront(c, 0, 4, 1.501, 0, 88, 6, 0.5, C.navy, CC.skyGlassLight);
      coursesSide(c, 4.001, 0, 1.5, 0, 88, 6, 0.5, C.navy);
      // Bracketed cornice.
      c.box(0, 0, 4, 1.62, 6, NM.brownstone, 88);
      c.faceX(0, 1.621, 4, 88, 2, CC.skyGlassLight);
      for (let u = 0.05; u < 4; u += 0.25)
        c.faceX(u, 1.622, 0.1, 84, 4, C.navy);
      c.edge([0, 1.622, 93], [4, 1.622, 93], CC.skyGlassLight);
      // Street-level hanging light boxes and a slim roofline reflection.
      c.edge([0.05, 1.625, 91], [3.95, 1.625, 91], C.teal);
      neonPanelFront(c, 3.6, 1.626, 0.28, 38, 30, false);
      for (let k = 0; k < 3; k++) {
        const x = 0.15 + k * 1.3;
        // Two sash windows per floor with lintels, sills and curtains.
        for (const z of [34, 56, 74])
          for (const dx of [0.15, 0.75]) {
            // Evening: about half the rooms are lit.
            const warm = cityHash(k * 2 + (dx > 0.5 ? 1 : 0), z, 3) < 0.5;
            sashFront(c, x + dx + 0.03, 1.502, 0.26, z + 1, 9, {
              frame: CC.skyGlassLight,
              glass: warm ? C.windowLit : CN.glass3,
              shade: warm ? C.yellowDark : CN.glass1,
              glint: warm ? undefined : CN.cool,
              sill: CC.skyGlass,
              bars: true,
              inside: (k + z + dx * 4) % 3 === 0 ? C.cream : undefined,
            });
            c.faceX(x + dx - 0.02, 1.503, 0.36, z + 12, 2, CC.skyGlass);
            c.edge(
              [x + dx - 0.02, 1.504, z + 13],
              [x + dx + 0.34, 1.504, z + 13],
              CC.skyGlassLight,
            );
          }
        // A window air-conditioner on an upper floor.
        const acX = x + (k % 2 ? 0.18 : 0.78),
          acZ = k === 1 ? 74 : 56;
        c.box(acX, 1.5, 0.22, 0.12, 5, M.steel, acZ + 1);
        c.faceX(acX + 0.02, 1.621, 0.18, acZ + 2, 3, C.steelDark);
        for (let g = 0; g < 3; g++)
          c.faceX(acX + 0.04 + g * 0.05, 1.622, 0.02, acZ + 2, 3, C.steel);
        // A window box of flowers on the parlour floor.
        c.box(x + 0.7, 1.5, 0.42, 0.1, 3, NM.brownstone, 31);
        for (let i = 0; i < 6; i++) {
          const [fx, fy] = c.at(x + 0.73 + i * 0.065, 1.56, 35);
          c.p.rect(fx, fy - 2, 2, 2, i % 2 ? C.leaf : C.leafDark);
          if (i % 2 === 0)
            c.p.pixel(fx, fy - 3, [C.pink, C.red, C.yellow][(i + k) % 3]);
        }
        // Stoop up to the front door, with black railings.
        for (let s2 = 0; s2 < 4; s2++) {
          c.box(
            x + 0.12,
            1.5,
            0.42,
            0.12 * (4 - s2),
            4 + s2 * 3.5,
            NM.brownstone,
          );
          c.edge(
            [x + 0.12, 1.5 + 0.12 * (4 - s2), 4 + s2 * 3.5],
            [x + 0.54, 1.5 + 0.12 * (4 - s2), 4 + s2 * 3.5],
            CC.skyGlassLight,
          );
        }
        // Panelled door under a fanlight.
        c.faceX(x + 0.16, 1.502, 0.34, 16, 22, CC.skyGlass);
        c.faceX(x + 0.18, 1.503, 0.3, 16, 18, C.woodDark);
        c.faceX(x + 0.21, 1.504, 0.1, 18, 6, C.wood);
        c.faceX(x + 0.21, 1.504, 0.1, 26, 6, C.wood);
        c.faceX(x + 0.18, 1.503, 0.3, 34, 3, C.windowLit);
        const [kx, ky] = c.at(x + 0.42, 1.505, 26);
        c.p.pixel(kx, ky, C.gold);
        for (const rx of [x + 0.12, x + 0.54]) {
          c.edge([rx, 1.98, 12], [rx, 1.5, 26], C.ink);
          c.edge([rx, 1.98, 9], [rx, 1.5, 23], C.charcoal);
          post(c, rx, 1.98, 4, 8, C.ink);
        }
        // Garden-level window with bars, and a bin by the railings.
        c.faceX(x + 0.72, 1.502, 0.36, 4, 9, k === 2 ? CN.amber : CN.glass1);
        for (let i = 1; i < 4; i++)
          c.edge(
            [x + 0.72 + i * 0.09, 1.503, 4],
            [x + 0.72 + i * 0.09, 1.503, 13],
            C.ink,
          );
        c.cylinder(x + 1.18, 1.82, 0, 3, 7, R.dark);
      }
      windowsSide(c, 4.002, 0.2, 1.4, 34, 84, 0.45, 20, 0.22, 11);
      for (let v = 0.2; v < 1.4; v += 0.45)
        for (let z = 34; z < 84; z += 20)
          c.faceY(4.003, v - 0.02, 0.26, z - 2, 2, C.stageNavy);
    },
  },
  'm-bodega': {
    footprint: [3, 1],
    h: 72,
    draw(c) {
      // Warm light from the shop spills onto the pavement.
      lightPool(c, 1.2, 1.05, 40, 8, 0.6);
      c.box(0, 0, 3, 0.8, 62, NM.brick);
      // Plain colour sign band above the awning (no text).
      c.faceX(0.1, 0.802, 2.8, 40, 7, C.navy);
      c.edge([0.1, 0.803, 40], [2.9, 0.803, 40], C.glow);
      c.edge([0.1, 0.803, 47], [2.9, 0.803, 47], C.glow);
      for (let k = 0; k < 6; k++)
        c.faceX(0.24 + k * 0.44, 0.804, 0.29, 42, 2, k % 2 ? C.pink : C.glow);
      windowsFront(c, 0.3, 2.8, 0.802, 50, 60, 0.6, 12, 0.3, 8);
      // Shopfront glass, lit warm, with shelves of goods behind.
      c.faceX(0.15, 0.802, 2.0, 4, 26, CN.hot);
      c.faceX(0.15, 0.802, 2.0, 24, 6, CN.amber);
      for (const z of [7, 14, 21])
        c.faceX(0.18, 0.8025, 1.94, z, 1, C.woodDark);
      for (let k = 0; k < 14; k++)
        c.faceX(
          0.2 + k * 0.14,
          0.803,
          0.08,
          8 + (k % 3) * 7,
          4,
          accents[k % accents.length],
        );
      c.faceX(2.3, 0.802, 0.5, 4, 26, C.greenDark);
      c.faceX(2.35, 0.803, 0.4, 6, 18, CN.warm);
      c.faceX(2.45, 0.804, 0.2, 4, 4, C.ink);
      // Striped awning projecting over the pavement.
      for (let i = 0; i < 10; i++) {
        const col = i % 2 ? C.white : C.red;
        c.poly(
          [
            [i * 0.3, 0.8, 38],
            [i * 0.3 + 0.3, 0.8, 38],
            [i * 0.3 + 0.3, 1.0, 33],
            [i * 0.3, 1.0, 33],
          ],
          col,
        );
        c.faceX(i * 0.3, 1.0, 0.3, 30, 3, i % 2 ? C.offwhite : C.redDark);
      }
      c.faceY(3.002, 0, 0.8, 4, 56, CN.glass0);
      neonPanelFront(c, 2.75, 0.805, 0.23, 19, 32, false);
      // Crates of fruit and flowers on the pavement.
      const crate = (x: number, fruit: string) => {
        c.box(x, 0.84, 0.34, 0.14, 6, M.wood);
        for (let k = 0; k < 4; k++) {
          const [fx, fy] = c.at(x + 0.06 + k * 0.08, 0.9, 7);
          c.p.ellipse(fx, fy, 1.5, 1.5, fruit);
        }
      };
      crate(0.15, C.red);
      crate(0.55, C.orange);
      crate(0.95, C.yellow);
      crate(1.35, C.green);
      for (const [x, col] of [
        [1.8, C.pink],
        [2.05, C.purple],
      ] as [number, string][]) {
        c.cylinder(x, 0.92, 0, 2.5, 6, R.steel);
        c.greenery(x, 0.92, 10, 4, [C.pink, col, C.pinkDark]);
      }
    },
  },
  'm-halal-cart': {
    footprint: [2, 1],
    h: 56,
    frames: 4,
    draw(c, f) {
      for (const [x, y] of [
        [0.45, 0.78],
        [1.55, 0.78],
      ] as [number, number][]) {
        const [wx, wy] = c.at(x, y, 3);
        c.p.ellipse(wx, wy, 3, 3, C.ink);
        c.p.pixel(wx, wy, C.silver);
      }
      c.box(0.3, 0.2, 1.4, 0.55, 15, M.steel, 4);
      c.faceX(0.35, 0.752, 1.3, 8, 6, C.yellow);
      c.faceX(0.35, 0.753, 1.3, 8, 1, C.red);
      c.top(0.35, 0.25, 1.3, 0.45, 19.5, C.charcoal);
      for (let k = 0; k < 5; k++) {
        const [gx, gy] = c.at(0.5 + k * 0.25, 0.45, 20);
        c.p.rect(gx - 2, gy - 1, 4, 2, k % 2 ? C.terracotta : C.rice);
      }
      // Steam rising from the grill (animated).
      for (let k = 0; k < 4; k++) {
        const t = (f + k) % 4,
          [sx, sy] = c.at(0.6 + k * 0.25, 0.4, 24 + t * 5);
        c.p.ellipse(
          sx + (t % 2),
          sy,
          2 + t * 0.5,
          1.5 + t * 0.3,
          t > 2 ? C.pale : C.offwhite,
        );
      }
      post(c, 1.0, 0.45, 20, 20, C.steelDark, 2);
      // Big striped umbrella.
      const [ux, uy] = c.at(1.0, 0.45, 42);
      for (let k = 0; k < 8; k++) {
        const a0 = (k / 8) * Math.PI * 2,
          a1 = ((k + 1) / 8) * Math.PI * 2;
        c.p.poly(
          [
            [ux, uy - 4],
            [ux + Math.cos(a0) * 27, uy + Math.sin(a0) * 10],
            [ux + Math.cos(a1) * 27, uy + Math.sin(a1) * 10],
          ],
          [C.red, C.yellow, C.blue, C.white][k % 4],
        );
      }
      c.p.ellipse(ux, uy - 4, 2, 1, C.white);
      // Little stools for customers.
      for (const x of [0.15, 1.85]) {
        c.cylinder(x, 0.9, 0, 2, 7, R.steel);
        const [tx, ty] = c.at(x, 0.9, 8);
        c.p.ellipse(tx, ty, 3, 1.5, C.red);
      }
    },
  },
  'm-city-hall': {
    footprint: [6, 3],
    h: 150,
    draw(c) {
      const pane: Sash = {
        frame: C.pale,
        glass: C.glassDark,
        shade: C.glassDeep,
        glint: C.glassLight,
        sill: C.silver,
        bars: true,
      };
      // Wings and central block in pale stone, rusticated below the cornice.
      c.box(0, 0.8, 1.3, 1.7, 52, M.white);
      c.box(4.7, 0.8, 1.3, 1.7, 52, M.white);
      c.box(1.3, 0.5, 3.4, 2.0, 64, M.white);
      for (const x of [0, 4.7])
        coursesFront(c, x, x + 1.3, 2.501, 0, 46, 6, 0.42, C.pale, C.white);
      coursesSide(c, 6.001, 0.8, 2.5, 0, 46, 6, 0.42, C.silver);
      coursesFront(c, 1.3, 4.7, 2.501, 0, 58, 6, 0.42, C.pale, C.white);
      for (const x of [0, 4.7]) {
        c.faceX(x, 2.501, 1.3, 0, 3, C.pale);
        c.faceX(x, 2.502, 1.3, 46, 2, C.silver);
        c.faceX(x, 2.502, 1.3, 48, 4, C.white);
      }
      // A few offices still lit in the evening.
      const litPane: Sash = {
        ...pane,
        glass: C.windowLit,
        shade: C.yellowDark,
        glint: undefined,
      };
      for (const x of [0.15, 4.85])
        for (const z of [12, 32])
          for (const dx of [0, 0.5]) {
            const on = x > 1 !== (z === 12) ? dx === 0 : dx > 0;
            sashFront(c, x + dx, 2.503, 0.3, z, 12, on ? litPane : pane);
            const [ax, ay] = c.at(x + dx + 0.15, 2.504, z + 13);
            c.p.ellipse(ax + 2, ay, 3, 2.5, C.pale);
            c.p.ellipse(ax + 2, ay, 2, 1.5, C.glassDark);
            c.p.pixel(ax + 2, ay - 3, C.silver);
          }
      for (const v of [1.0, 1.5, 2.0])
        for (const z of [12, 32])
          sashSide(c, 6.003, v, 0.24, z, 12, {
            ...pane,
            frame: C.silver,
            glass: C.glassDeep,
            glint: C.glass,
          });
      // Balustrade along the roofline, with rooftop vents on the wings.
      c.faceX(1.3, 2.502, 3.4, 58, 6, C.white);
      c.edge([1.3, 2.503, 58], [4.7, 2.503, 58], C.silver);
      for (let u = 1.35; u < 4.7; u += 0.18) {
        post(c, u, 2.5, 64, 4, C.pale);
        post(c, u + 0.04, 2.5, 64, 4, C.silver);
      }
      c.faceX(1.3, 2.5, 3.4, 68, 2, C.offwhite);
      c.box(0.3, 1.0, 0.4, 0.3, 5, M.steel, 52);
      c.box(5.2, 1.1, 0.5, 0.4, 4, M.steel, 52);
      // Portico: a plain pediment and entablature on six fluted columns.
      c.faceX(2.3, 2.502, 1.4, 6, 30, C.glassDeep);
      for (let k = 0; k < 3; k++) {
        c.faceX(2.38 + k * 0.45, 2.503, 0.36, 6, 22, C.woodDark);
        c.faceX(2.42 + k * 0.45, 2.504, 0.12, 8, 18, C.wood);
        c.faceX(2.38 + k * 0.45, 2.504, 0.36, 28, 6, CN.warm);
      }
      c.box(1.6, 2.4, 2.8, 0.3, 7, M.white, 44);
      c.faceX(1.6, 2.701, 2.8, 47, 2, C.pale);
      for (let u = 1.65; u < 4.4; u += 0.16)
        c.faceX(u, 2.702, 0.08, 44, 2, C.silver);
      c.poly(
        [
          [1.55, 2.7, 51],
          [4.45, 2.7, 51],
          [3.0, 2.7, 64],
        ],
        C.white,
      );
      c.poly(
        [
          [1.85, 2.701, 52],
          [4.15, 2.701, 52],
          [3.0, 2.701, 61],
        ],
        C.pale,
      );
      c.edge([1.55, 2.702, 51], [3.0, 2.702, 64], C.white);
      c.edge([3.0, 2.702, 64], [4.45, 2.702, 51], C.silver);
      for (let k = 0; k < 6; k++) {
        const [px, py] = c.at(1.75 + k * 0.5, 2.62, 6);
        c.p.rect(px - 2, py - 38, 5, 38, C.offwhite);
        c.p.rect(px - 2, py - 38, 1, 38, C.white);
        c.p.rect(px, py - 38, 1, 38, C.pale);
        c.p.rect(px + 2, py - 38, 1, 38, C.silver);
        c.p.rect(px - 3, py - 40, 7, 2, C.white);
        c.p.rect(px - 3, py - 38, 7, 1, C.pale);
        c.p.rect(px - 3, py - 2, 7, 2, C.pale);
      }
      for (let k = 0; k < 3; k++)
        c.box(
          1.4 - k * 0.1,
          2.5 + k * 0.17,
          3.2 + k * 0.2,
          0.17,
          6 - k * 2,
          M.stone,
        );
      // Lamp posts and clipped shrubs flanking the steps.
      for (const x of [1.15, 4.85]) {
        c.box(x - 0.12, 2.7, 0.24, 0.24, 6, M.stone);
        c.greenery(x, 2.82, 10, 5, R.leaf);
      }
      for (const x of [1.45, 4.55]) {
        const [lx, ly] = c.at(x, 2.98, 0);
        c.p.rect(lx, ly - 26, 2, 26, C.charcoal);
        c.p.rect(lx - 2, ly - 31, 6, 5, C.charcoal);
        c.p.rect(lx - 1, ly - 30, 4, 3, C.lamp);
        c.p.rect(lx - 1, ly - 2, 4, 2, C.ink);
      }
      // Cupola: drum with arched lights, ribbed cap and a plain knob.
      c.cylinder(3.0, 1.5, 64, 12, 22, R.white);
      for (let k = 0; k < 5; k++) {
        const [wx, wy] = c.at(2.7 + k * 0.14, 1.5 + 0.5, 70);
        c.p.rect(wx - 1, wy - 13, 3, 12, C.pale);
        c.p.rect(wx - 1, wy - 12, 2, 10, C.windowLit);
        c.p.pixel(wx - 1, wy - 11, C.lamp);
      }
      c.cylinder(3.0, 1.5, 86, 9, 10, R.white);
      const [dx, dy] = c.at(3.0, 1.5, 96);
      c.p.ellipse(dx, dy, 9, 7, C.offwhite);
      c.p.ellipse(dx - 3, dy - 2, 4, 3, C.white);
      for (const o of [-5, 0, 5])
        c.line([dx + o, dy + 3], [dx + o / 2, dy - 6], C.pale);
      c.p.rect(dx - 1, dy - 14, 3, 8, C.pale);
      c.p.rect(dx - 2, dy - 19, 5, 5, C.gold);
      c.p.pixel(dx - 1, dy - 18, C.yellow);
    },
  },
  'm-subway-entrance': {
    footprint: [2, 1],
    h: 40,
    draw(c) {
      c.top(0.2, 0.15, 1.6, 0.7, 0, C.ink);
      for (let k = 0; k < 6; k++)
        c.edge(
          [0.25, 0.2 + k * 0.11, 0],
          [1.75, 0.2 + k * 0.11, 0],
          C.charcoal,
        );
      // Green railings round three sides.
      for (const [a, b] of [
        [
          [0.15, 0.1],
          [1.85, 0.1],
        ],
        [
          [0.15, 0.1],
          [0.15, 0.9],
        ],
        [
          [1.85, 0.1],
          [1.85, 0.9],
        ],
      ] as [[number, number], [number, number]][]) {
        c.edge(
          [...a, 12] as [number, number, number],
          [...b, 12] as [number, number, number],
          C.greenDark,
        );
        c.edge(
          [...a, 6] as [number, number, number],
          [...b, 6] as [number, number, number],
          C.greenDark,
        );
        for (let t = 0; t <= 1.001; t += 0.25)
          post(
            c,
            a[0] + (b[0] - a[0]) * t,
            a[1] + (b[1] - a[1]) * t,
            0,
            12,
            C.greenDark,
          );
      }
      // Two round globe lamps on posts.
      for (const x of [0.15, 1.85]) {
        post(c, x, 0.9, 0, 30, C.greenDark, 2);
        const [gx, gy] = c.at(x, 0.9, 33);
        c.p.ellipse(gx + 1, gy, 3.5, 3.5, C.green);
        c.p.ellipse(gx, gy - 1, 1.5, 1.5, C.lime);
      }
    },
  },
  'm-taxi': {
    footprint: [2, 1],
    h: 26,
    side: true,
    draw(c) {
      for (const [x, y] of [
        [0.45, 0.8],
        [1.5, 0.8],
        [1.55, 0.22],
      ] as [number, number][]) {
        const [wx, wy] = c.at(x, y, 3);
        c.p.ellipse(wx, wy, 3.5, 2.5, C.ink);
        c.p.pixel(wx, wy, C.slate);
      }
      c.box(0.15, 0.2, 1.7, 0.6, 8, NM.taxi, 3);
      c.box(0.5, 0.26, 0.95, 0.48, 7, NM.taxi, 11);
      c.faceX(0.55, 0.742, 0.4, 12, 5, C.glassDark);
      c.faceX(1.0, 0.742, 0.4, 12, 5, C.glassDark);
      c.faceY(1.452, 0.3, 0.4, 12, 5, C.glassDeep);
      // Checker stripe along the doors.
      for (let k = 0; k < 16; k++)
        c.faceX(
          0.2 + k * 0.1,
          0.801,
          0.05,
          6 + (k % 2),
          1,
          k % 2 ? C.ink : C.white,
        );
      c.box(0.85, 0.42, 0.25, 0.16, 3, M.white, 18);
      c.faceY(1.852, 0.3, 0.12, 6, 2, C.lamp);
      c.faceY(1.852, 0.62, 0.12, 6, 2, C.lamp);
      c.faceY(1.852, 0.42, 0.18, 4, 2, C.charcoal);
    },
  },
  'm-water-tower': {
    footprint: [1, 1],
    h: 96,
    draw(c) {
      const legs: [number, number][] = [
        [0.2, 0.2],
        [0.8, 0.2],
        [0.2, 0.8],
        [0.8, 0.8],
      ];
      for (const [x, y] of legs) post(c, x, y, 0, 50, C.steelDark, 2);
      c.edge([0.2, 0.8, 8], [0.8, 0.8, 44], C.steel);
      c.edge([0.8, 0.8, 8], [0.2, 0.8, 44], C.steel);
      c.edge([0.8, 0.2, 8], [0.8, 0.8, 44], C.steelDark);
      c.edge([0.8, 0.8, 8], [0.8, 0.2, 44], C.steelDark);
      c.cylinder(
        0.5,
        0.5,
        50,
        14,
        28,
        [C.woodLight, C.wood, C.woodDark],
        C.wood,
      );
      for (let z = 54; z < 78; z += 7) {
        const [hx, hy] = c.at(0.5, 0.5, z);
        for (let i = -14; i <= 14; i++)
          c.p.pixel(
            hx + i,
            hy + Math.sqrt(Math.max(0, 1 - (i / 14) ** 2)) * 7,
            C.ink,
          );
      }
      const [tx, ty] = c.at(0.5, 0.5, 78);
      c.p.poly(
        [
          [tx - 15, ty],
          [tx + 15, ty],
          [tx, ty - 16],
        ],
        C.woodDark,
      );
      c.p.poly(
        [
          [tx - 15, ty],
          [tx, ty],
          [tx, ty - 16],
        ],
        C.wood,
      );
      c.p.ellipse(tx, ty, 15, 3, C.woodDark);
    },
  },
  'm-hydrant': {
    footprint: [0.5, 0.5],
    h: 20,
    draw(c) {
      c.cylinder(0.25, 0.25, 0, 4, 12, [C.red, C.red, C.redDark]);
      const [hx, hy] = c.at(0.25, 0.25, 12);
      c.p.ellipse(hx, hy - 1, 4, 3, C.redDark);
      c.p.ellipse(hx, hy - 2, 2, 1.5, C.red);
      c.p.rect(hx - 6, hy + 4, 3, 3, C.red);
      c.p.rect(hx + 4, hy + 4, 3, 3, C.redDark);
      c.p.rect(hx - 1, hy + 6, 3, 3, C.silver);
      c.p.pixel(hx - 2, hy + 2, C.pink);
    },
  },
  'm-newsstand': {
    footprint: [2, 1],
    h: 50,
    draw(c) {
      c.box(0.15, 0.15, 1.7, 0.7, 40, NM.green);
      c.box(0.05, 0.08, 1.9, 0.86, 4, M.dark, 40);
      c.faceX(0.4, 0.852, 1.2, 18, 14, C.ink);
      c.faceX(0.45, 0.853, 1.1, 18, 12, C.screen);
      // Rows of colourful magazines (plain colour blocks).
      for (let row = 0; row < 3; row++)
        for (let k = 0; k < 9; k++)
          c.faceX(
            0.25 + k * 0.17,
            0.854,
            0.12,
            4 + row * 5,
            4,
            accents[(k + row * 3) % accents.length],
          );
      for (let k = 0; k < 7; k++)
        c.faceX(
          0.45 + k * 0.15,
          0.854,
          0.1,
          34,
          4,
          accents[(k + 5) % accents.length],
        );
      windowsSide(c, 1.852, 0.25, 0.8, 8, 36, 0.18, 7, 0.1, 5, C.ink);
    },
  },
  'm-crosswalk': {
    footprint: [3, 1],
    h: 2,
    floor: true,
    side: true,
    draw(c) {
      for (let i = 0; i < 6; i++)
        c.top(0.08 + i * 0.5, 0.08, 0.3, 0.84, 0, C.line);
    },
  },
  /* Michigan victory rally. */
  'm-stage-base': {
    footprint: [7, 3],
    h: 10,
    floor: true,
    draw(c) {
      c.top(0, 0, 7, 3, 8, C.oak);
      for (let v = 0.25; v < 3; v += 0.25) c.edge([0, v, 8], [7, v, 8], C.wood);
      for (let u = 0.9; u < 7; u += 1.4)
        c.edge([u, 0, 8], [u, 3, 8], C.woodLight);
      c.faceX(0, 3, 7, 0, 8, C.navy);
      c.faceY(7, 0, 3, 0, 8, C.stageNavy);
      // Pleated skirt and lit board ends.
      for (let u = 0.12; u < 7; u += 0.24)
        c.edge([u, 3.001, 0], [u, 3.001, 7], C.stageNavy);
      for (let v = 0.12; v < 3; v += 0.24)
        c.edge([7.001, v, 0], [7.001, v, 7], C.ink);
      c.edge([0, 3, 8], [7, 3, 8], C.woodLight);
      c.edge([7, 0, 8], [7, 3, 8], C.wood);
      // Gaffer-taped cable runs across the boards.
      c.edge([0.6, 0.5, 8], [2.4, 1.6, 8], C.ink);
      c.edge([4.8, 0.45, 8], [6.4, 1.1, 8], C.ink);
    },
  },
  'm-stage-backdrop': {
    footprint: [7, 0.4],
    h: 122,
    draw(c) {
      c.box(0, 0, 7, 0.4, 108, M.wood);
      for (let u = 0.1; u < 7; u += 0.2)
        c.faceX(
          u,
          0.402,
          0.06,
          8,
          98,
          Math.round(u * 5) % 2 ? C.woodDark : C.woodLight,
        );
      c.faceX(0, 0.403, 7, 0, 8, C.navy);
      for (let u = 0.1; u < 7; u += 0.2)
        c.edge([u, 0.404, 0], [u, 0.404, 7], C.stageNavy);
      // Navy drapes at both ends, folded.
      for (const x0 of [0, 6.4])
        for (let k = 0; k < 6; k++)
          c.faceX(
            x0 + k * 0.1,
            0.404,
            0.1,
            8,
            98,
            k % 2 ? C.stageNavy : C.navy,
          );
      // Lighting truss with stage lamps.
      c.box(-0.05, 0.1, 7.1, 0.2, 2, M.steel, 112);
      c.box(-0.05, 0.1, 7.1, 0.2, 2, M.steel, 118);
      for (let u = 0; u <= 7.01; u += 0.25) {
        c.edge([u, 0.3, 112], [u + 0.25, 0.3, 120], C.steelDark);
        c.edge([u, 0.3, 120], [u + 0.25, 0.3, 112], C.steelDark);
      }
      for (let k = 0; k < 7; k++) {
        const [lx, ly] = c.at(0.5 + k, 0.45, 108);
        c.p.rect(lx - 2, ly - 4, 5, 5, C.charcoal);
        c.p.rect(lx - 1, ly, 3, 1, C.lamp);
        c.p.pixel(lx, ly + 1, C.lampGlow);
      }
    },
  },
  'm-podium': {
    footprint: [1, 0.6],
    h: 44,
    draw(c) {
      c.box(0.2, 0.1, 0.6, 0.4, 24, M.wood);
      c.poly(
        [
          [0.15, 0.05, 24],
          [0.85, 0.05, 24],
          [0.85, 0.55, 28],
          [0.15, 0.55, 28],
        ],
        C.woodLight,
      );
      c.faceX(0.25, 0.502, 0.5, 6, 16, C.blueDark);
      c.faceX(0.28, 0.503, 0.44, 8, 12, C.blue);
      c.faceX(0.28, 0.504, 0.44, 19, 1, C.white);
      // Microphone on a gooseneck stand.
      const [mx, my] = c.at(0.5, 0.2, 28);
      c.p.rect(mx, my - 8, 1, 8, C.ink);
      c.line([mx, my - 8], [mx + 3, my - 12], C.ink);
      c.p.ellipse(mx + 4, my - 13, 2, 1.5, C.charcoal);
      c.p.pixel(mx + 3, my - 14, C.slate);
    },
  },
  'm-us-flag': {
    footprint: [0.5, 0.5],
    h: 92,
    frames: 2,
    draw(c, f) {
      flag(c, f, (x, y, w, h) => {
        // Blue canton with a grid of tiny white dots; red and white stripes.
        if (x < w * 0.42 && y < Math.round((h * 7) / 13))
          return x % 3 === 1 && y % 2 === 1 ? C.white : C.navy;
        return Math.floor((y * 13) / h) % 2 ? C.white : C.red;
      });
    },
  },
  'm-state-flag': {
    footprint: [0.5, 0.5],
    h: 92,
    frames: 2,
    draw(c, f) {
      flag(c, f, (x, y, w, h) =>
        y === 0 || y === h - 1 || x === w - 1 ? C.stageNavy : C.navy,
      );
    },
  },
  'm-speaker-stack': {
    footprint: [1, 1],
    h: 54,
    draw(c) {
      c.edge([0.5, 0.5, 12], [0.2, 0.8, 0], C.ink);
      c.edge([0.5, 0.5, 12], [0.8, 0.8, 0], C.ink);
      c.edge([0.5, 0.5, 12], [0.5, 0.2, 0], C.ink);
      for (const z of [12, 32]) {
        c.box(0.25, 0.3, 0.5, 0.4, 18, M.dark, z);
        for (const dz of [5, 13]) {
          const [sx, sy] = c.at(0.5, 0.701, z + dz);
          c.p.ellipse(sx, sy, dz === 5 ? 4 : 2.5, dz === 5 ? 3 : 2, C.slate);
          c.p.ellipse(sx, sy, 1.2, 1, C.ink);
        }
      }
    },
  },
  'm-camera-riser': {
    footprint: [2, 1],
    h: 48,
    draw(c) {
      c.box(0, 0, 2, 1, 12, M.dark);
      c.faceX(0.05, 1.002, 1.9, 2, 8, C.stageNavy);
      for (const x of [0.5, 1.4]) {
        for (const [dx, dy] of [
          [-0.15, 0.15],
          [0.15, 0.15],
          [0, -0.15],
        ])
          c.edge([x, 0.5, 30], [x + dx, 0.5 + dy, 12], C.charcoal);
        c.box(x - 0.18, 0.38, 0.36, 0.24, 9, M.dark, 30);
        c.faceY(x + 0.182, 0.42, 0.14, 32, 5, C.glassDeep);
        c.faceX(x - 0.12, 0.622, 0.12, 33, 4, C.glow);
        const [rx, ry] = c.at(x - 0.1, 0.4, 40);
        c.p.pixel(rx, ry, C.red);
      }
    },
  },
  'm-brick-building': {
    footprint: [4, 2],
    h: 128,
    side: true,
    draw(c) {
      c.box(0, 0, 4, 1.8, 114, NM.brick);
      // Mortar courses.
      for (let z = 4; z < 112; z += 3) {
        c.edge([0, 1.801, z], [4, 1.801, z], C.brickDark);
        c.edge([4.001, 0, z], [4.001, 1.8, z], C.brickDark);
      }
      // Arched upper windows.
      for (let row = 0; row < 3; row++)
        for (let k = 0; k < 6; k++) {
          const x = 0.2 + k * 0.63,
            z = 44 + row * 22;
          c.faceX(x, 1.802, 0.34, z, 13, C.cream);
          c.faceX(
            x + 0.04,
            1.803,
            0.26,
            z + 1,
            11,
            lit(k, row) ? C.windowLit : C.glassDark,
          );
          const [ax, ay] = c.at(x + 0.17, 1.803, z + 13);
          c.p.ellipse(ax + 2, ay - 1, 3, 2.5, C.cream);
          c.p.ellipse(ax + 2, ay - 1, 2, 1.5, C.glassDark);
        }
      // Stone sills under every upper window.
      for (let row = 0; row < 3; row++)
        for (let k = 0; k < 6; k++)
          c.faceX(0.17 + k * 0.63, 1.804, 0.4, 42 + row * 22, 2, C.limestone);
      windowsSide(c, 4.002, 0.2, 1.6, 44, 108, 0.4, 22, 0.2, 12, C.glassDark);
      // Fire escape down the middle bays: landings, railings and ladders.
      for (let row = 0; row < 3; row++) {
        const z = 41 + row * 22;
        c.box(1.4, 1.8, 1.3, 0.32, 1, M.dark, z);
        for (let u = 1.4; u <= 2.71; u += 0.13)
          c.edge([u, 2.12, z + 1], [u, 2.12, z + 8], C.charcoal);
        c.edge([1.4, 2.12, z + 8], [2.7, 2.12, z + 8], C.ink);
        c.edge([1.4, 2.12, z + 4], [2.7, 2.12, z + 4], C.charcoal);
        if (row > 0) {
          c.edge([2.3, 2.0, z], [2.6, 2.0, z - 21], C.ink);
          c.edge([2.4, 2.0, z], [2.7, 2.0, z - 21], C.ink);
          for (let r = 3; r < 21; r += 3)
            c.edge(
              [2.3 + r * 0.0143, 2.0, z - r],
              [2.4 + r * 0.0143, 2.0, z - r],
              C.charcoal,
            );
        }
      }
      // Shopfronts with green awnings.
      for (let k = 0; k < 3; k++) {
        const x = 0.15 + k * 1.3;
        c.faceX(x, 1.802, 1.1, 4, 24, C.glassDark);
        c.faceX(x + 0.05, 1.803, 1.0, 6, 3, C.glassLight);
        c.poly(
          [
            [x - 0.05, 1.8, 32],
            [x + 1.15, 1.8, 32],
            [x + 1.15, 2.0, 28],
            [x - 0.05, 2.0, 28],
          ],
          C.greenDark,
        );
      }
      // Cornice, parapet, rooftop air-conditioners and a small water tank.
      c.box(0, 0, 4, 1.86, 4, M.stone, 114);
      for (let u = 0.1; u < 4; u += 0.3)
        c.faceX(u, 1.861, 0.15, 112, 2, C.stoneShade);
      for (const [x, y] of [
        [0.5, 0.6],
        [1.3, 1.0],
      ]) {
        c.box(x, y, 0.45, 0.35, 6, M.steel, 118);
        for (let u = x + 0.06; u < x + 0.42; u += 0.07)
          c.edge([u, y + 0.351, 119], [u, y + 0.351, 123], C.steelDark);
      }
      c.cylinder(3.1, 0.6, 118, 6, 10, [C.woodLight, C.wood, C.woodDark]);
      const [tx, ty] = c.at(3.1, 0.6, 128);
      c.p.poly(
        [
          [tx - 6, ty],
          [tx + 6, ty],
          [tx, ty - 6],
        ],
        C.woodDark,
      );
    },
  },
};
Object.assign(objects, nyc);

/* ════════ Bangladesh block: Baitul Mukarram, a school, cricket and more ════════ */
const MB = {
  cream: {
    top: C.paper,
    front: C.cream,
    side: C.creamShade,
    edge: C.limestone,
  },
  yellow: {
    top: C.paper,
    front: C.rice,
    side: C.carpetGold,
    edge: C.limestoneDark,
  },
  green: {
    top: C.greenDark,
    front: C.carpetGreen,
    side: C.carpetGreenDark,
    edge: C.carpetGreenDark,
  },
} satisfies Record<string, Material>;
/** Pointed arch on the front (y) plane or the side (x) plane. */
function pointed(
  c: IsoCanvas,
  side: boolean,
  u: number,
  at: number,
  w: number,
  z: number,
  h: number,
  frame: string,
  fill: string,
  shade: string = C.ink,
  rim = 0.07,
) {
  const pt = (a: number, zz: number, d = 0): [number, number, number] =>
      side ? [at + d, a, zz] : [a, at + d, zz],
    spring = z + h * 0.62;
  c.poly(
    [
      pt(u - rim, z),
      pt(u + w + rim, z),
      pt(u + w + rim, spring),
      pt(u + w / 2, z + h + 3),
      pt(u - rim, spring),
    ],
    frame,
  );
  c.poly(
    [
      pt(u, z, 0.001),
      pt(u + w, z, 0.001),
      pt(u + w, spring, 0.001),
      pt(u + w / 2, z + h, 0.001),
      pt(u, spring, 0.001),
    ],
    fill,
  );
  // Reveal shadow down the left jamb and under the left curve.
  c.edge(pt(u + 0.02, z, 0.002), pt(u + 0.02, spring, 0.002), shade);
  c.edge(pt(u + 0.02, spring, 0.002), pt(u + w / 2, z + h - 1, 0.002), shade);
}
/** Jali: a small pierced-stone lattice panel on the front plane. */
function jali(
  c: IsoCanvas,
  u: number,
  at: number,
  w: number,
  z: number,
  h: number,
  stone: string,
  hole: string,
) {
  c.faceX(u, at, w, z, h, stone);
  const [x0, y0] = c.at(u, at + 0.001, z + h),
    [x1] = c.at(u + w, at, z);
  for (let x = Math.ceil(x0) + 1; x < x1 - 1; x++)
    for (let y = 1; y < h - 1; y++) {
      const dy = Math.round((x - x0) / 2);
      if ((x + y) % 3 === 0 || (x - y) % 3 === 0)
        c.p.pixel(x, y0 + y + dy, hole);
    }
}
const bangladesh: Record<string, Spec> = {
  'm-baitul-mukarram': {
    footprint: [8, 8],
    h: 178,
    draw(c) {
      const H = 166,
        x0 = 0.3,
        w = 7.4,
        front = x0 + w,
        side = x0 + w;
      // Plinth, then the plain cube.
      c.box(x0 - 0.1, x0 - 0.1, w + 0.2, w + 0.2, 6, MB.cream);
      c.box(x0, x0, w, w, H, MB.cream);
      c.faceX(x0, front + 0.001, w, 0, 6, C.creamShade);
      c.faceY(side + 0.001, x0, w, 0, 6, C.limestone);
      // Weathering: faint vertical streaks below the roof line.
      for (let k = 0; k < 9; k++) {
        const u = x0 + 0.4 + k * 0.82;
        c.faceX(u, front + 0.001, 0.05, 60 + (k % 3) * 12, 70, C.paper);
        c.faceY(side + 0.001, u, 0.05, 70 + (k % 2) * 10, 60, C.limestoneLight);
      }
      // The three black bands across the upper part of both faces.
      for (const z of [H - 22, H - 32, H - 42]) {
        c.faceX(x0, front + 0.002, w, z, 2, C.ink);
        c.faceY(side + 0.002, x0, w, z, 2, C.ink);
        c.faceX(x0, front + 0.002, w, z + 2, 1, C.creamShade);
      }
      // Rows of slim slit windows low on each face, and a grille band.
      for (let k = 0; k < 14; k++) {
        const u = x0 + 0.3 + k * 0.5;
        for (const z of [14, 34]) {
          c.faceX(u, front + 0.003, 0.12, z, 12, C.charcoal);
          c.faceX(u, front + 0.004, 0.04, z + 9, 3, C.slate);
          c.faceY(side + 0.003, u, 0.12, z, 12, C.ink);
        }
      }
      jali(
        c,
        x0 + 0.4,
        front + 0.003,
        w - 0.8,
        54,
        8,
        C.creamShade,
        C.limestone,
      );
      // Roof: a low parapet round an open light well.
      c.top(x0 + 0.5, x0 + 0.5, w - 1, w - 1, H, C.creamShade);
      c.top(x0 + 1.4, x0 + 1.4, w - 2.8, w - 2.8, H, C.limestone);
      c.faceX(x0 + 1.4, x0 + 1.4, w - 2.8, H - 10, 10, C.limestoneDark);
      for (let k = 0; k < 7; k++) {
        const u = x0 + 1.6 + k * 0.62;
        c.faceX(u, x0 + 1.401, 0.3, H - 9, 7, C.charcoal);
      }
      for (const [u, v] of [
        [x0, x0],
        [x0, front - 0.25],
        [front - 0.25, x0],
        [front - 0.25, front - 0.25],
      ])
        c.box(u, v, 0.25, 0.25, 6, MB.cream, H);
      c.edge([x0, front, H], [front, front, H], C.white);
      c.edge([front, x0, H], [front, front, H], C.paper);
      c.box(x0 + 5.6, x0 + 0.8, 0.6, 0.5, 6, M.steel, H);
      c.box(x0 + 0.8, x0 + 5.8, 0.4, 0.4, 4, M.steel, H);
    },
  },
  'm-bm-gate': {
    footprint: [5, 2],
    h: 92,
    draw(c) {
      const f = 1.8;
      c.box(0.2, 0.3, 4.6, 1.5, 70, MB.cream);
      c.faceX(0.2, f + 0.001, 4.6, 0, 4, C.creamShade);
      // Plain panel above the main arch (left blank on purpose).
      c.faceX(1.5, f + 0.001, 2.0, 52, 12, C.creamShade);
      c.faceX(1.55, f + 0.002, 1.9, 53, 10, C.cream);
      // The great arch with its deep teal-blue hall and inner arches.
      pointed(c, false, 1.75, f + 0.001, 1.5, 0, 48, C.creamShade, C.deepTeal);
      c.faceX(1.8, f + 0.003, 1.4, 0, 26, C.tealDark);
      for (let k = 0; k < 3; k++)
        pointed(
          c,
          false,
          1.85 + k * 0.45,
          f + 0.004,
          0.32,
          2,
          20,
          C.cream,
          C.charcoal,
          C.ink,
          0.05,
        );
      c.faceX(1.8, f + 0.005, 1.4, 0, 2, C.slate);
      // Two smaller arches either side, and one on the side wall.
      for (const u of [0.55, 3.55])
        pointed(c, false, u, f + 0.001, 0.9, 0, 32, C.creamShade, C.deepTeal);
      for (const u of [0.62, 3.62])
        pointed(
          c,
          false,
          u,
          f + 0.003,
          0.76,
          0,
          14,
          C.cream,
          C.charcoal,
          C.ink,
          0.04,
        );
      pointed(c, true, 0.7, 4.801, 0.7, 0, 30, C.limestone, C.tealDark);
      // Flat roof edge with small lamps.
      c.faceX(0.2, f + 0.002, 4.6, 66, 4, C.paper);
      c.edge([0.2, f + 0.003, 70], [4.8, f + 0.003, 70], C.white);
      for (const u of [0.5, 4.4]) {
        const [lx, ly] = c.at(u, 1.6, 70);
        c.p.rect(lx, ly - 9, 2, 9, C.charcoal);
        c.p.rect(lx - 1, ly - 12, 4, 3, C.lamp);
      }
    },
  },
  'm-bm-arcade': {
    footprint: [7, 1.5],
    h: 62,
    draw(c) {
      const f = 1.4;
      c.box(0.05, 0.2, 6.9, 1.2, 46, M.white);
      c.faceX(0.05, f + 0.001, 6.9, 0, 4, C.pale);
      for (let k = 0; k < 9; k++) {
        const u = 0.2 + k * 0.75;
        if (k % 4 === 0) {
          // Lattice windows between groups of open arches.
          pointed(
            c,
            false,
            u,
            f + 0.001,
            0.5,
            6,
            28,
            C.pale,
            C.stone,
            C.stoneLine,
          );
          jali(c, u + 0.05, f + 0.002, 0.4, 8, 18, C.stone, C.stoneLine);
        } else {
          pointed(c, false, u, f + 0.001, 0.5, 0, 34, C.pale, C.charcoal);
          c.faceX(u + 0.05, f + 0.002, 0.4, 0, 3, C.slate);
        }
      }
      pointed(c, true, 0.45, 6.951, 0.5, 0, 30, C.stoneShade, C.ink);
      // Cornice and a row of small parapet blocks.
      c.faceX(0.05, f + 0.002, 6.9, 40, 3, C.offwhite);
      c.edge([0.05, f + 0.003, 43], [6.95, f + 0.003, 43], C.silver);
      for (let u = 0.1; u < 6.9; u += 0.35)
        c.box(u, 1.2, 0.18, 0.18, 4, M.white, 46);
    },
  },
  'm-bm-pavilion': {
    footprint: [2, 2],
    h: 58,
    draw(c) {
      c.box(0.25, 0.25, 1.5, 1.5, 24, MB.cream);
      pointed(c, false, 0.6, 1.751, 0.8, 0, 18, C.creamShade, C.charcoal);
      pointed(c, true, 0.6, 1.751, 0.8, 0, 18, C.limestone, C.ink);
      c.box(0.15, 0.15, 1.7, 1.7, 3, MB.cream, 24);
      // The rose-pink dome on a short drum.
      c.cylinder(1, 1, 27, 11, 3, [C.cream, C.creamShade, C.limestone]);
      const [dx, dy] = c.at(1, 1, 30);
      for (let r = 11; r > 0; r--) {
        const t = r / 11;
        c.p.ellipse(
          dx,
          dy - (1 - t) * 13,
          r,
          Math.max(1, r * 0.55),
          t > 0.75 ? C.pinkDark : C.pink,
        );
      }
      c.p.ellipse(dx - 4, dy - 9, 3, 3, C.rose);
      c.p.ellipse(dx - 4, dy - 10, 1.5, 1.5, C.white);
      c.p.rect(dx, dy - 18, 1, 5, C.limestone);
      c.p.ellipse(dx, dy - 19, 1.5, 1.5, C.paper);
    },
  },
  'm-bd-school': {
    footprint: [10, 3],
    h: 98,
    draw(c) {
      const f = 2.7,
        e = 9.8;
      // Red-brick plinth, then two storeys of pale yellow plaster.
      c.box(0.2, 0.3, 9.6, 2.4, 8, {
        top: C.brickLight,
        front: C.brick,
        side: C.brickDark,
        edge: C.brickDark,
      });
      for (let z = 2; z < 8; z += 3)
        c.faceX(0.2, f + 0.001, 9.6, z, 1, C.brickDark);
      c.box(0.2, 0.3, 9.6, 2.4, 74, MB.yellow, 8);
      // Ground floor: green doors and shuttered windows.
      for (let k = 0; k < 8; k++) {
        const u = 0.55 + k * 1.15;
        if (k === 3 || k === 4) {
          c.faceX(u, f + 0.001, 0.6, 8, 26, C.carpetGreenDark);
          c.faceX(u + 0.05, f + 0.002, 0.24, 10, 22, C.carpetGreen);
          c.faceX(u + 0.31, f + 0.002, 0.24, 10, 22, C.carpetGreen);
        } else {
          c.faceX(u, f + 0.001, 0.6, 16, 16, C.limestone);
          c.faceX(u + 0.06, f + 0.002, 0.48, 17, 14, C.screen);
          for (let b = 0; b < 4; b++)
            c.faceX(u + 0.1 + b * 0.12, f + 0.003, 0.03, 17, 14, C.steelDark);
          c.faceX(u - 0.14, f + 0.002, 0.14, 16, 16, C.carpetGreen);
          c.faceX(u + 0.6, f + 0.002, 0.14, 16, 16, C.carpetGreen);
        }
      }
      // First-floor veranda: shadowed recess, columns and a green railing.
      c.faceX(0.3, f + 0.001, 9.4, 44, 30, C.carpetGold);
      for (let k = 0; k < 8; k++) {
        const u = 0.6 + k * 1.15;
        c.faceX(u, f + 0.002, 0.5, 48, 20, C.carpetGreenDark);
        c.faceX(u + 0.04, f + 0.003, 0.42, 50, 6, C.screen);
      }
      for (let k = 0; k <= 8; k++) {
        const u = 0.25 + k * 1.17;
        c.box(u, f - 0.15, 0.16, 0.16, 30, MB.yellow, 44);
      }
      c.faceX(0.3, f + 0.004, 9.4, 50, 1, C.greenDark);
      c.faceX(0.3, f + 0.004, 9.4, 44, 1, C.greenDark);
      for (let u = 0.35; u < 9.7; u += 0.14)
        c.faceX(u, f + 0.004, 0.03, 44, 7, C.greenDark);
      c.faceX(0.2, f + 0.002, 9.6, 42, 2, C.paper);
      // Side wall windows.
      for (const v of [0.7, 1.6])
        for (const z of [16, 50]) {
          c.faceY(e + 0.001, v, 0.5, z, 14, C.carpetGreenDark);
          c.faceY(e + 0.002, v + 0.05, 0.4, z + 2, 10, C.screen);
        }
      // Parapet, a plain green board, and a water tank on the roof.
      c.faceX(0.2, f + 0.002, 9.6, 74, 8, C.cream);
      c.edge([0.2, f + 0.003, 82], [9.8, f + 0.003, 82], C.white);
      c.box(0.2, 0.3, 9.6, 0.2, 6, MB.yellow, 82);
      c.faceX(3.9, f + 0.004, 2.2, 74, 8, C.pale);
      c.faceX(3.95, f + 0.005, 2.1, 75, 6, C.carpetGreen);
      c.cylinder(8.6, 1.2, 82, 6, 10, [C.slate, C.charcoal, C.ink]);
      c.faceX(0.2, f + 0.001, 9.6, 8, 1, C.carpetGold);
    },
  },
  'm-bd-flag': {
    footprint: [0.5, 0.5],
    h: 92,
    frames: 2,
    draw(c, f) {
      flag(c, f, (x, y, w, h) =>
        (x - w * 0.45) ** 2 + (y - h / 2) ** 2 <= (h * 0.31) ** 2
          ? C.flagRed
          : C.carpetGreen,
      );
    },
  },
  'm-shapla-pond': {
    footprint: [4, 3],
    h: 12,
    draw(c) {
      c.box(0.1, 0.1, 3.8, 2.8, 4, M.stone);
      c.top(0.35, 0.35, 3.3, 2.3, 4, C.deepTeal);
      c.top(0.45, 0.45, 3.1, 2.1, 4, C.turquoise);
      for (let k = 0; k < 7; k++) {
        const [rx, ry] = c.at(
          0.8 + ((k * 0.47) % 2.8),
          0.6 + ((k * 0.71) % 1.8),
          4,
        );
        c.p.rect(rx - 3, ry, 6, 1, C.waterLight);
      }
      // Lily pads with pink and white shapla flowers.
      const pads: [number, number, string | null][] = [
        [0.9, 0.9, C.pink],
        [1.6, 1.5, null],
        [2.4, 0.8, C.white],
        [3.1, 1.6, C.pink],
        [1.1, 2.1, C.pink],
        [2.2, 2.2, null],
        [2.9, 2.5, C.white],
        [1.9, 0.7, null],
      ];
      for (const [u, v, flower] of pads) {
        const [px, py] = c.at(u, v, 4);
        c.p.ellipse(px, py, 4, 2, C.leafDark);
        c.p.ellipse(px - 1, py - 0.5, 3, 1.5, C.leaf);
        c.p.pixel(px + 2, py, C.turquoise);
        if (flower) {
          const dark = flower === C.pink ? C.pinkDark : C.pale;
          c.p.rect(px - 2, py - 3, 5, 2, flower);
          c.p.rect(px - 1, py - 5, 3, 2, flower);
          c.p.pixel(px - 2, py - 4, dark);
          c.p.pixel(px + 2, py - 4, dark);
          c.p.pixel(px, py - 3, C.yellow);
        }
      }
      c.edge([0.1, 2.9, 4], [3.9, 2.9, 4], C.ivory);
    },
  },
  'm-tea-stall': {
    footprint: [2, 1],
    h: 50,
    draw(c) {
      // Corner posts and a sagging blue tarp roof.
      for (const [u, v] of [
        [0.15, 0.15],
        [1.75, 0.15],
        [0.15, 0.85],
        [1.75, 0.85],
      ])
        post(c, u, v, 0, 36, C.woodDark);
      c.box(0.2, 0.3, 1.2, 0.55, 16, M.wood);
      for (let k = 1; k < 4; k++)
        c.faceX(0.2, 0.851, 1.2, k * 4, 1, C.woodDark);
      // Stove and kettle, glass jars of biscuits.
      c.box(0.3, 0.4, 0.3, 0.3, 5, M.dark, 16);
      const [kx, ky] = c.at(0.45, 0.55, 23);
      c.p.ellipse(kx, ky, 3, 2.5, C.steelDark);
      c.p.ellipse(kx - 1, ky - 1, 1.5, 1, C.steelLight);
      c.p.rect(kx + 3, ky - 2, 2, 1, C.steelDark);
      c.p.rect(kx - 1, ky - 4, 2, 1, C.charcoal);
      for (const [u, col] of [
        [0.8, C.yellow],
        [1.0, C.orange],
        [1.2, C.woodLight],
      ] as [number, string][]) {
        c.cylinder(u, 0.55, 16, 2.5, 6, R.glass);
        const [jx, jy] = c.at(u, 0.55, 18);
        c.p.rect(jx - 1, jy - 1, 3, 3, col);
      }
      // A bench for customers.
      c.box(1.45, 0.35, 0.4, 0.5, 6, M.oak);
      c.poly(
        [
          [0.05, 0.05, 40],
          [1.95, 0.05, 40],
          [1.95, 0.98, 33],
          [0.05, 0.98, 33],
        ],
        C.blue,
      );
      c.faceX(0.05, 0.98, 1.9, 30, 3, C.blueDark);
      for (let k = 1; k < 5; k++)
        c.edge([k * 0.38, 0.1, 40], [k * 0.38 + 0.05, 0.95, 33], C.blueDark);
    },
  },
  'm-rickshaw': {
    footprint: [2, 1],
    h: 46,
    draw(c) {
      const wheel = (u: number, v: number, r: number) => {
        const [wx, wy] = c.at(u, v, r);
        c.p.ellipse(wx, wy, r * 0.75, r, C.ink);
        c.p.ellipse(wx, wy, r * 0.75 - 1, r - 1, C.silver);
        c.p.ellipse(wx, wy, r * 0.75 - 2, r - 2, C.ink);
        c.line([wx, wy - r + 2], [wx, wy + r - 2], C.steel);
        c.line([wx - r * 0.55, wy], [wx + r * 0.55, wy], C.steel);
        c.p.pixel(wx, wy, C.gold);
      };
      wheel(1.45, 0.2, 8);
      // Frame from the front wheel to the passenger seat.
      const [fx, fy] = c.at(0.3, 0.5, 8),
        [sx, sy] = c.at(1.3, 0.5, 16);
      c.thick([fx, fy], [sx, sy], 1, C.blueDark);
      c.line([fx, fy - 10], [fx, fy], C.charcoal);
      c.line([fx - 4, fy - 12], [fx + 4, fy - 12], C.charcoal);
      const [dx, dy] = c.at(0.75, 0.5, 18);
      c.p.rect(dx - 3, dy, 6, 2, C.ink);
      c.line([dx, dy + 2], [dx + 2, dy + 8], C.charcoal);
      wheel(0.3, 0.5, 6);
      // Passenger seat with a bright cushion and a painted back panel.
      c.box(
        1.15,
        0.2,
        0.55,
        0.6,
        5,
        { top: C.red, front: C.redDark, side: C.carpet },
        13,
      );
      c.faceY(1.701, 0.2, 0.6, 18, 12, C.yellow);
      for (let k = 0; k < 4; k++) {
        const [px, py] = c.at(1.702, 0.28 + k * 0.14, 23);
        c.p.pixel(px, py, [C.pink, C.red, C.green, C.blue][k]);
        c.p.pixel(px, py - 2, C.leafDark);
        c.p.pixel(px - 1, py + 1, [C.purple, C.orange, C.pink, C.red][k]);
      }
      c.faceY(1.702, 0.2, 0.6, 18, 1, C.carpet);
      // Folding hood with stripes and a fringe of tassels.
      c.poly(
        [
          [1.15, 0.15, 24],
          [1.7, 0.15, 40],
          [1.7, 0.85, 40],
          [1.15, 0.85, 24],
        ],
        C.carpet,
      );
      c.poly(
        [
          [1.7, 0.15, 40],
          [1.75, 0.15, 18],
          [1.75, 0.85, 18],
          [1.7, 0.85, 40],
        ],
        C.carpetDark,
      );
      for (const t of [0.3, 0.6]) {
        const u = 1.15 + t * 0.55,
          z = 24 + t * 16;
        c.edge([u, 0.15, z], [u, 0.85, z], C.gold);
      }
      for (let k = 0; k < 6; k++) {
        const [tx, ty] = c.at(1.15, 0.18 + k * 0.12, 23);
        c.p.pixel(tx, ty, accents[k % accents.length]);
        c.p.pixel(tx, ty + 1, accents[(k + 3) % accents.length]);
      }
      wheel(1.45, 0.85, 8);
    },
  },
  'm-cricket-pitch': {
    footprint: [2, 8],
    h: 2,
    floor: true,
    draw(c) {
      for (let k = 0; k < 8; k++)
        c.top(
          0.4,
          0.1 + k * 0.975,
          1.2,
          0.975,
          0,
          k % 2 ? C.sand : C.sandShade,
        );
      // Wear at the ends where bowlers land and batters stand.
      for (const v of [0.6, 7.3]) c.top(0.7, v - 0.3, 0.6, 0.6, 0, C.sandDark);
      for (const v of [0.9, 7.1]) {
        c.edge([0.4, v, 0], [1.6, v, 0], C.line);
        c.edge([0.55, v - 0.5, 0], [0.55, v + 0.3, 0], C.line);
        c.edge([1.45, v - 0.5, 0], [1.45, v + 0.3, 0], C.line);
      }
      for (const v of [0.45, 7.55]) c.edge([0.6, v, 0], [1.4, v, 0], C.line);
    },
  },
  'm-stumps': {
    footprint: [1, 1],
    h: 20,
    draw(c) {
      for (const u of [0.3, 0.5, 0.7]) {
        const [px, py] = c.at(u, 0.5, 0);
        c.p.rect(px, py - 13, 1, 13, C.woodLight);
        c.p.pixel(px, py - 13, C.oak);
      }
      const [a, b] = [c.at(0.3, 0.5, 14), c.at(0.7, 0.5, 14)];
      c.line(a, b, C.wood);
    },
  },
  'm-basketball-court': {
    footprint: [8, 5],
    h: 2,
    floor: true,
    draw(c) {
      const ln = (a: [number, number], b: [number, number]) =>
        c.edge([a[0], a[1], 0], [b[0], b[1], 0], C.line);
      c.top(0.05, 0.05, 7.9, 4.9, 0, C.carpetGreen);
      c.top(0.3, 0.3, 7.4, 4.4, 0, C.terracotta);
      // Keys at both ends.
      c.top(0.3, 1.7, 1.8, 1.6, 0, C.blueDark);
      c.top(5.9, 1.7, 1.8, 1.6, 0, C.blueDark);
      ln([0.3, 0.3], [7.7, 0.3]);
      ln([0.3, 4.7], [7.7, 4.7]);
      ln([0.3, 0.3], [0.3, 4.7]);
      ln([7.7, 0.3], [7.7, 4.7]);
      ln([4, 0.3], [4, 4.7]);
      for (const [x0, x1] of [
        [0.3, 2.1],
        [5.9, 7.7],
      ]) {
        ln([x0, 1.7], [x1, 1.7]);
        ln([x0, 3.3], [x1, 3.3]);
        ln([x0 < 1 ? x1 : x0, 1.7], [x0 < 1 ? x1 : x0, 3.3]);
      }
      // Centre circle and three-point arcs.
      const arcPts = (cx: number, r: number, a0: number, a1: number) => {
        for (let t = a0; t <= a1; t += 0.05) {
          const [px, py] = c.at(cx + Math.cos(t) * r, 2.5 + Math.sin(t) * r, 0);
          c.p.pixel(px, py, C.line);
        }
      };
      arcPts(4, 0.7, 0, Math.PI * 2);
      arcPts(0.6, 2.0, -Math.PI / 2, Math.PI / 2);
      arcPts(7.4, 2.0, Math.PI / 2, (Math.PI * 3) / 2);
    },
  },
  'm-hoop': {
    footprint: [1, 1],
    h: 70,
    draw(c) {
      post(c, 0.3, 0.5, 0, 52, C.steelDark);
      post(c, 0.32, 0.5, 0, 52, C.steel);
      c.box(0.2, 0.4, 0.2, 0.2, 3, M.dark);
      c.edge([0.3, 0.5, 50], [0.55, 0.5, 50], C.steelDark);
      // Backboard facing the court, rim and net.
      c.faceY(0.55, 0.15, 0.7, 44, 18, C.white);
      c.faceY(0.551, 0.15, 0.7, 44, 1, C.silver);
      c.faceY(0.552, 0.38, 0.24, 47, 7, C.orangeDark);
      c.faceY(0.553, 0.41, 0.18, 48, 5, C.white);
      const [rx, ry] = c.at(0.75, 0.5, 46);
      for (let k = 0; k < 5; k++)
        c.line([rx - 4 + k * 2, ry], [rx - 2 + k, ry + 7], C.offwhite);
      c.line([rx - 3, ry + 4], [rx + 3, ry + 4], C.net);
      c.p.ellipse(rx, ry, 5, 2, C.orange);
      c.p.ellipse(rx, ry, 3.5, 1, C.orangeDark);
    },
  },
};
Object.assign(objects, bangladesh);

/* ════════ Stadium scenes (scene bible, batch 1) ════════ */
/** An arched opening on the +y face: a rectangle with a rounded top. */
function archX(
  c: IsoCanvas,
  x: number,
  y: number,
  w: number,
  z: number,
  h: number,
  col: string,
) {
  c.faceX(x, y, w, z, h - w * 8, col);
  const steps = 6;
  for (let i = 0; i < steps; i++) {
    const t = (i + 0.5) / steps,
      half = (w / 2) * Math.sqrt(1 - t * t);
    c.faceX(
      x + w / 2 - half,
      y,
      half * 2,
      z + h - w * 8 + (i * w * 8) / steps,
      (w * 8) / steps + 0.6,
      col,
    );
  }
}
const stadiumScenes: Record<string, Spec> = {
  'm-hospital-stand': {
    // Children from the hospital ward, in light-blue gowns, behind the goal.
    // The tiers face +x so the children and their plain banner face the viewer.
    footprint: [2, 7],
    h: 66,
    frames: 2,
    period: 240,
    draw(c, f) {
      const gowns = [C.glass, C.glassLight, C.mint, C.glassDark];
      const treads: [number, number, number][] = [
        [0, 0.67, 30],
        [0.67, 0.67, 20],
        [1.33, 0.67, 10],
      ];
      for (const [x, d, z] of treads) c.box(x, 0, d, 7, z, M.concrete);
      c.faceY(2.001, 0, 7, 8, 2, C.glassDark);
      const up = f === 1;
      let n = 0;
      for (const [x, d, z] of treads)
        for (let k = 0; k < 8; k++, n++) {
          if (n === 23) continue;
          const y = 0.45 + k * 0.84,
            [px, py] = c.at(x + d * 0.5, y, z),
            skin = fanSkins[(n * 3) % 4];
          // Gown, head and hair; arms raised when the banner goes up.
          c.p.rect(px - 2, py - 10, 5, 8, gowns[n % gowns.length]);
          c.p.rect(px + 2, py - 10, 1, 8, C.glassDark);
          c.p.rect(px - 1, py - 14, 4, 4, skin);
          c.p.rect(px - 1, py - 15, 4, 1, n % 3 ? C.fanHair : C.woodDark);
          c.p.pixel(px + 2, py - 12, C.edge);
          if (up) {
            c.p.rect(px - 3, py - 17, 1, 7, skin);
            c.p.rect(px + 4, py - 17, 1, 7, skin);
          } else {
            c.p.rect(px - 3, py - 9, 1, 4, skin);
            c.p.rect(px + 4, py - 9, 1, 4, skin);
          }
        }
      // A plain white banner, no text: held low across the front, then high.
      const z0 = up ? 50 : 22,
        bh = 10;
      c.faceY(1.95, 0.6, 5.8, z0, bh, C.white);
      c.faceY(1.951, 0.6, 5.8, z0, 1, C.silver);
      c.faceY(1.951, 0.6, 5.8, z0 + bh - 2, 1, C.glass);
      c.faceY(1.951, 0.6, 5.8, z0 + 2, 1, C.glass);
      for (const y of [0.6, 6.4])
        c.edge([1.95, y, z0 - 8], [1.95, y, z0 + bh], C.woodDark);
    },
  },
  'm-village-school': {
    // A village school in Senegal: sand walls, blue shutters, a tin roof.
    footprint: [4, 2],
    h: 58,
    draw(c) {
      const sand = {
        top: C.sand,
        front: C.sand,
        side: C.sandShade,
        edge: C.sandDark,
      };
      c.box(0.2, 0.25, 3.6, 1.5, 30, sand);
      // Lower wall band, worn paint.
      c.faceX(0.2, 1.751, 3.6, 0, 4, C.clay);
      c.faceY(3.801, 0.25, 1.5, 0, 4, C.terracottaDark);
      // Blue door and shuttered windows on the front.
      c.faceX(1.75, 1.752, 0.5, 0, 20, C.blue);
      c.faceX(1.8, 1.753, 0.4, 2, 16, C.blueDark);
      for (const x of [0.5, 2.6]) {
        c.faceX(x, 1.752, 0.75, 10, 11, C.ink);
        c.faceX(x, 1.753, 0.3, 10, 11, C.blue);
        c.faceX(x + 0.45, 1.753, 0.3, 10, 11, C.blue);
      }
      c.faceY(3.802, 0.6, 0.6, 10, 11, C.blue);
      // Corrugated tin roof with a low ridge and an overhang.
      c.poly(
        [
          [0.05, 1.95, 29],
          [3.95, 1.95, 29],
          [3.95, 1.0, 40],
          [0.05, 1.0, 40],
        ],
        C.steel,
      );
      c.poly(
        [
          [0.05, 0.05, 29],
          [3.95, 0.05, 29],
          [3.95, 1.0, 40],
          [0.05, 1.0, 40],
        ],
        C.steelLight,
      );
      for (let x = 0.15; x < 3.95; x += 0.2)
        c.edge([x, 1.95, 29], [x, 1.0, 40], C.steelDark);
      c.poly(
        [
          [3.95, 0.05, 29],
          [3.95, 1.95, 29],
          [3.95, 1.0, 40],
        ],
        C.steelDark,
      );
      c.edge([0.05, 1.95, 29], [3.95, 1.95, 29], C.slate);
      // A shade tree beside the yard.
      c.box(0.1, 1.85, 0.12, 0.12, 30, M.wood);
      c.greenery(0.15, 1.9, 44, 11, R.leaf);
    },
  },
  'm-ambulance-centre': {
    // A small new ambulance station with an open garage bay.
    footprint: [4, 2],
    h: 50,
    draw(c) {
      c.box(0.15, 0.2, 3.7, 1.6, 38, M.white);
      // Wide open bay: dark garage, roller door rolled up at the top.
      c.faceX(0.4, 1.801, 2.2, 0, 28, C.charcoal);
      c.faceX(0.5, 1.802, 2.0, 0, 24, C.ink);
      c.faceX(0.4, 1.802, 2.2, 26, 2, C.silver);
      for (let z = 1; z < 24; z += 4) c.faceX(0.5, 1.803, 2.0, z, 1, C.slate);
      // Office door and window.
      c.faceX(2.95, 1.802, 0.45, 0, 18, C.glassDark);
      c.faceX(3.45, 1.802, 0.3, 9, 9, C.glass);
      // Blue band and roof parapet.
      c.faceX(0.15, 1.803, 3.7, 31, 3, C.blue);
      c.faceY(3.851, 0.2, 1.6, 31, 3, C.blueDark);
      c.box(0.15, 0.2, 3.7, 0.12, 4, M.white, 38);
      c.faceY(3.852, 0.6, 0.7, 12, 10, C.glassDark);
      // A blue lamp on the roof corner.
      const [lx, ly] = c.at(3.6, 1.6, 40);
      c.p.rect(lx - 1, ly - 3, 3, 3, C.blue);
      c.p.pixel(lx, ly - 3, C.glassLight);
    },
  },
  'm-mosque-door': {
    // A white mosque front: frame 0 dark inside, frame 1 lit for Friday prayer.
    footprint: [3, 1],
    h: 72,
    frames: 2,
    period: 240,
    draw(c, f) {
      const lit = f === 1;
      c.box(0, 0.45, 3, 0.55, 58, M.white);
      c.box(0, 0.45, 3, 0.55, 4, M.stone, 58);
      for (let x = 0.1; x < 3; x += 0.4)
        c.box(x, 0.5, 0.2, 0.45, 5, M.white, 62);
      const glow = lit ? C.windowLit : C.glassDeep,
        deep = lit ? C.lampGlow : C.ink;
      for (const x of [0.3, 2.25]) {
        archX(c, x, 1.001, 0.45, 20, 26, C.pale);
        archX(c, x + 0.05, 1.002, 0.35, 22, 22, glow);
      }
      // Tall wooden double door in an arched frame.
      archX(c, 1.05, 1.001, 0.9, 0, 40, C.pale);
      archX(c, 1.12, 1.002, 0.76, 0, 36, lit ? deep : C.woodDark);
      if (!lit) {
        c.faceX(1.14, 1.003, 0.34, 0, 28, C.wood);
        c.faceX(1.52, 1.003, 0.34, 0, 28, C.wood);
        c.faceX(1.49, 1.004, 0.02, 0, 28, C.woodDark);
      } else {
        // Doors open inward; warm light spills out.
        c.faceX(1.12, 1.003, 0.12, 0, 28, C.wood);
        c.faceX(1.76, 1.003, 0.12, 0, 28, C.wood);
        c.top(1.15, 1.0, 0.7, 0.4, 0, C.lamp);
      }
      c.box(0.9, 1.0, 1.2, 0.18, 2, M.stone);
    },
  },
  'm-tunnel': {
    // The players' tunnel: a dark mouth under a short canopy, seats above.
    footprint: [3, 2],
    h: 48,
    draw(c) {
      c.box(0, 0, 3, 1.6, 30, M.concrete);
      for (let i = 0; i < 3; i++)
        c.box(0, i * 0.45, 3, 0.45, 6, M.concrete, 30 + (2 - i) * 4);
      for (let i = 0; i < 3; i++)
        for (let k = 0; k < 8; k++) {
          const [sx, sy] = c.at(
            0.2 + k * 0.36,
            i * 0.45 + 0.25,
            36 + (2 - i) * 4,
          );
          c.p.rect(sx - 1, sy - 3, 3, 3, C.seatGrey);
        }
      // Tunnel mouth.
      c.faceX(0.8, 1.601, 1.4, 0, 22, C.charcoal);
      c.faceX(0.95, 1.602, 1.1, 0, 19, C.ink);
      c.faceX(1.2, 1.603, 0.6, 0, 15, C.ink);
      // Canopy on two posts.
      c.box(0.7, 1.6, 1.6, 0.35, 2, M.white, 22);
      for (const x of [0.75, 2.2]) c.box(x, 1.85, 0.06, 0.06, 22, M.steel);
      c.faceX(0.7, 1.951, 1.6, 22, 1, C.teal);
    },
  },
};
Object.assign(objects, stadiumScenes);

/* ════════ Cricket ground scenes (scene bible) ════════ */
const cricketScenes: Record<string, Spec> = {
  // A low presentation platform people stand on (z 10), baked into the floor.
  'm-presentation-stage': {
    footprint: [5, 2],
    h: 12,
    floor: true,
    draw(c) {
      const Z = 9;
      // Skirt on the two visible faces, with a trim band and vertical folds.
      c.faceX(0, 1.7, 5, 0, Z, C.navy);
      c.faceY(5, 0, 1.7, 0, Z, C.blueDark);
      for (let u = 0.25; u < 5; u += 0.5)
        c.edge([u, 1.7, 0], [u, 1.7, Z - 2], C.blueDark);
      for (let u = 0.25; u < 1.7; u += 0.5)
        c.edge([5, u, 0], [5, u, Z - 2], C.navy);
      c.edge([0, 1.7, Z - 1], [5, 1.7, Z - 1], C.gold);
      c.edge([5, 0, Z - 1], [5, 1.7, Z - 1], C.gold);
      c.edge([0, 1.7, 0], [5, 1.7, 0], C.ink);
      c.edge([5, 0, 0], [5, 1.7, 0], C.ink);
      // Carpeted top with a lighter border.
      c.top(0, 0, 5, 1.7, Z, C.slate);
      c.top(0.12, 0.12, 4.76, 1.46, Z, C.grey);
      for (let k = 0; k < 24; k++) {
        const [x, y] = c.at(
          0.3 + ((k * 7) % 44) / 10,
          0.25 + ((k * 11) % 12) / 10,
          Z,
        );
        c.p.pixel(x, y, C.silver);
      }
      c.edge([0, 1.7, Z], [5, 1.7, Z], C.silver);
      c.edge([5, 0, Z], [5, 1.7, Z], C.silver);
      // A front step in the middle of the long side.
      c.box(1.9, 1.7, 1.2, 0.3, 4, M.stone);
    },
  },
  // The plain backdrop along the stage's back edge: colour bands only.
  'm-presentation-backdrop': {
    footprint: [5, 0.4],
    h: 46,
    draw(c) {
      // Two slim posts and a panel standing on the stage top (z 9).
      for (const x of [0.15, 4.75]) c.box(x, 0.12, 0.1, 0.16, 44, M.steel, 0);
      c.box(0.1, 0.1, 4.8, 0.2, 34, M.white, 10);
      c.faceX(0.1, 0.301, 4.8, 36, 5, C.blueDark);
      c.faceX(0.1, 0.302, 4.8, 30, 4, C.green);
      c.faceX(0.1, 0.302, 4.8, 14, 3, C.blue);
      c.faceX(0.1, 0.302, 4.8, 11, 2, C.gold);
      c.edge([0.1, 0.303, 44], [4.9, 0.303, 44], C.silver);
    },
  },
};
Object.assign(objects, cricketScenes);

/* ════════ Nature pass: trees, plants, rocks, waterfall, ship ════════ */
// Objects defined here may replace earlier ones with the same id (m-tree).
/* ───────────── Nature pass helpers ───────────── */
/*
 * Painterly foliage, bark, rock and water in the owner's reference style:
 * canopies built from many leaf clumps, each lit from the top left over a
 * darker underside; blocky lit rocks; bright falling water over dark stone.
 * Everything is deterministic (seeded hashes), so frames and builds repeat.
 */
type Tones = readonly string[];
const FOLIAGE: Tones = [
  NC.leaf0,
  NC.leaf1,
  NC.leaf2,
  NC.leaf3,
  NC.leaf4,
  NC.leaf5,
];
const OAK: Tones = [NC.oak0, NC.oak1, NC.oak2, NC.oak3, NC.oak4, NC.oak5];
const PINE: Tones = [
  NC.pine0,
  NC.pine1,
  NC.pine2,
  NC.pine3,
  NC.pine4,
  NC.pine5,
];
const BLOSSOM: Tones = [
  NC.blossom0,
  NC.blossom1,
  NC.blossom2,
  NC.blossom3,
  NC.blossom4,
  NC.blossom5,
];
const BIRCH_LEAF: Tones = [
  NC.birch0,
  NC.birch1,
  NC.birch2,
  NC.birch3,
  NC.birch4,
  NC.leaf4,
];
const BARK: Tones = [NC.bark0, NC.bark1, NC.bark2, NC.bark3];
const ROCK: Tones = [
  NC.rock0,
  NC.rock1,
  NC.rock2,
  NC.rock3,
  NC.rock4,
  NC.rock5,
];
const MOSS: Tones = [NC.moss0, NC.moss1, NC.moss2];
const FALL: Tones = [
  NC.water0,
  NC.water1,
  NC.water2,
  NC.water3,
  NC.water4,
  NC.water5,
  NC.water6,
];
const SEA: Tones = [NC.sea0, NC.sea1, NC.sea2, NC.sea3, NC.sea4, NC.sea5];
/** 0..1 hash of integer coordinates and a seed. */
function nhash(x: number, y: number, s = 0) {
  let h = Math.imul(
    (Math.floor(x) * 374761393) ^
      (Math.floor(y) * 668265263) ^
      (s * 2246822519),
    1274126177,
  );
  h ^= h >>> 13;
  h = Math.imul(h, 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
const tone = (t: Tones, v: number, steps: readonly number[]) => {
  for (let i = 0; i < steps.length; i++) if (v > steps[i]) return t[i];
  return t[Math.min(steps.length, t.length - 1)];
};
type Clump = { x: number; y: number; r: number };
/** Leaf clumps filling an ellipse (screen px), sorted back (top) to front. */
function clumpsIn(
  seed: number,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  n: number,
  rMin: number,
  rMax: number,
): Clump[] {
  const out: Clump[] = [];
  for (let i = 0; i < n; i++) {
    const a = i * 2.39996 + nhash(i, seed) * 0.6,
      k = Math.sqrt((i + 0.5) / n),
      r = rMin + (rMax - rMin) * nhash(i, seed, 7);
    out.push({
      x: cx + Math.cos(a) * (rx - r * 0.7) * k,
      y: cy + Math.sin(a) * (ry - r * 0.7) * k,
      r,
    });
  }
  return out.sort((p, q) => p.y - q.y);
}
/**
 * Paint leaf clumps: each clump is lit on its top-left and darkens toward a
 * shadowed lower-right rim; the whole canopy is lighter on top and darker
 * underneath. Leaf tips break the outline; a few sparkles catch the light.
 */
function paintClumps(
  c: IsoCanvas,
  clumps: Clump[],
  t: Tones,
  box: { cx: number; cy: number; rx: number; ry: number },
  seed = 0,
  extra = 0,
) {
  for (const [k, q] of clumps.entries()) {
    const lim = q.r + 2;
    for (let py = Math.floor(q.y - lim); py <= q.y + lim; py++)
      for (let px = Math.floor(q.x - lim); px <= q.x + lim; px++) {
        const dx = (px + 0.5 - q.x) / q.r,
          dy = (py + 0.5 - q.y) / q.r,
          d = Math.hypot(dx, dy),
          tip = nhash(px, py, seed + k) < 0.3 && dy < 0.4 ? 0.22 : 0;
        if (d > 1 + tip) continue;
        const local = -(dx * 0.55 + dy * 0.85),
          glob = -(
            ((q.x - box.cx) / box.rx) * 0.4 +
            ((q.y - box.cy) / box.ry) * 0.85
          );
        let v =
          local * 0.78 +
          glob * 0.55 +
          (nhash(px, py, seed) - 0.5) * 0.22 +
          extra;
        // A bright cap on the lit side, a dark rim on the shaded side, so
        // each clump reads on its own.
        if (d < 0.55 && dx + dy < -0.15) v += 0.2;
        if (d > 0.76 && dx + dy > 0.1) v -= 0.5;
        if (d > 1) v -= 0.2;
        c.p.pixel(px, py, tone(t, v, [0.78, 0.42, 0.08, -0.26, -0.6]));
      }
  }
}
/** A canopy: a dark back layer for depth, then lit clumps on top. */
function canopy(
  c: IsoCanvas,
  seed: number,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  t: Tones,
  n = 26,
  rMin = 6,
  rMax = 9.5,
) {
  const box = { cx, cy, rx, ry };
  paintClumps(
    c,
    clumpsIn(
      seed + 50,
      cx + 2,
      cy + 3,
      rx * 0.92,
      ry * 0.85,
      Math.round(n * 0.5),
      rMin,
      rMax,
    ),
    t,
    box,
    seed + 3,
    -0.45,
  );
  paintClumps(c, clumpsIn(seed, cx, cy, rx, ry, n, rMin, rMax), t, box, seed);
}
/** Tapered trunk with lit left side, bark streaks and root flares. */
function trunk(
  c: IsoCanvas,
  x: number,
  y: number,
  h: number,
  wBase: number,
  wTop: number,
  t: Tones = BARK,
  roots = true,
) {
  for (let j = 0; j <= h; j++) {
    const k = j / h,
      half = (wBase + (wTop - wBase) * k) / 2,
      flare = roots && j < 4 ? (4 - j) * 0.9 : 0;
    for (let i = Math.floor(x - half - flare); i <= x + half + flare; i++) {
      const u = (i + 0.5 - x) / (half + flare + 0.01);
      let v = -u * 0.8 + (nhash(i, Math.floor((y - j) / 3), 11) - 0.5) * 0.5;
      if (nhash(i, y - j, 12) < 0.06) v -= 0.6;
      c.p.pixel(i, y - j, tone(t, v, [0.45, -0.05, -0.55]));
    }
  }
}
/** A branch: a tapering stroke from (x0,y0) to (x1,y1). */
function branch(
  c: IsoCanvas,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  w: number,
  t: Tones = BARK,
) {
  const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0));
  for (let i = 0; i <= n; i++) {
    const k = i / n,
      r = Math.max(0.5, w * (1 - k * 0.6)),
      px = x0 + (x1 - x0) * k,
      py = y0 + (y1 - y0) * k;
    for (let dx = -r; dx <= r; dx++)
      c.p.pixel(px + dx, py, dx < 0 ? t[1] : t[2]);
  }
}
/** Grass tufts and tiny flowers on the ground around a point. */
function tufts(
  c: IsoCanvas,
  x: number,
  y: number,
  rx: number,
  seed: number,
  flowers: string[] = [],
) {
  for (let i = 0; i < 14; i++) {
    const a = nhash(i, seed) * Math.PI * 2,
      r = Math.sqrt(nhash(i, seed, 1)) * rx,
      px = Math.round(x + Math.cos(a) * r),
      py = Math.round(y + Math.sin(a) * r * 0.5);
    c.p.pixel(px, py, FOLIAGE[3]);
    c.p.pixel(px, py - 1, FOLIAGE[2]);
    if (nhash(i, seed, 2) < 0.5) c.p.pixel(px + 1, py - 2, FOLIAGE[1]);
    if (flowers.length && nhash(i, seed, 3) < 0.4)
      c.p.pixel(px, py - 2, flowers[i % flowers.length]);
  }
}
/**
 * Blocky lit rock on a marker-filled area: Voronoi cells become stones, each
 * lit on its top-left with a dark crack around it. `face` biases the tone
 * (0 top, 1 front, 2 side).
 */
function rockShade(
  px: number,
  py: number,
  face: number,
  seed: number,
  cell = 9,
  t: Tones = ROCK,
) {
  const gx = Math.floor(px / cell),
    gy = Math.floor(py / (cell * 0.75));
  let d1 = 1e9,
    d2 = 1e9,
    bx = 0,
    by = 0;
  for (let j = -1; j <= 1; j++)
    for (let i = -1; i <= 1; i++) {
      const cxp = (gx + i + 0.15 + nhash(gx + i, gy + j, seed) * 0.7) * cell,
        cyp =
          (gy + j + 0.15 + nhash(gx + i, gy + j, seed + 1) * 0.7) * cell * 0.75;
      const d = Math.hypot(px - cxp, (py - cyp) * 1.25);
      if (d < d1) {
        d2 = d1;
        d1 = d;
        bx = cxp;
        by = cyp;
      } else if (d < d2) d2 = d;
    }
  const base = [0.45, 0.05, -0.4][face],
    local = -((px - bx) * 0.6 + (py - by) * 0.9) / cell;
  let v = base + local * 0.55 + (nhash(px, py, seed + 2) - 0.5) * 0.16;
  if (d2 - d1 < 1.3) v -= 0.75;
  return tone(t, v, [0.62, 0.3, 0.0, -0.3, -0.62]);
}
/**
 * Cliff stone: big angular rock masses laid in rough strata along the face
 * (so they follow the isometric slope). Each mass is lit toward its top
 * left, with a dark crack around it. `face` 1 is a lit front (constant y),
 * 2 a shaded side (constant x). `lift` brightens or darkens.
 */
function cliffShade(
  px: number,
  py: number,
  face: 1 | 2,
  seed: number,
  lift = 0,
  t: Tones = ROCK,
) {
  const r = face === 1 ? py - px * 0.5 : py + px * 0.5,
    CW = 15,
    CH = 9,
    gx = Math.floor(px / CW),
    gy = Math.floor(r / CH);
  let d1 = 1e9,
    d2 = 1e9,
    bx = 0,
    by = 0,
    id = 0;
  for (let j = -1; j <= 1; j++)
    for (let i = -1; i <= 1; i++) {
      const cx = (gx + i + 0.1 + nhash(gx + i, gy + j, seed) * 0.8) * CW,
        cy = (gy + j + 0.3 + nhash(gx + i, gy + j, seed + 1) * 0.4) * CH,
        d = Math.hypot((px - cx) / CW, ((r - cy) / CH) * 1.1);
      if (d < d1) {
        d2 = d1;
        d1 = d;
        bx = cx;
        by = cy;
        id = (gx + i) * 31 + gy + j;
      } else if (d < d2) d2 = d;
    }
  const local = -(((px - bx) / CW) * 0.5 + ((r - by) / CH) * 0.9);
  let v =
    (face === 1 ? 0.1 : -0.38) +
    lift +
    local * 0.45 +
    (nhash(id, 0, seed + 2) - 0.5) * 0.3 +
    (nhash(px, py, seed + 3) - 0.5) * 0.1;
  if (d2 - d1 < 0.09) v -= 0.75;
  else if (d2 - d1 < 0.16 && local > 0) v += 0.25;
  return tone(t, v, [0.62, 0.3, 0.0, -0.3, -0.62]);
}
/** Fill pixels of marker colour `m` with `shade(x, y)`. */
function recolour(
  c: IsoCanvas,
  m: string,
  shade: (x: number, y: number) => string,
) {
  const { p } = c,
    w = p.width,
    h = Math.floor(p.data.length / (4 * w)),
    [mr, mg, mb] = [
      parseInt(m.slice(1, 3), 16),
      parseInt(m.slice(3, 5), 16),
      parseInt(m.slice(5, 7), 16),
    ];
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (
        p.data[i + 3] &&
        p.data[i] === mr &&
        p.data[i + 1] === mg &&
        p.data[i + 2] === mb
      )
        p.pixel(x, y, shade(x, y));
    }
}
/** Irregular rounded boulder (screen-space blob) shaded as rock with moss on top. */
function boulder(
  c: IsoCanvas,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  seed: number,
  t: Tones = ROCK,
  moss = true,
) {
  for (let py = Math.floor(cy - ry - 2); py <= cy + ry + 1; py++)
    for (let px = Math.floor(cx - rx - 2); px <= cx + rx + 2; px++) {
      const a = Math.atan2(py - cy, px - cx),
        wob = 1 + (nhash(Math.round(a * 4), seed) - 0.5) * 0.25,
        dx = (px + 0.5 - cx) / (rx * wob),
        dy = (py + 0.5 - cy) / (ry * wob);
      const d = Math.hypot(dx, dy);
      if (d > 1) continue;
      let v = -(dx * 0.6 + dy * 0.8) * 0.7 + (nhash(px, py, seed) - 0.5) * 0.2;
      if (dy > 0.55) v -= 0.35;
      const facet = nhash(Math.floor(px / 5), Math.floor(py / 4), seed + 3);
      if (facet < 0.18) v -= 0.25;
      let col = tone(t, v, [0.6, 0.3, 0.0, -0.32, -0.62]);
      if (moss && dy < -0.25 && nhash(px, py, seed + 5) < 0.75 - dy * 0.2)
        col = tone(MOSS, v + 0.2, [0.55, 0.05]);
      c.p.pixel(px, py, col);
    }
}

const nature: Record<string, Spec> = {
  // NATURE-OBJECTS
  'm-tree': {
    // A lush broadleaf: clustered canopy over a tapered trunk with roots.
    footprint: [1, 1],
    h: 92,
    pad: 30,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 1, 15, 3, [C.pink, C.white, C.yellow]);
      trunk(c, x, y, 40, 8, 4);
      branch(c, x - 1, y - 24, x - 13, y - 42, 1.6);
      branch(c, x + 1, y - 22, x + 14, y - 40, 1.6);
      canopy(c, 11, x, y - 56, 28, 25, FOLIAGE, 30, 6.5, 10);
    },
  },
  'm-oak': {
    // A broad old oak: wide three-lobed canopy, thick trunk, spreading roots.
    footprint: [1, 1],
    h: 98,
    pad: 38,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 2, 20, 5, [C.white, C.yellow]);
      for (const [dx, dy] of [
        [-11, 2],
        [10, 3],
        [-6, 4],
        [6, 4],
      ])
        branch(c, x + dx * 0.3, y - 1, x + dx, y + dy, 2.2);
      trunk(c, x, y, 40, 13, 8);
      branch(c, x - 3, y - 30, x - 22, y - 50, 2.6);
      branch(c, x + 3, y - 28, x + 22, y - 48, 2.6);
      branch(c, x, y - 36, x - 2, y - 60, 2.2);
      canopy(c, 21, x - 15, y - 56, 20, 17, OAK, 18, 6.5, 10);
      canopy(c, 22, x + 15, y - 55, 20, 17, OAK, 18, 6.5, 10);
      canopy(c, 23, x, y - 68, 24, 20, OAK, 24, 7, 11);
    },
  },
  'm-pine': {
    // A tall conifer in drooping tiers, darker blue-green, lit from the left.
    footprint: [1, 1],
    h: 106,
    pad: 26,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 1, 12, 9);
      trunk(c, x, y, 22, 6, 4, BARK, false);
      const box = { cx: x, cy: y - 56, rx: 22, ry: 48 };
      for (let t = 0; t < 7; t++) {
        const cy = y - 18 - t * 11.5,
          half = 21 - t * 2.9,
          tierBox = { ...box };
        // Dark skirt under each tier so needles never show gaps.
        c.p.poly(
          [
            [x - half, cy + 3],
            [x + half, cy + 3],
            [x, cy - 13],
          ],
          PINE[4],
        );
        const m = Math.round(half / 3) + 2,
          clumps: Clump[] = [];
        for (let i = 0; i <= m; i++) {
          const u = -1 + (2 * i) / m;
          clumps.push({
            x: x + u * half * 0.92,
            y: cy + u * u * 4 + nhash(i, t, 4) * 1.5,
            r: 4.6 - t * 0.25,
          });
          if (i % 2 === 0 && Math.abs(u) < 0.7)
            clumps.push({
              x: x + u * half * 0.55,
              y: cy - 6,
              r: 4.2 - t * 0.2,
            });
        }
        paintClumps(
          c,
          clumps.sort((p, q) => p.y - q.y),
          PINE,
          tierBox,
          30 + t,
        );
      }
      paintClumps(c, [{ x, y: y - 100, r: 3.2 }], PINE, box, 40);
    },
  },
  'm-cherry': {
    // Cherry blossom: soft pink clusters with dark branches showing through.
    footprint: [1, 1],
    h: 90,
    pad: 32,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      // Fallen petals on the grass.
      for (let i = 0; i < 26; i++) {
        const a = nhash(i, 81) * Math.PI * 2,
          r = Math.sqrt(nhash(i, 82)) * 18;
        c.p.pixel(
          x + Math.cos(a) * r,
          y + 1 + Math.sin(a) * r * 0.5,
          i % 3 ? BLOSSOM[1] : BLOSSOM[2],
        );
      }
      const bark = [NC.bark1, NC.bark2, NC.bark3, NC.bark3] as const;
      trunk(c, x, y, 38, 7, 4, bark);
      const box = { cx: x, cy: y - 60, rx: 28, ry: 21 };
      paintClumps(
        c,
        clumpsIn(61, x + 2, y - 58, 26, 18, 14, 6, 9),
        BLOSSOM,
        box,
        62,
        -0.5,
      );
      branch(c, x - 1, y - 32, x - 20, y - 54, 1.8, bark);
      branch(c, x + 1, y - 30, x + 21, y - 52, 1.8, bark);
      branch(c, x, y - 36, x + 3, y - 70, 1.6, bark);
      branch(c, x - 10, y - 44, x - 15, y - 66, 1.1, bark);
      paintClumps(
        c,
        clumpsIn(63, x, y - 62, 28, 21, 22, 5.5, 8.5),
        BLOSSOM,
        box,
        64,
      );
    },
  },
  'm-palm': {
    // Coconut palm: a ringed trunk curving toward the light under a crown of
    // arching, drooping fronds fringed with leaflets.
    footprint: [1, 1],
    h: 104,
    pad: 40,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 1, 12, 95);
      const top: [number, number] = [x + 9, y - 80],
        ctrl: [number, number] = [x - 7, y - 38],
        palmBark = [NC.palm0, NC.palm1, NC.palm2, NC.bark2] as const;
      for (let j = 0; j <= 82; j++) {
        const s = j / 82,
          bx =
            (1 - s) * (1 - s) * x + 2 * (1 - s) * s * ctrl[0] + s * s * top[0],
          by =
            (1 - s) * (1 - s) * y + 2 * (1 - s) * s * ctrl[1] + s * s * top[1],
          half = 3.9 - s * 1.7 + (j < 4 ? (4 - j) * 0.6 : 0),
          ring = j % 4 === 0 ? 1 : 0;
        for (let i = Math.floor(bx - half); i <= bx + half; i++) {
          const u = (i + 0.5 - bx) / half;
          c.p.pixel(i, by, palmBark[(u < -0.35 ? 0 : u > 0.4 ? 2 : 1) + ring]);
        }
      }
      // Fronds pointing away are drawn first and a shade darker.
      const fronds = [-160, -115, -70, -25, 15, 60, 110, 155].sort(
        (a, b) => Math.sin((a * Math.PI) / 180) - Math.sin((b * Math.PI) / 180),
      );
      const frond = (deg: number, k: number) => {
        const a = (deg * Math.PI) / 180,
          away = Math.sin(a) < 0,
          L = (away ? 27 : 33) + nhash(k, 90) * 6,
          pts: [number, number][] = [];
        for (let i = 0; i <= 40; i++) {
          const s = i / 40;
          pts.push([
            top[0] + Math.cos(a) * L * s,
            top[1] + Math.sin(a) * L * s * 0.5 - 10 * s + 25 * s * s,
          ]);
        }
        // A tapered blade: lit above the midrib, shaded below, with a
        // serrated lower edge of leaflet tips.
        const d = away ? 1 : 0;
        for (let i = 1; i < pts.length; i++) {
          const s = i / 40,
            [fx, fy] = pts[i],
            tx = fx - pts[i - 1][0],
            ty = fy - pts[i - 1][1],
            tl = Math.hypot(tx, ty) || 1;
          let nx = -ty / tl,
            ny = tx / tl;
          if (ny < 0) {
            nx = -nx;
            ny = -ny;
          }
          const w =
              1.2 + 5 * Math.sin(Math.PI * (0.12 + 0.85 * s)) * (1 - 0.4 * s),
            tip = w < 2 ? 0 : i % 3 === 0 ? 1.6 : i % 3 === 1 ? 0.6 : 0,
            edge = w * 0.65 + tip;
          for (let q = -w * 0.35; q <= edge; q += 0.5) {
            // The lowest pixel is a dark edge, so overlapping fronds part.
            const t =
              q < -0.6
                ? 1
                : q < 0.6
                  ? 2
                  : q < w * 0.45
                    ? 3
                    : q > edge - 0.5
                      ? 5
                      : 4;
            c.p.pixel(fx + nx * q, fy + ny * q, FOLIAGE[Math.min(5, t + d)]);
          }
        }
      };
      const coconuts = () => {
        for (const [dx, dy] of [
          [-3, 4],
          [2, 5],
          [5, 2],
          [-1, 1],
        ]) {
          c.p.ellipse(top[0] + dx, top[1] + dy, 2.3, 2.3, NC.coconut);
          c.p.pixel(top[0] + dx - 1, top[1] + dy - 1, NC.palm1);
        }
      };
      let nuts = false;
      for (const [k, deg] of fronds.entries()) {
        if (!nuts && Math.sin((deg * Math.PI) / 180) >= 0) {
          coconuts();
          nuts = true;
        }
        frond(deg, k);
      }
    },
  },
  'm-birch': {
    // Slim birch: white bark with dark marks under a light, airy canopy.
    footprint: [1, 1],
    h: 94,
    pad: 28,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 1, 12, 7, [C.yellow, C.white]);
      const birch = [
        NC.birchBark0,
        NC.birchBark1,
        NC.birchBark1,
        NC.birchMark,
      ] as const;
      trunk(c, x, y, 56, 5, 3, birch, false);
      for (let j = 4; j < 54; j += 5)
        if (nhash(j, 33) < 0.7)
          c.p.rect(x - 2 + (j % 3), y - j, 2 + (j % 2), 1, NC.birchMark);
      branch(c, x, y - 42, x - 11, y - 60, 1, birch);
      branch(c, x, y - 46, x + 10, y - 66, 1, birch);
      canopy(c, 41, x + 1, y - 68, 20, 22, BIRCH_LEAF, 24, 4.5, 7.5);
    },
  },
  'm-bush': {
    // Flowering shrub.
    footprint: [1, 1],
    h: 30,
    pad: 20,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 2, 14, 51);
      canopy(c, 61, x, y - 9, 15, 10, FOLIAGE, 16, 4.5, 6.5);
      const petals = [C.pink, C.white, BLOSSOM[1], C.white];
      for (let i = 0; i < 14; i++) {
        const a = nhash(i, 52) * Math.PI * 2,
          r = Math.sqrt(nhash(i, 53)) * 11,
          px = Math.round(x + Math.cos(a) * r),
          py = Math.round(y - 10 + Math.sin(a) * r * 0.7);
        if (py > y - 4) continue;
        c.p.pixel(px, py, petals[i % petals.length]);
        c.p.pixel(px + 1, py, petals[i % petals.length]);
        c.p.pixel(px, py - 1, NC.blossom0);
      }
    },
  },
  'm-flowers': {
    // A walkable flower patch, baked into the ground.
    footprint: [1, 1],
    h: 6,
    pad: 6,
    floor: true,
    draw(c) {
      const colours = [C.pink, C.white, C.yellow, C.purple, BLOSSOM[1]];
      for (let i = 0; i < 30; i++) {
        const [px, py] = c.at(
          0.1 + nhash(i, 71) * 0.8,
          0.1 + nhash(i, 72) * 0.8,
          0,
        );
        c.p.pixel(px, py, FOLIAGE[3]);
        c.p.pixel(px, py - 1, FOLIAGE[2]);
        if (i % 3) {
          const col = colours[i % colours.length];
          c.p.pixel(px - 1, py - 2, col);
          c.p.pixel(px + 1, py - 2, col);
          c.p.pixel(px, py - 3, col);
          c.p.pixel(px, py - 2, C.yellow);
        } else c.p.pixel(px + 1, py - 1, FOLIAGE[1]);
      }
    },
  },
  'm-rock': {
    // Mossy boulder with a smaller stone and grass at its foot.
    footprint: [1, 1],
    h: 26,
    pad: 18,
    detail: { grain: 0 },
    draw(c) {
      const [x, y] = c.at(0.5, 0.5, 0);
      tufts(c, x, y + 3, 15, 73, [C.yellow]);
      boulder(c, x - 1, y - 8, 12, 9.5, 71);
      boulder(c, x + 11, y - 2, 5, 4, 72, ROCK, false);
    },
  },
  'm-rocks-small': {
    // Pebbles in the grass (walkable).
    footprint: [1, 1],
    h: 6,
    pad: 6,
    floor: true,
    draw(c) {
      for (let i = 0; i < 6; i++) {
        const [px, py] = c.at(
          0.15 + nhash(i, 75) * 0.7,
          0.15 + nhash(i, 76) * 0.7,
          0,
        );
        boulder(
          c,
          px,
          py - 1,
          2 + nhash(i, 77) * 1.8,
          1.4 + nhash(i, 78),
          79 + i,
          ROCK,
          false,
        );
      }
    },
  },
  'm-waterfall': {
    // A mossy outcrop of stepped blue-grey rock. A stream crosses the top,
    // spills from a notch as a bright waterfall and churns a misty pool.
    footprint: [5, 4],
    h: 156,
    pad: 22,
    frames: 4,
    period: 12,
    detail: { grain: 0 },
    draw(c, f) {
      const { p } = c,
        W = p.width,
        H = Math.floor(p.data.length / (4 * W)),
        [ax, ay] = c.at(0, 0, 0);
      /*
       * The rock is a height map of quarter-tile columns drawn into a small
       * scene buffer (what each pixel shows, how near it is, and where on
       * that surface it lies), then painted in one pass.
       */
      const TOP = 0,
        FRONT = 1,
        SIDE = 2,
        STREAM = 3,
        FALLING = 4,
        POOL = 5;
      const kind = new Int8Array(W * H).fill(-1),
        near = new Float32Array(W * H).fill(-1e9),
        ua = new Float32Array(W * H),
        ub = new Float32Array(W * H),
        uc = new Float32Array(W * H);
      const put = (
        px: number,
        py: number,
        k: number,
        d: number,
        a: number,
        b: number,
        e = 0,
      ) => {
        px = Math.floor(px);
        py = Math.floor(py);
        if (px < 0 || py < 0 || px >= W || py >= H) return;
        const i = py * W + px;
        if (d < near[i]) return;
        near[i] = d;
        kind[i] = k;
        ua[i] = a;
        ub[i] = b;
        uc[i] = e;
      };
      const G = 0.25,
        NX = 20,
        NY = 16,
        stream = (i: number) => i >= 8 && i <= 11,
        hill = (x: number) => Math.max(0, 1 - Math.abs(x - 2.5) / 2.6) ** 0.7;
      // Where the cliff face stands (tile y), per column: rounded, with the
      // stream's notch set back between two jutting buttresses.
      const frontY = (i: number) => {
        if (stream(i)) return 2;
        const x = (i + 0.5) * G,
          r = Math.sqrt(Math.max(0, 1 - ((x - 2.5) / 2.65) ** 2)),
          v =
            Math.round(
              (1.2 + 1.05 * r + (nhash(i >> 1, 0, 140) - 0.5) * 0.3) / G,
            ) * G;
        return i >= 6 && i <= 13 ? Math.max(2.25, v) : v;
      };
      const rockH = (i: number, j: number) => {
        const x = (i + 0.5) * G,
          y = (j + 0.5) * G,
          v =
            22 +
            84 * hill(x) +
            (frontY(i) - y) * 9 +
            (nhash(i >> 1, j >> 1, 141) - 0.5) * 16;
        return Math.max(8, Math.round(v / 6) * 6);
      };
      // The stream bed steps down toward the edge in little cascades.
      const bed: number[] = [];
      for (let j = 0; j < 8; j++)
        bed.push(
          Math.min(
            j ? bed[j - 1] : 1e9,
            Math.round((Math.min(rockH(7, j), rockH(12, j)) - 8) / 4) * 4,
          ),
        );
      const cellH = (i: number, j: number) =>
        stream(i) ? bed[j] : rockH(i, j);
      for (let j = 0; j < NY; j++)
        for (let i = 0; i < NX; i++) {
          if ((j + 0.5) * G >= frontY(i)) continue;
          const h = cellH(i, j),
            water = stream(i),
            x0 = i * G,
            x1 = x0 + G,
            y0 = j * G,
            y1 = y0 + G;
          // Front face (constant y, facing the light).
          for (
            let px = Math.ceil(ax + (x0 - y1) * 16 - 0.5);
            px + 0.5 < ax + (x1 - y1) * 16;
            px++
          ) {
            const x = (px + 0.5 - ax) / 16 + y1,
              py0 = ay + (x + y1) * 8;
            for (let z = 0; z < h; z++)
              if (water) put(px, py0 - z, FALLING, x + y1, x - 2, z, h);
              else put(px, py0 - z, FRONT, x + y1, h - z, h);
          }
          // Side face (constant x, in shade).
          for (
            let px = Math.ceil(ax + (x1 - y1) * 16 - 0.5);
            px + 0.5 < ax + (x1 - y0) * 16;
            px++
          ) {
            const y = x1 - (px + 0.5 - ax) / 16,
              py0 = ay + (x1 + y) * 8;
            for (let z = 0; z < h; z++)
              if (water) put(px, py0 - z, FALLING, x1 + y, 1, z, h);
              else put(px, py0 - z, SIDE, x1 + y, h - z, h);
          }
          // Top.
          for (
            let py = Math.floor(ay + (x0 + y0) * 8 - h);
            py <= ay + (x1 + y1) * 8 - h;
            py++
          )
            for (
              let px = Math.floor(ax + (x0 - y1) * 16);
              px <= ax + (x1 - y0) * 16;
              px++
            ) {
              const X = (px + 0.5 - ax) / 16,
                S = (py + 0.5 - ay + h) / 8,
                x = (S + X) / 2,
                y = (S - X) / 2;
              if (x >= x0 && x < x1 && y >= y0 && y < y1)
                put(px, py, water ? STREAM : TOP, x + y, x, y, h);
            }
        }
      // The pool at the foot of the cliff.
      const frontAt = (x: number) =>
        frontY(Math.max(0, Math.min(NX - 1, Math.floor(x / G))));
      for (let py = ay; py <= ay + 72; py++)
        for (let px = ax - 64; px <= ax + 80; px++) {
          const X = (px + 0.5 - ax) / 16,
            S = (py + 0.5 - ay) / 8,
            x = (S + X) / 2,
            y = (S - X) / 2,
            ang = Math.atan2(y - 2.95, x - 2.5),
            e = Math.hypot((x - 2.5) / 2.05, (y - 2.95) / 0.95);
          if (
            e < 1 - nhash(Math.round(ang * 5), 0, 142) * 0.1 &&
            y > frontAt(x)
          )
            put(px, py, POOL, x + y, x, y);
        }
      // Paint.
      const MOSSY = [NC.leaf0, NC.moss0, NC.leaf2, NC.moss1, NC.moss2] as const,
        WATER = [0.72, 0.42, 0.15, -0.1, -0.35, -0.6],
        impact = c.at(2.5, 2.05, 0);
      for (let py = 0; py < H; py++)
        for (let px = 0; px < W; px++) {
          const i = py * W + px,
            k = kind[i];
          if (k < 0) continue;
          let col: string;
          if (k === TOP) {
            // Moss and grass, a bright lip where the top breaks into cliff.
            const below = py + 1 < H ? kind[i + W] : -1,
              lip = below === FRONT || below === SIDE,
              n = nhash(px >> 1, py, 150);
            col =
              nhash(px >> 2, py >> 1, 151) < 0.14 && !lip
                ? rockShade(px, py, 0, 3)
                : tone(
                    MOSSY,
                    0.25 + (n - 0.5) * 0.6 + (lip ? 0.45 : 0),
                    [0.62, 0.3, 0.0, -0.3],
                  );
          } else if (k === FRONT || k === SIDE) {
            // Blocky stone in strata; moss and a few long vines hang over
            // each ledge, with a shadow under the overhang. The rock is
            // lighter near the top and darker toward the ground.
            const depth = ua[i],
              vine = nhash(px, 0, 155) < 0.1,
              drape =
                (k === FRONT ? 2 : 1) +
                nhash(px, 0, 152) * (k === FRONT ? 8 : 4) +
                (vine ? 8 + nhash(px, 0, 156) * 26 : 0);
            if (depth < drape)
              col = tone(
                MOSS,
                (k === FRONT ? 0.35 : -0.1) - depth * (vine ? 0.02 : 0.05),
                [0.5, 0.0],
              );
            else if (depth < drape + 2 && !vine)
              col = k === FRONT ? NC.rock4 : NC.rock5;
            else
              col = cliffShade(
                px,
                py,
                k === FRONT ? 1 : 2,
                3,
                0.12 - Math.min(1, depth / Math.max(24, ub[i])) * 0.3,
              );
          } else if (k === STREAM) {
            // The stream on top, ripples drifting toward the edge.
            const ph = (((py - px / 2 - f * 4) % 16) + 16) % 16;
            col = tone(
              FALL,
              0.05 + (ph < 4 ? 0.4 : 0) + (nhash(px, py, 153 + f) - 0.5) * 0.3,
              WATER,
            );
          } else if (k === FALLING) {
            // Falling water: bright streaks flow down; the lip and the foot
            // are white with foam.
            const u = ua[i],
              z = ub[i],
              lipZ = uc[i],
              off = nhash(Math.floor(u * 10), 0, 31) * 22,
              ph = ((((z + f * 5.5 + off) % 22) + 22) % 22) / 22;
            let v =
              0.3 -
              Math.abs(u - 0.5) * 0.9 +
              (ph < 0.4 ? 0.35 : ph < 0.55 ? 0.1 : -0.15);
            if (lipZ - z < 4) v += 0.5;
            if (z < 14 && nhash(px, py, 40 + f) < 0.7 - z * 0.045) v = 1;
            col = tone(FALL, v, WATER);
          } else {
            // The pool: churning foam where the water lands, rings spreading
            // out, deeper and darker in the middle, shaded by the cliff.
            const x = ua[i],
              y = ub[i],
              rr = Math.hypot(px - impact[0], (py - impact[1]) * 2),
              e = Math.hypot((x - 2.5) / 2.05, (y - 2.95) / 0.95);
            if (rr < 14 && nhash(px, py, 20 + f) < 0.8 - rr * 0.045)
              col = FALL[0];
            else {
              const ring = (((rr - f * 2.5) % 10) + 10) % 10;
              let v =
                0.02 - (1 - e) * 0.3 + (nhash(px >> 1, py, 154) - 0.5) * 0.12;
              if (e > 0.82) v += 0.35;
              if (ring < 1.3 && rr < 64) v += 0.45 * (1 - rr / 72);
              if (y - frontAt(x) < 0.2) v -= 0.3;
              col = tone(FALL, v, [0.75, 0.45, 0.2, -0.05, -0.3, -0.6]);
            }
          }
          p.pixel(px, py, col);
        }
      // Trees and shrubs on the top, ferns over the notch.
      const onTop = (x: number, y: number) =>
        c.at(x, y, cellH(Math.floor(x / G), Math.floor(y / G)));
      {
        const [tx, ty] = onTop(1.15, 0.55);
        trunk(c, tx, ty, 10, 4, 3, BARK, false);
        for (let t = 0; t < 4; t++)
          paintClumps(
            c,
            clumpsIn(160 + t, tx, ty - 12 - t * 7, 11 - t * 2.4, 4, 6, 3, 4.5),
            PINE,
            { cx: tx, cy: ty - 22, rx: 12, ry: 16 },
            161 + t,
          );
      }
      {
        const [tx, ty] = onTop(3.95, 0.5);
        trunk(c, tx, ty, 9, 5, 3);
        canopy(c, 165, tx, ty - 18, 13, 11, FOLIAGE, 14, 4, 6);
      }
      for (const [x, y, r] of [
        [0.45, 0.9, 7],
        [1.8, 1.6, 6],
        [3.35, 1.55, 6],
        [4.55, 1.0, 7],
        [2.6, 0.35, 5],
      ] as const) {
        const [bx, by] = onTop(x, y);
        canopy(
          c,
          170 + Math.round(x * 10),
          bx,
          by - r * 0.4,
          r,
          r * 0.65,
          FOLIAGE,
          8,
          2.5,
          3.8,
        );
      }
      for (const i of [7, 12]) {
        const x = (i + 0.5) * G,
          [fx, fy] = c.at(
            x,
            frontY(i),
            rockH(i, Math.floor(frontY(i) / G) - 1),
          );
        for (let k = 0; k < 5; k++)
          branch(
            c,
            fx - 5 + k * 2.5,
            fy - 1,
            fx - 6 + k * 2.6,
            fy + 5 + (k % 2) * 4,
            0.6,
            [FOLIAGE[2], FOLIAGE[2], FOLIAGE[3], FOLIAGE[3]],
          );
      }
      // Wet stones in the pool and a ring of boulders around it.
      boulder(c, ...c.at(1.65, 2.55, 2), 4.5, 3, 181, ROCK, false);
      boulder(c, ...c.at(3.4, 2.5, 2), 3.5, 2.6, 182, ROCK, false);
      for (let t = -0.35; t < Math.PI + 0.4; t += 0.31) {
        const k = Math.round(t * 10),
          [bx, by] = c.at(
            2.5 + Math.cos(t) * 2.12,
            2.95 + Math.sin(t) * 1.0,
            1,
          );
        boulder(
          c,
          bx,
          by,
          3 + nhash(k, 0, 183) * 2.5,
          2.2 + nhash(k, 0, 184) * 1.3,
          185 + k,
        );
      }
      tufts(c, ...c.at(0.35, 3.6, 0), 12, 97, [C.white, C.yellow]);
      tufts(c, ...c.at(4.75, 3.3, 0), 12, 98, [C.pink]);
      tufts(c, ...c.at(2.5, 3.98, 0), 10, 99, [C.white]);
      // Spray and mist rising from the foot of the fall.
      for (let i = 0; i < 80; i++) {
        const a = nhash(i, 50 + f) * Math.PI,
          r = 3 + nhash(i, 51 + f) * 22;
        c.p.pixel(
          impact[0] + Math.cos(a) * r * 1.2,
          impact[1] - Math.sin(a) * r * 0.5 - 3,
          i % 3 ? FALL[0] : FALL[1],
        );
      }
    },
  },
  'm-ship': {
    // A wooden sailing ship (no flags or emblems). It sits on the planet's
    // open sea, so it carries only its own shadow, bow wave and wake; the
    // hull bobs and the sails fill between the two frames.
    footprint: [3, 2],
    h: 110,
    pad: 26,
    frames: 2,
    period: 48,
    detail: { grain: 0 },
    shadow: false,
    draw(c, f) {
      // Shadow on the water along the hull.
      for (let py = 0; py < c.p.height; py++)
        for (let px = 0; px < c.p.width; px++) {
          const [ax, ay] = c.at(0, 0, 0),
            X = (px + 0.5 - ax) / 16,
            S = (py + 0.5 - ay) / 8,
            x = (S + X) / 2,
            y = (S - X) / 2,
            e = Math.hypot((x - 1.65) / 1.5, (y - 1.05) / 0.42);
          if (e < 1 - nhash(px >> 1, py, 4 + f) * 0.15)
            c.p.pixel(px, py, e < 0.7 ? SEA[4] : SEA[3]);
        }
      const zb = f ? 1 : 0,
        HULL = 22 + zb;
      const MH = '#010301',
        MD = '#010302';
      // Hull (front side faces +y), deck on top.
      c.poly(
        [
          [0.3, 1.34, HULL],
          [2.2, 1.38, HULL],
          [2.98, 1.0, HULL + 3],
          [2.82, 1.0, 5 + zb],
          [2.2, 1.24, 3 + zb],
          [0.4, 1.22, 5 + zb],
        ],
        MH,
      );
      c.poly(
        [
          [0.3, 0.66, HULL],
          [2.2, 0.62, HULL],
          [2.98, 1.0, HULL + 3],
          [2.2, 1.38, HULL],
          [0.3, 1.34, HULL],
        ],
        MD,
      );
      // Planks run along the hull: height above the water from the pixel.
      const [hax, hay] = c.at(0, 0, 0);
      recolour(c, MH, (px, py) => {
        const z = hay + (px - hax) / 2 + 16 * 1.3 - py;
        if (z < 8 + zb) return NC.hull2;
        if (z > HULL - 2) return C.woodLight;
        return Math.floor(z) % 4 === 0 ? NC.hull1 : NC.hull0;
      });
      // Deck planks run fore and aft.
      recolour(c, MD, (px, py) => {
        const y = ((py + 0.5 - hay + HULL) / 8 - (px + 0.5 - hax) / 16) / 2;
        return (((y * 9) % 1) + 1) % 1 < 0.2 ? NC.hull0 : C.woodLight;
      });
      // Dark wale and stern castle.
      c.edge([0.32, 1.33, HULL - 4], [2.25, 1.37, HULL - 4], NC.hull2);
      c.box(
        0.28,
        0.66,
        0.55,
        0.68,
        12,
        { top: C.woodLight, front: NC.hull0, side: NC.hull1, edge: NC.hull2 },
        HULL,
      );
      for (const x of [0.35, 0.55])
        c.faceX(x, 1.341, 0.1, HULL + 4, 4, NC.hull2);
      // Masts, yards and square sails (bellied), a jib at the bow.
      const masts: [number, number][] = [
        [0.95, 92],
        [1.6, 104],
        [2.25, 90],
      ];
      for (const [mx, mh] of masts) {
        const [px, py] = c.at(mx, 1, HULL);
        c.p.rect(px - 1, py - (mh - HULL), 2, mh - HULL, NC.hull2);
        for (const [z0, z1] of [
          [HULL + 12, HULL + (mh - HULL) * 0.52],
          [HULL + (mh - HULL) * 0.56, mh - 6],
        ]) {
          const MS = '#010303';
          const belly = 0.06 + (f ? 0.02 : 0);
          c.poly(
            [
              [mx, 0.48, z0],
              [mx + belly, 1.0, z0 - 1],
              [mx, 1.52, z0],
              [mx, 1.5, z1],
              [mx + belly, 1.0, z1],
              [mx, 0.5, z1],
            ],
            MS,
          );
          const [cx, cy] = c.at(mx, 1, (z0 + z1) / 2);
          recolour(c, MS, (px2, py2) => {
            const dx = (px2 - cx) / 14,
              dy = (py2 - cy) / ((z1 - z0) / 2);
            const v = 0.5 - Math.abs(dx) * 0.5 - dy * 0.25 + (f ? 0.05 : 0);
            return tone(
              [NC.sail0, NC.sail1, NC.sail2, NC.sail3],
              v,
              [0.42, 0.15, -0.1],
            );
          });
          c.edge([mx, 0.46, z1 + 1], [mx, 1.54, z1 + 1], NC.hull2);
        }
      }
      c.poly(
        [
          [2.25, 1, 84],
          [3.05, 1, HULL + 6],
          [2.3, 1, HULL + 8],
        ],
        NC.sail1,
      );
      c.edge([2.25, 1, 84], [3.05, 1, HULL + 6], NC.sail2);
      // Rigging.
      for (const [mx, mh] of masts) {
        c.edge([mx, 1, mh], [0.3, 1, HULL + 12], NC.hull2);
        c.edge([mx, 1, mh], [Math.min(2.98, mx + 0.75), 1, HULL + 2], NC.hull2);
      }
      // Foam along the waterline, a bow wave and a widening wake.
      for (let x = 0.3; x < 2.9; x += 1 / 32) {
        const [px, py] = c.at(x, 1.3 + (x > 2.2 ? (2.2 - x) * 0.4 : 0), 2);
        if (nhash(Math.round(x * 32), 64, f) < 0.7) c.p.pixel(px, py, SEA[0]);
      }
      for (let i = 0; i < 26; i++) {
        const [px, py] = c.at(
          2.9 + nhash(i, 60 + f) * 0.3,
          1.0 + (nhash(i, 61) - 0.5) * 0.7,
          0,
        );
        c.p.pixel(px, py, SEA[0]);
        c.p.pixel(px + 1, py, SEA[1]);
      }
      for (let i = 0; i < 40; i++) {
        const k = nhash(i, 62 + f),
          [px, py] = c.at(
            0.25 - k * 0.9,
            1.0 + (nhash(i, 63) - 0.5) * (0.3 + k * 0.9),
            0,
          );
        c.p.pixel(px, py, i % 3 ? SEA[0] : SEA[1]);
      }
    },
  },
  'm-beach-rocks': {
    // Wet rocks at the water's edge: a little tide pool at their feet with
    // surf lapping in and out between the two frames.
    footprint: [2, 1],
    h: 26,
    pad: 18,
    frames: 2,
    period: 24,
    // No outline: the wet sand and pool fade into the beach.
    detail: { grain: 0, outline: false },
    shadow: false,
    draw(c, f) {
      const [gx, gy] = c.at(1, 0.5, 0);
      // Darker wet sand, then the shallow pool and its foam edge.
      for (let py = gy - 9; py <= gy + 9; py++)
        for (let px = gx - 30; px <= gx + 30; px++) {
          const dx = (px + 0.5 - gx) / 29,
            dy = (py + 0.5 - gy - 1) / 8.5,
            d = Math.hypot(dx, dy) + (nhash(px >> 1, py, 130) - 0.5) * 0.12,
            reach = f ? 0.8 : 0.7;
          if (d > 1 || (d > 0.86 && nhash(px, py, 131) < (d - 0.86) * 7))
            continue;
          let col: string = C.sandDark;
          if (d < reach) {
            const wave = Math.sin(px * 0.5 + py * 1.4 + f * Math.PI);
            col = d < reach - 0.25 ? SEA[2] : SEA[1];
            if (wave > 0.82) col = SEA[0];
          } else if (d < reach + 0.07) col = SEA[0];
          c.p.pixel(px, py, col);
        }
      const wet = [
        NC.rock1,
        NC.rock2,
        NC.rock3,
        NC.rock4,
        NC.rock5,
        NC.rock5,
      ] as const;
      boulder(c, gx - 9, gy - 5, 9, 7, 121, wet, true);
      boulder(c, gx + 9, gy - 2, 7, 5.5, 122, wet, false);
      boulder(c, gx + 1, gy + 3, 4, 3, 123, wet, false);
      // Foam around the rocks' feet and glints of wet stone.
      for (let i = 0; i < 30; i++) {
        const a = nhash(i, 124 + f) * Math.PI,
          r = 7 + nhash(i, 125 + f) * 5;
        c.p.pixel(
          gx - 9 + Math.cos(a) * r * 1.3,
          gy + 1 + Math.sin(a) * r * 0.35,
          SEA[0],
        );
      }
      c.p.pixel(gx - 13, gy - 9, NC.water0);
      c.p.pixel(gx - 12, gy - 9, NC.water0);
      c.p.pixel(gx + 6, gy - 5, NC.water0);
    },
  },
};
Object.assign(objects, nature);

/* ════════ City pass: skyline, lit windows, street furniture ════════ */
// Blue-hour city: deep blue glass, warm and cool lit windows, glowing street
// life. Signs and panels are plain colour only (no text, logos or symbols).
const CN = {
  // Night glass, deep to light.
  glass0: C.screen,
  glass1: C.stageNavy,
  glass2: C.navy,
  glass3: CC.duskGlass,
  glass4: CC.skyGlass,
  glass5: CC.skyGlassLight,
  glass6: C.glassDeep,
  // Window light.
  warm: C.windowLit,
  amber: CC.amberLit,
  hot: C.lampGlow,
  cool: C.glow,
  coolDim: C.teal,
  // Dimmer versions for the shaded (+x) face.
  warmSide: C.gold,
  amberSide: C.orangeDark,
  coolSide: C.tealDark,
  // Concrete for poles and the broadcast tower.
  conc0: C.concrete,
  conc1: C.silver,
  conc2: C.grey,
  conc3: C.slate,
  // Cherry blossom.
  petal0: CC.blossomLight,
  petal1: C.rose,
  petal2: CC.blossom,
  petal3: CC.blossomDeep,
  bark: C.brownstoneDark,
  barkLight: C.trunk,
  aircraft: C.red,
};
/** Deterministic 0..1 hash for window patterns. */
const cityHash = (i: number, j: number, s = 0) => {
  let h = Math.imul(i * 374761393 + j * 668265263 + s * 2147483647, 1274126177);
  h ^= h >>> 13;
  return ((Math.imul(h, 1274126177) >>> 0) % 10000) / 10000;
};
/**
 * Window state for floor j, column i: whole floors light up in bands (as in
 * an office tower at dusk), with single windows varying inside them.
 */
function windowState(i: number, j: number, seed: number) {
  const floor = cityHash(0, j, seed),
    w = cityHash(i, j, seed + 1);
  if (floor < 0.42) return w < 0.82 ? 'warm' : w < 0.92 ? 'amber' : 'dark';
  if (floor < 0.62) return w < 0.7 ? 'cool' : 'dark';
  return w < 0.14 ? 'warm' : w < 0.2 ? 'cool' : 'dark';
}
type WindowShades = { warm: string; amber: string; cool: string; dark: string };
const FRONT_LIGHTS: WindowShades = {
  warm: CN.warm,
  amber: CN.amber,
  cool: CN.cool,
  dark: CN.glass2,
};
const SIDE_LIGHTS: WindowShades = {
  warm: CN.warmSide,
  amber: CN.amberSide,
  cool: CN.coolSide,
  dark: CN.glass1,
};
/** Lit-window grid on a front (+y) face. */
function nightWindowsFront(
  c: IsoCanvas,
  x0: number,
  x1: number,
  y: number,
  z0: number,
  z1: number,
  step: number,
  row: number,
  w: number,
  h: number,
  seed: number,
  shades: WindowShades = FRONT_LIGHTS,
) {
  let i = 0;
  for (let u = x0; u + w <= x1 + 1e-6; u += step, i++) {
    let j = 0;
    for (let z = z0; z + h <= z1; z += row, j++) {
      const s = windowState(i, j, seed);
      c.faceX(u, y, w, z, h, shades[s]);
      // A soft top shade inside lit windows (blinds, ceiling).
      if (s !== 'dark' && h >= 3)
        c.faceX(u, y + 0.001, w, z + h - 1, 1, darker(shades[s]));
    }
  }
}
/** Lit-window grid on a side (+x) face. */
function nightWindowsSide(
  c: IsoCanvas,
  x: number,
  y0: number,
  y1: number,
  z0: number,
  z1: number,
  step: number,
  row: number,
  w: number,
  h: number,
  seed: number,
  shades: WindowShades = SIDE_LIGHTS,
) {
  let i = 0;
  for (let v = y0; v + w <= y1 + 1e-6; v += step, i++) {
    let j = 0;
    for (let z = z0; z + h <= z1; z += row, j++)
      c.faceY(x, v, w, z, h, shades[windowState(i + 7, j, seed)]);
  }
}
/** Checkerboard a colour over part of a side (+x) face. */
function ditherSide(
  c: IsoCanvas,
  x: number,
  y0: number,
  y1: number,
  z0: number,
  z1: number,
  col: string,
) {
  const [sx0] = c.at(x, y0, 0),
    [sx1] = c.at(x, y1, 0);
  for (let px = Math.ceil(Math.min(sx0, sx1)); px < Math.max(sx0, sx1); px++) {
    const v = y0 + (sx0 - px) / 16,
      [, top] = c.at(x, v, z1),
      [, bottom] = c.at(x, v, z0);
    for (let py = Math.ceil(top); py < bottom; py++)
      if ((px + py) % 2 === 0 && c.p.data[(py * c.p.width + px) * 4 + 3])
        c.p.pixel(px, py, col);
  }
}
/** A blinking-free aircraft light: a red pixel with a soft halo. */
function aircraftLight(c: IsoCanvas, x: number, y: number, z: number) {
  const [px, py] = c.at(x, y, z);
  c.p.pixel(px - 1, py, C.redDark);
  c.p.pixel(px + 1, py, C.redDark);
  c.p.pixel(px, py - 1, C.redDark);
  c.p.pixel(px, py, CN.aircraft);
}
/** 4×4 ordered-dither thresholds, for soft light falling off on the ground. */
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
/**
 * A soft pool of light on the ground at tile point (x, y): dense near the
 * centre, thinning out to the rim (rx, ry in screen pixels).
 */
function lightPool(
  c: IsoCanvas,
  x: number,
  y: number,
  rx: number,
  ry: number,
  strength = 0.7,
  inner: string = CN.hot,
  outer: string = CN.warm,
) {
  const [gx, gy] = c.at(x, y, 0);
  for (let j = Math.floor(-ry); j <= ry; j++)
    for (let i = Math.floor(-rx); i <= rx; i++) {
      const k = Math.sqrt((i / rx) ** 2 + (j / ry) ** 2);
      if (k > 1) continue;
      const px = Math.round(gx + i),
        py = Math.round(gy + j),
        t = BAYER[(py & 3) * 4 + (px & 3)] / 16;
      if (t < strength * (1 - k) ** 1.4)
        c.p.pixel(px, py, k < 0.4 ? inner : outer);
    }
}
/** Geometric light panels: bright frame and coloured bars, never writing. */
function neonPanelFront(
  c: IsoCanvas,
  x: number,
  y: number,
  w: number,
  z: number,
  h: number,
  cool = true,
) {
  const rim = cool ? C.glow : C.pink;
  c.faceX(x, y, w, z, h, C.screen);
  c.edge([x, y + 0.001, z], [x + w, y + 0.001, z], rim);
  c.edge([x, y + 0.001, z + h], [x + w, y + 0.001, z + h], rim);
  c.edge([x, y + 0.001, z], [x, y + 0.001, z + h], rim);
  c.edge([x + w, y + 0.001, z], [x + w, y + 0.001, z + h], rim);
  for (let j = 0; j < 4; j++) {
    const pad = w * (j % 2 ? 0.2 : 0.12);
    c.faceX(
      x + pad,
      y + 0.002,
      w - pad * 2,
      z + 3 + (j * (h - 5)) / 4,
      2,
      j % 2 ? (cool ? C.glassLight : C.lampGlow) : rim,
    );
  }
}
/**
 * A night glass tower: a podium with a glowing lobby, a shaft of deep blue
 * glass with a lit window grid, sky reflection toward the top and floor
 * lines, and a crown.
 */
function nightTower(
  c: IsoCanvas,
  o: number,
  size: number,
  shaftH: number,
  seed: number,
  base = 3,
) {
  // Podium and warm lobby.
  const b = base;
  c.box(0, 0, b, b, 16, {
    top: C.slate,
    front: C.charcoal,
    side: C.ink,
    edge: C.ink,
  });
  c.faceX(0.25, b + 0.002, b - 0.5, 2, 11, CN.hot);
  c.faceX(0.25, b + 0.003, b - 0.5, 10, 3, CN.amber);
  for (let u = 0.25; u < b - 0.2; u += 0.42)
    c.faceX(u, b + 0.004, 0.05, 2, 11, C.charcoal);
  c.faceY(b + 0.002, 0.3, b - 0.6, 2, 11, CN.warmSide);
  c.faceY(b + 0.003, 0.3, b - 0.6, 10, 3, CN.amberSide);
  for (let v = 0.3; v < b - 0.25; v += 0.42)
    c.faceY(b + 0.004, v, 0.05, 2, 11, C.ink);
  c.box(b / 2 - 0.65, b, 1.3, 0.25, 2, M.steel, 13);
  const z0 = 16,
    z1 = z0 + shaftH,
    e = o + size;
  c.box(
    o,
    o,
    size,
    size,
    shaftH,
    {
      top: CN.glass4,
      front: CN.glass3,
      side: CN.glass1,
      edge: CN.glass0,
    },
    z0,
  );
  // Sky reflected on the upper glass; the base sits in the dusk shadow.
  ditherFront(
    c,
    o + size * 0.04,
    o + size * 0.19,
    e + 0.001,
    z1 - shaftH * 0.34,
    z1,
    CN.glass4,
    0.25,
  );
  ditherFront(
    c,
    o + size * 0.53,
    o + size * 0.69,
    e + 0.001,
    z1 - shaftH * 0.12,
    z1,
    CN.glass5,
    0.25,
  );
  ditherSide(c, e + 0.001, o, e, z1 - shaftH * 0.3, z1, CN.glass2);
  nightWindowsFront(
    c,
    o + 0.06,
    e - 0.04,
    e + 0.002,
    z0 + 4,
    z1 - 4,
    0.205,
    6,
    0.13,
    3,
    seed,
  );
  nightWindowsSide(
    c,
    e + 0.002,
    o + 0.06,
    e - 0.04,
    z0 + 4,
    z1 - 4,
    0.205,
    6,
    0.13,
    3,
    seed,
  );
  // Vertical fins catch a thin rim of light on the lit corner.
  c.edge([o, e + 0.003, z0], [o, e + 0.003, z1], CN.glass6);
  c.edge([e + 0.003, e + 0.003, z0], [e + 0.003, e + 0.003, z1], CN.glass0);
  for (let u = o + 0.615; u < e - 0.1; u += 0.615)
    c.edge([u, e + 0.003, z0 + 2], [u, e + 0.003, z1 - 2], CN.glass2);
  // Long diagonal reflections, very sparse.
  for (let k = 0; k < 3; k++) {
    const z = z0 + 30 + k * (shaftH / 3.2);
    c.edge([o + 0.1, e + 0.004, z], [o + 0.7, e + 0.004, z + 22], CN.glass5);
  }
  // Parapet light line.
  c.edge([o, e + 0.004, z1 - 1], [e, e + 0.004, z1 - 1], CN.cool);
  c.edge([e + 0.004, o, z1 - 1], [e + 0.004, e, z1 - 1], CN.glass4);
  // A few brilliant accents sit against dark window grids, like the
  // reference night skyline. Solid facades retain broad readable shapes.
  const signZ = z0 + shaftH * (seed % 2 ? 0.22 : 0.39);
  neonPanelFront(
    c,
    o + size * 0.08,
    e + 0.006,
    size * 0.3,
    signZ,
    25,
    seed % 3 !== 0,
  );
  c.edge(
    [e, e + 0.007, z0 + 6],
    [e, e + 0.007, z1 - 10],
    seed % 2 ? C.teal : C.pinkDark,
  );
  for (let floor = 3; floor < 12; floor += 4) {
    const bandZ = z0 + (shaftH * floor) / 13;
    c.faceX(
      o + size * 0.49,
      e + 0.008,
      size * 0.47,
      bandZ,
      2,
      seed % 2 ? CN.cool : C.pink,
    );
  }
  return z1;
}
/**
 * A concrete utility pole with two cross-arms. Wires run along x toward the
 * next pole (6 tiles away) in each direction in `dirs`, sagging to meet that
 * pole's wires at the midpoint: z(s) = z0 + 1 - 8 s (6 - s) / 9. A pole that
 * ends a run is held by a guy wire. The -side variant runs along y.
 */
function utilityPole(dirs: number[]): Spec {
  return {
    footprint: [1, 1],
    h: 98,
    pad: 58,
    side: true,
    detail: { outline: true, rim: false, grain: 0, contact: true },
    shadow: false,
    draw(c) {
      const [px, py] = c.at(0.5, 0.5, 0);
      // Concrete pole with a footing, joint rings and climbing steps.
      c.p.rect(px - 2, py - 92, 4, 92, CN.glass3);
      c.p.rect(px - 2, py - 92, 1, 92, CN.glass5);
      c.p.rect(px + 1, py - 92, 1, 92, CN.glass0);
      c.p.rect(px - 3, py - 4, 6, 4, CN.glass0);
      for (let z = 20; z < 88; z += 17)
        c.p.rect(px - 2, py - z, 4, 1, CN.glass0);
      for (let z = 30; z < 70; z += 6)
        c.p.pixel(px + (z % 12 ? 2 : -3), py - z, C.steelDark);
      // Transformer drum, a junction box and a small plain plate.
      c.cylinder(0.62, 0.5, 52, 4, 11, [CN.glass3, CN.glass0, CN.glass0]);
      c.p.rect(px + 1, py - 66, 6, 1, C.steelDark);
      c.p.rect(px + 2, py - 40, 3, 6, C.slate);
      c.p.rect(px + 2, py - 40, 1, 6, C.grey);
      c.p.rect(px - 2, py - 28, 4, 3, C.yellow);
      // Cross-arms run across the street (along y): the top one carries the
      // three power lines along x; the lower one holds the transformer leads.
      const lanes = [0.12, 0.5, 0.88];
      for (const [z, v0, v1] of [
        [86, 0.05, 0.95],
        [76, 0.3, 0.7],
      ]) {
        c.thick(c.at(0.5, v0, z), c.at(0.5, v1, z), 0.6, CN.glass0);
        c.line(c.at(0.5, v0, z + 1), c.at(0.5, v1, z + 1), CN.glass3);
      }
      for (const v of lanes) {
        const [ix, iy] = c.at(0.5, v, 87);
        c.p.rect(ix, iy - 2, 1, 2, C.offwhite);
      }
      for (const v of [0.34, 0.66]) {
        const [ix, iy] = c.at(0.5, v, 77);
        c.p.rect(ix, iy - 2, 1, 2, C.offwhite);
        c.line([ix, iy - 2], c.at(0.62, 0.5, 63), C.charcoal);
      }
      for (const z0 of [86])
        for (const v of lanes)
          for (const dir of dirs) {
            let last = c.at(0.5, v, z0 + 1);
            for (let k = 1; k <= 30; k++) {
              const s = (k / 30) * 3,
                z = z0 + 1 - (8 * s * (6 - s)) / 9,
                next = c.at(0.5 + dir * s, v, z);
              c.line(last, next, C.ink);
              last = next;
            }
          }
      // A thinner telecom cable lower down, and a guy wire at a run's end.
      for (const dir of dirs) {
        let last = c.at(0.5, 0.5, 62);
        for (let k = 1; k <= 30; k++) {
          const s = (k / 30) * 3,
            next = c.at(0.5 + dir * s, 0.5, 62 - (10 * s * (6 - s)) / 9);
          c.line(last, next, C.charcoal);
          last = next;
        }
      }
      if (dirs.length === 1) {
        const back = -dirs[0];
        c.line(c.at(0.5, 0.5, 80), c.at(0.5 + back * 0.45, 0.5, 0), C.charcoal);
        c.p.rect(...c.at(0.5 + back * 0.45, 0.5, 0), 2, 1, C.slate);
      }
    },
  };
}
/** Colourway for a shop house: walls, awning stripes, plain sign panel. */
type ShopLook = {
  wall: Material;
  trim: string;
  awning: [string, string, string];
  sign: [string, string];
  /** Which of the two upper windows are lit. */
  lit: [boolean, boolean];
};
/**
 * A narrow two-storey shop house: a warm lit shop window and door under a
 * striped awning, a plain sign panel (no text), a paper lantern, upper
 * windows with a wall air-conditioner, and rooftop plant.
 */
function awningShop(o: ShopLook): Spec {
  return {
    footprint: [2, 1],
    h: 92,
    pad: 10,
    draw(c) {
      lightPool(c, 0.8, 1.2, 24, 6, 0.5);
      c.box(0, 0, 2, 0.8, 64, {
        top: C.cream,
        front: C.ivory,
        side: C.creamShade,
        edge: C.woodDark,
      });
      c.faceX(0, 0.801, 2, 0, 7, C.sandShade);
      coursesFront(c, 0, 2, 0.802, 0, 7, 3, 0.4, C.clay, C.sand);
      // A timber-framed gable, with terracotta roof tiles rather than a flat roof.
      c.poly(
        [
          [0, 0.8, 64],
          [2, 0.8, 64],
          [1, 0.8, 83],
        ],
        C.cream,
      );
      for (const x of [0.02, 0.96, 1.92]) {
        c.faceX(x, 0.803, 0.08, 7, x === 0.96 ? 73 : 57, C.woodDark);
        c.edge([x + 0.02, 0.804, 8], [x + 0.02, 0.804, 62], C.wood);
      }
      for (const z of [30, 43, 63]) {
        c.faceX(0, 0.805, 2, z, 3, C.woodDark);
        c.edge([0, 0.806, z + 2], [2, 0.806, z + 2], C.woodLight);
      }
      c.edge([0.08, 0.807, 64], [0.95, 0.807, 80], C.woodDark);
      c.edge([1.05, 0.807, 80], [1.93, 0.807, 64], C.woodDark);
      c.edge([0.18, 0.807, 44], [0.55, 0.807, 61], C.woodDark);
      c.edge([1.78, 0.807, 44], [1.4, 0.807, 61], C.woodDark);
      // Warm shop window, shelves, and a planked door with a small glass light.
      c.faceX(0.15, 0.809, 1.14, 8, 20, C.woodDark);
      c.faceX(0.2, 0.81, 1.04, 10, 16, CN.warm);
      for (const z of [15, 22]) c.faceX(0.2, 0.811, 1.04, z, 1, C.woodDark);
      c.faceX(0.69, 0.812, 0.06, 10, 17, C.woodDark);
      for (let i = 0; i < 8; i++) {
        const x = 0.24 + i * 0.12;
        c.faceX(
          x,
          0.812,
          0.06,
          16 + (i % 2) * 7,
          3,
          accents[(i * 3) % accents.length],
        );
      }
      c.faceX(1.43, 0.81, 0.43, 3, 26, C.woodDark);
      c.faceX(1.47, 0.811, 0.35, 4, 24, C.wood);
      for (let i = 0; i < 4; i++)
        c.edge(
          [1.49 + i * 0.08, 0.812, 4],
          [1.49 + i * 0.08, 0.812, 27],
          C.woodDark,
        );
      c.faceX(1.51, 0.813, 0.26, 17, 9, C.glassDeep);
      c.edge([1.64, 0.814, 18], [1.64, 0.814, 25], C.woodLight);
      c.p.pixel(...c.at(1.76, 0.815, 13), C.gold);
      c.box(1.36, 0.8, 0.58, 0.23, 2, M.stone);
      // Canvas porch awning and a small lantern, all signage remains blank.
      const [aLight, aDark, aDeep] = o.awning;
      c.poly(
        [
          [0.04, 0.8, 39],
          [1.35, 0.8, 39],
          [1.35, 1.12, 33],
          [0.04, 1.12, 33],
        ],
        aDark,
      );
      for (let x = 0.04; x < 1.32; x += 0.22)
        c.poly(
          [
            [x, 0.8, 39],
            [x + 0.11, 0.8, 39],
            [x + 0.11, 1.12, 33],
            [x, 1.12, 33],
          ],
          aLight,
        );
      c.faceX(0.04, 1.121, 1.31, 30, 3, aDark);
      c.edge([0.04, 1.122, 30], [1.35, 1.122, 30], aDeep);
      for (const x of [0.22, 1.2]) {
        sashFront(c, x, 0.808, 0.53, 47, 12, {
          frame: C.woodDark,
          glass: C.glassDeep,
          shade: C.navy,
          glint: C.glassLight,
          sill: C.woodLight,
          bars: true,
          inside: C.cream,
        });
        villageFlowerBox(c, x - 0.04, 0.82, 42, 0.61, x > 1 ? 2 : 0);
      }
      c.faceY(2.001, 0.12, 0.52, 45, 13, C.woodDark);
      c.faceY(2.002, 0.18, 0.4, 47, 9, C.glassDeep);
      // Two pitched planes with staggered individual clay shingles.
      for (const side of [-1, 1]) {
        const edge = side < 0 ? -0.16 : 2.16;
        c.poly(
          [
            [1, -0.18, 84],
            [1, 0.96, 84],
            [edge, 0.96, 63],
            [edge, -0.18, 63],
          ],
          side < 0 ? C.terracottaDark : C.terracotta,
        );
        for (let row = 0; row < 7; row++) {
          const t = row / 7,
            nt = (row + 1) / 7;
          const x = 1 + (edge - 1) * t,
            nx = 1 + (edge - 1) * nt;
          const z = 84 - t * 21,
            nz = 84 - nt * 21;
          c.edge([x, -0.18, z], [x, 0.96, z], C.terracottaLight);
          for (let y = -0.18 + (row % 2) * 0.1; y < 0.96; y += 0.21) {
            c.edge([x, y, z], [nx, y, nz], C.terracottaDark);
            c.edge([x, y + 0.03, z], [nx, y + 0.03, nz], C.terracottaLight);
          }
        }
        c.edge([edge, -0.18, 63], [edge, 0.96, 63], C.woodDark);
        c.edge([1, 0.97, 84], [edge, 0.97, 63], C.woodDark);
        c.edge([1, 0.98, 85], [edge, 0.98, 64], C.terracottaLight);
      }
      c.edge([1, -0.2, 85], [1, 0.98, 85], C.terracottaLight);
      // Moss, trailing plants, and a terracotta planter settle the cottage into the garden.
      c.pot(1.99, 1.0, 0, 3, 5, R.terracotta, C.soil);
      c.greenery(1.99, 1.0, 10, 5, R.leaf, C.pink);
      const [lx, ly] = c.at(1.95, 0.95, 36);
      c.p.rect(lx - 2, ly - 4, 5, 8, C.woodDark);
      c.p.rect(lx - 1, ly - 3, 3, 5, C.lamp);
      c.p.pixel(lx, ly - 3, C.white);
    },
  };
}
const city: Record<string, Spec> = {
  // CITY-OBJECTS
  'm-neon-shop': {
    footprint: [3, 1],
    h: 108,
    pad: 12,
    side: true,
    detail: { grain: 0, rim: false },
    draw(c) {
      lightPool(c, 1.5, 1.1, 40, 10, 0.85, C.glow, C.teal);
      c.box(0, 0, 3, 0.9, 94, {
        top: CN.glass4,
        front: CN.glass2,
        side: CN.glass0,
        edge: CN.glass0,
      });
      // Cool shop light, warm upstairs rooms, and an external stair pipe.
      c.faceX(0.12, 0.902, 2.72, 4, 26, CN.glass0);
      c.faceX(0.18, 0.903, 1.65, 7, 20, C.glow);
      c.faceX(0.2, 0.904, 1.61, 23, 3, C.glassLight);
      for (let x = 0.22; x < 1.8; x += 0.28)
        c.faceX(x, 0.905, 0.05, 7, 20, CN.glass2);
      c.faceX(2.03, 0.903, 0.54, 4, 25, CN.warm);
      c.faceX(2.09, 0.904, 0.42, 6, 20, CN.glass1);
      c.faceX(2.44, 0.905, 0.04, 7, 18, C.pink);
      c.p.pixel(...c.at(2.4, 0.906, 16), C.lamp);
      for (const z of [45, 68])
        for (let i = 0; i < 3; i++) {
          const x = 0.23 + i * 0.88;
          c.faceX(
            x,
            0.903,
            0.54,
            z,
            13,
            i === 1 && z === 45 ? CN.glass0 : CN.warm,
          );
          c.faceX(
            x + 0.04,
            0.904,
            0.46,
            z + 9,
            3,
            i === 1 ? CN.glass3 : CN.amber,
          );
          c.edge([x, 0.905, z - 2], [x + 0.54, 0.905, z - 2], CN.glass5);
          c.edge([x + 0.26, 0.905, z], [x + 0.26, 0.905, z + 13], CN.glass2);
        }
      neonPanelFront(c, 0.07, 0.91, 2.82, 31, 8, true);
      neonPanelFront(c, 2.7, 0.912, 0.27, 49, 38, false);
      c.edge([0.03, 0.914, 92], [2.97, 0.914, 92], C.pink);
      c.box(
        0.08,
        0.07,
        0.72,
        0.55,
        9,
        {
          top: CN.glass5,
          front: CN.glass3,
          side: CN.glass1,
          edge: CN.glass0,
        },
        94,
      );
      for (let i = 0; i < 5; i++)
        c.faceX(0.14 + i * 0.12, 0.622, 0.04, 96, 4, CN.glass0);
      for (const z of [11, 42, 64, 88])
        c.edge([2.99, 0.05, z], [2.99, 0.85, z], CN.glass4);
    },
  },
  'm-tram-stop': {
    footprint: [3, 1],
    h: 62,
    pad: 16,
    side: true,
    detail: { grain: 0, rim: false },
    draw(c) {
      lightPool(c, 1.4, 1.15, 46, 10, 0.9, CN.hot, CN.amber);
      // Thin iron canopy, glass weather screen, bench and illuminated board.
      c.box(
        0,
        0,
        3,
        0.88,
        3,
        { top: CN.glass5, front: CN.glass2, side: CN.glass0 },
        49,
      );
      c.edge([0, 0.89, 50], [3, 0.89, 50], CN.amber);
      for (const x of [0.12, 2.86]) {
        c.box(x, 0.12, 0.08, 0.7, 49, {
          top: CN.glass4,
          front: CN.glass0,
          side: C.ink,
        });
        c.edge([x, 0.83, 0], [x, 0.83, 48], CN.glass5);
      }
      c.faceX(0.23, 0.16, 2.48, 7, 36, CN.glass3);
      for (const x of [0.3, 1.13, 1.96]) {
        c.faceX(x, 0.161, 0.65, 9, 31, CN.glass4);
        c.edge([x + 0.02, 0.163, 13], [x + 0.4, 0.163, 36], CN.glass6);
      }
      c.box(
        0.35,
        0.32,
        1.8,
        0.28,
        3,
        { top: C.wood, front: C.woodDark, side: CN.glass0 },
        13,
      );
      for (const x of [0.48, 1.88]) c.box(x, 0.35, 0.06, 0.2, 13, M.dark);
      neonPanelFront(c, 2.24, 0.84, 0.5, 13, 29, false);
      c.faceX(0.24, 0.9, 1.8, 43, 5, CN.glass0);
      for (let i = 0; i < 8; i++)
        c.faceX(0.34 + i * 0.2, 0.901, 0.1, 45, 1, CN.amber);
    },
  },
  'm-tower-tall': {
    footprint: [3, 3],
    h: 336,
    draw(c) {
      const top = nightTower(c, 0.25, 2.5, 272, 11);
      // Stepped crown with glowing bands, then a lit spire.
      c.box(
        0.55,
        0.55,
        1.9,
        1.9,
        16,
        {
          top: CN.glass4,
          front: CN.glass3,
          side: CN.glass1,
          edge: CN.glass0,
        },
        top,
      );
      for (const z of [top + 4, top + 9, top + 14]) {
        c.faceX(0.55, 2.451, 1.9, z, 1, CN.hot);
        c.faceY(2.451, 0.55, 1.9, z, 1, CN.warmSide);
      }
      c.box(
        0.95,
        0.95,
        1.1,
        1.1,
        14,
        {
          top: CN.glass5,
          front: CN.glass4,
          side: CN.glass2,
          edge: CN.glass0,
        },
        top + 16,
      );
      c.faceX(0.95, 2.051, 1.1, top + 22, 3, CN.cool);
      c.faceY(2.051, 0.95, 1.1, top + 22, 3, CN.coolSide);
      const [sx, sy] = c.at(1.5, 1.5, top + 30);
      c.p.rect(sx - 1, sy - 26, 3, 26, C.silver);
      c.p.rect(sx + 1, sy - 26, 1, 26, C.steelDark);
      c.p.rect(sx, sy - 34, 1, 8, C.silver);
      aircraftLight(c, 1.5, 1.5, top + 64);
      aircraftLight(c, 0.6, 0.6, top + 17);
      aircraftLight(c, 2.4, 2.4, top + 17);
    },
  },
  'm-tower-slim': {
    footprint: [2, 2],
    h: 262,
    draw(c) {
      const top = nightTower(c, 0.2, 1.6, 206, 23, 2);
      // A lantern crown: a cool-lit glass box under a thin cap, then a mast.
      c.box(
        0.35,
        0.35,
        1.3,
        1.3,
        18,
        {
          top: CN.glass5,
          front: CN.glass3,
          side: CN.glass1,
          edge: CN.glass0,
        },
        top,
      );
      for (let u = 0.42; u < 1.6; u += 0.18) {
        c.faceX(u, 1.651, 0.1, top + 3, 12, CN.cool);
        c.faceY(1.651, u, 0.1, top + 3, 12, CN.coolSide);
      }
      c.box(
        0.3,
        0.3,
        1.4,
        1.4,
        2,
        {
          top: C.slate,
          front: C.charcoal,
          side: C.ink,
          edge: C.ink,
        },
        top + 18,
      );
      c.edge([0.3, 1.7, top + 20], [1.7, 1.7, top + 20], CN.glass6);
      const [mx, my] = c.at(1, 1, top + 20);
      c.p.rect(mx, my - 18, 1, 18, C.silver);
      aircraftLight(c, 1, 1, top + 39);
    },
  },
  'm-tower-slim-b': {
    footprint: [2, 2],
    h: 228,
    draw(c) {
      const top = nightTower(c, 0.2, 1.6, 180, 41, 2);
      // A stepped crown ringed with warm light, rooftop plant and a mast.
      c.box(
        0.4,
        0.4,
        1.2,
        1.2,
        12,
        {
          top: CN.glass4,
          front: CN.glass3,
          side: CN.glass1,
          edge: CN.glass0,
        },
        top,
      );
      for (const z of [top + 3, top + 8]) {
        c.faceX(0.4, 1.601, 1.2, z, 1, CN.hot);
        c.faceY(1.601, 0.4, 1.2, z, 1, CN.warmSide);
      }
      c.box(0.75, 0.75, 0.5, 0.5, 6, M.steel, top + 12);
      c.faceY(1.251, 0.85, 0.2, top + 12, 4, CN.warm);
      const [mx, my] = c.at(1, 1, top + 18);
      c.p.rect(mx, my - 12, 1, 12, C.silver);
      aircraftLight(c, 1, 1, top + 31);
      aircraftLight(c, 0.4, 1.6, top + 13);
    },
  },
  'm-broadcast-tower': {
    footprint: [2, 2],
    h: 262,
    pad: 12,
    draw(c) {
      // Podium with a glowing entrance hall.
      c.box(0.1, 0.1, 1.8, 1.8, 12, M.concrete);
      c.faceX(0.35, 1.901, 1.3, 2, 8, CN.hot);
      c.faceX(0.35, 1.902, 1.3, 8, 2, CN.amber);
      for (let u = 0.35; u < 1.7; u += 0.32)
        c.faceX(u, 1.903, 0.04, 2, 8, C.charcoal);
      c.faceY(1.901, 0.4, 1.2, 2, 8, CN.amberSide);
      // Tapering shaft in sections, with a strip of warm lights up the lit side.
      const ramp: Ramp = [CN.conc0, CN.conc1, CN.conc2];
      const sections: [number, number, number][] = [
        [12, 7, 40],
        [52, 6, 40],
        [92, 5, 40],
        [132, 4.5, 20],
      ];
      for (const [z, rx, h] of sections) c.cylinder(1, 1, z, rx, h, ramp);
      const [bx, by] = c.at(1, 1, 0);
      for (let z = 16; z < 150; z += 4) c.p.pixel(bx - 3, by - z, CN.hot);
      for (let z = 18; z < 150; z += 8) c.p.pixel(bx + 3, by - z, CN.warmSide);
      // Main observation pod: dark band, a ring of lit windows, a glowing rim.
      c.cylinder(1, 1, 150, 18, 4, [CN.conc1, CN.conc2, CN.conc3]);
      c.cylinder(1, 1, 154, 17, 9, [CN.glass4, CN.glass3, CN.glass1]);
      const [pcx, pcy] = c.at(1, 1, 158);
      for (let a = 0; a < Math.PI; a += 0.09) {
        const wx = pcx + Math.cos(a) * 16,
          wy = pcy + Math.sin(a) * 8;
        const k = Math.floor(a / 0.09);
        c.p.rect(
          wx,
          wy - 2,
          1,
          3,
          k % 5 === 4 ? CN.glass2 : k % 3 ? CN.warm : CN.hot,
        );
      }
      c.cylinder(1, 1, 163, 18, 3, [CN.conc0, CN.conc1, CN.conc2]);
      const [rx0, ry0] = c.at(1, 1, 166);
      for (let a = 0; a < Math.PI; a += 0.12)
        c.p.pixel(rx0 + Math.cos(a) * 17, ry0 + Math.sin(a) * 8.5, CN.hot);
      c.cylinder(1, 1, 166, 11, 10, ramp, CN.conc0);
      // Upper shaft and a smaller pod.
      c.cylinder(1, 1, 176, 3.5, 30, ramp);
      c.cylinder(1, 1, 206, 8, 7, [CN.glass4, CN.glass3, CN.glass1]);
      const [ucx, ucy] = c.at(1, 1, 209);
      for (let a = 0.2; a < Math.PI - 0.2; a += 0.22)
        c.p.pixel(ucx + Math.cos(a) * 7, ucy + Math.sin(a) * 3.5, CN.cool);
      c.cylinder(1, 1, 213, 8.5, 2, [CN.conc0, CN.conc1, CN.conc2]);
      // Antenna mast with white and red bands and aircraft lights.
      const [mx, my] = c.at(1, 1, 215);
      for (let z = 0; z < 44; z++)
        c.p.rect(
          mx - (z < 20 ? 1 : 0),
          my - z,
          z < 20 ? 3 : 2,
          1,
          Math.floor(z / 6) % 2 ? C.redDark : C.offwhite,
        );
      c.p.rect(mx, my - 52, 1, 8, C.silver);
      aircraftLight(c, 1, 1, 236);
      aircraftLight(c, 1, 1, 268);
      aircraftLight(c, 1, 1, 169);
    },
  },
  // Poles stand 6 tiles apart along a kerb; -start and -end close a run.
  'm-utility-pole': utilityPole([1, -1]),
  'm-utility-pole-start': utilityPole([1]),
  'm-utility-pole-end': utilityPole([-1]),
  'm-street-cherry': {
    footprint: [1, 1],
    h: 86,
    pad: 18,
    draw(c) {
      const [bx, by] = c.at(0.5, 0.5, 0);
      // Petals already fallen on the pavement around the tree pit.
      for (let k = 0; k < 46; k++) {
        const a = cityHash(k, 1) * Math.PI * 2,
          r = 4 + cityHash(k, 2) * 22;
        c.p.pixel(
          bx + Math.cos(a) * r,
          by + Math.sin(a) * r * 0.5,
          k % 3 ? CN.petal1 : CN.petal0,
        );
      }
      c.top(0.32, 0.32, 0.36, 0.36, 0, C.soil);
      // Trunk and branches spreading wide into the canopy.
      c.thick([bx, by], [bx + 1, by - 24], 1.6, CN.bark);
      c.thick([bx - 1, by - 2], [bx, by - 22], 0.6, CN.barkLight);
      const branches: [number, number, number, number][] = [
        [1, -24, -16, -40],
        [1, -24, 17, -38],
        [1, -28, 3, -52],
        [-8, -32, -26, -42],
        [10, -31, 27, -40],
        [-14, -38, -12, -54],
        [13, -36, 12, -52],
      ];
      for (const [x0, y0, x1, y1] of branches)
        c.thick([bx + x0, by + y0], [bx + x1, by + y1], 0.8, CN.bark);
      // Blossom: a broad, airy crown of soft clusters, lit from the upper
      // left, deep pink in the shade underneath.
      const clusters: [number, number, number][] = [
        [-24, -42, 8],
        [25, -41, 8],
        [-14, -36, 8],
        [14, -35, 8],
        [-17, -50, 10],
        [17, -49, 10],
        [0, -44, 11],
        [-6, -58, 10],
        [8, -57, 10],
        [0, -64, 7],
      ];
      for (const [dx, dy, r] of clusters) {
        c.p.ellipse(bx + dx + 1, by + dy + 2, r, r * 0.74, CN.petal3);
        c.p.ellipse(bx + dx, by + dy, r * 0.95, r * 0.7, CN.petal2);
      }
      for (const [dx, dy, r] of clusters) {
        c.p.ellipse(
          bx + dx - r * 0.16,
          by + dy - r * 0.18,
          r * 0.72,
          r * 0.5,
          CN.petal1,
        );
        c.p.ellipse(
          bx + dx - r * 0.34,
          by + dy - r * 0.34,
          r * 0.36,
          r * 0.24,
          CN.petal0,
        );
      }
      // Loose petals break up the outline; texture inside the crown.
      for (let k = 0; k < 140; k++) {
        const [dx, dy, r] = clusters[k % clusters.length],
          a = cityHash(k, 7) * Math.PI * 2,
          d = r * (0.9 + cityHash(k, 8) * 0.3),
          x = Math.round(bx + dx + Math.cos(a) * d),
          y = Math.round(by + dy + Math.sin(a) * d * 0.72);
        c.p.pixel(x, y, Math.sin(a) > 0.3 ? CN.petal2 : CN.petal1);
      }
      for (let k = 0; k < 110; k++) {
        const x = bx - 32 + Math.floor(cityHash(k, 5) * 64),
          y = by - 72 + Math.floor(cityHash(k, 6) * 44),
          i = (y * c.p.width + x) * 4;
        if (!c.p.data[i + 3]) continue;
        c.p.pixel(
          x,
          y,
          k % 4 === 0 ? CN.petal3 : k % 3 ? CN.petal0 : CN.petal2,
        );
      }
      // Dark twigs showing through gaps in the blossom.
      for (const [x0, y0, x1, y1] of [
        [-11, -44, -15, -49],
        [12, -43, 16, -47],
        [2, -55, 1, -60],
        [-20, -40, -23, -44],
        [21, -39, 24, -42],
      ])
        c.line([bx + x0, by + y0], [bx + x1, by + y1], CN.bark);
      // Petals drifting down.
      for (const [dx, dy] of [
        [-25, -28],
        [20, -22],
        [-12, -16],
        [27, -34],
        [6, -12],
      ])
        c.p.pixel(bx + dx, by + dy, CN.petal0);
    },
  },
  'm-vending': {
    footprint: [1, 1],
    h: 46,
    pad: 10,
    side: true,
    draw(c) {
      // Light spilling onto the pavement in front.
      lightPool(c, 0.55, 1.15, 20, 7, 0.6);
      const machine = (x: number, body: Material, panel: string) => {
        c.box(x, 0.3, 0.42, 0.5, 40, body);
        // Glowing display window with rows of plain coloured bottles.
        c.faceX(x + 0.04, 0.801, 0.34, 18, 19, panel);
        for (let row = 0; row < 3; row++)
          for (let k = 0; k < 5; k++) {
            const col =
              accents[(k * 3 + row * 2 + (x > 0.5 ? 1 : 0)) % accents.length];
            c.faceX(x + 0.06 + k * 0.064, 0.802, 0.04, 21 + row * 6, 3, col);
          }
        c.faceX(x + 0.04, 0.802, 0.34, 36, 1, C.white);
        // Button strip and the dispenser slot.
        c.faceX(x + 0.06, 0.802, 0.3, 14, 2, C.charcoal);
        for (let k = 0; k < 5; k++)
          c.faceX(x + 0.08 + k * 0.06, 0.803, 0.02, 14, 1, CN.cool);
        c.faceX(x + 0.08, 0.802, 0.26, 4, 6, C.ink);
        c.faceX(x + 0.1, 0.803, 0.22, 5, 1, C.charcoal);
      };
      machine(
        0.04,
        {
          top: C.red,
          front: C.redDark,
          side: C.carpet,
          edge: C.carpetDark,
        },
        CN.hot,
      );
      machine(
        0.52,
        {
          top: C.white,
          front: C.offwhite,
          side: C.pale,
          edge: C.silver,
        },
        C.lamp,
      );
      // A small recycling bin beside them.
      c.cylinder(1.02, 0.6, 0, 2.5, 9, [C.blue, C.blueDark, C.navy]);
    },
  },
  // Two-storey shop houses with awnings, in three colourways.
  'm-awning-shop': awningShop({
    wall: {
      top: C.warmGreyLight,
      front: C.creamShade,
      side: C.warmGrey,
      edge: C.warmGreyDark,
    },
    trim: C.warmGreyDark,
    awning: [C.teal, C.tealDark, C.deepTeal],
    sign: [C.redDark, C.red],
    lit: [true, false],
  }),
  'm-awning-shop-b': awningShop({
    wall: {
      top: C.offwhite,
      front: C.stone,
      side: C.stoneShade,
      edge: C.stoneLine,
    },
    trim: C.stoneLine,
    awning: [C.white, C.red, C.redDark],
    sign: [C.stageNavy, C.blueDark],
    lit: [false, true],
  }),
  'm-awning-shop-c': awningShop({
    wall: {
      top: C.terracottaLight,
      front: C.terracotta,
      side: C.terracottaDark,
      edge: C.brickDark,
    },
    trim: C.terracottaDark,
    awning: [C.orange, C.orangeDark, C.terracottaDark],
    sign: [C.greenDark, C.green],
    lit: [true, true],
  }),
  'm-city-lamp': {
    footprint: [1, 1],
    h: 70,
    pad: 14,
    shadow: false,
    draw(c) {
      // A warm pool of light on the pavement.
      const [gx, gy] = c.at(0.5, 0.5, 0);
      lightPool(c, 0.5, 0.5, 26, 13, 0.9);
      // Dark cast-iron post with a curved arm and a glowing lantern.
      c.p.rect(gx - 1, gy - 60, 3, 60, C.ink);
      c.p.rect(gx - 1, gy - 60, 1, 60, C.charcoal);
      c.p.rect(gx - 3, gy - 6, 7, 6, C.charcoal);
      c.p.rect(gx - 2, gy - 7, 5, 1, C.slate);
      c.line([gx, gy - 60], [gx + 6, gy - 64], C.ink);
      c.line([gx + 6, gy - 64], [gx + 10, gy - 61], C.ink);
      c.p.rect(gx + 7, gy - 61, 7, 2, C.ink);
      c.p.rect(gx + 8, gy - 59, 5, 4, C.lamp);
      c.p.rect(gx + 9, gy - 59, 3, 3, C.white);
      c.p.rect(gx + 7, gy - 55, 7, 1, CN.hot);
    },
  },
};
Object.assign(objects, city);

/** Target only the urban pass when refreshing city art; never regenerate people. */
export const NIGHT_CITY_ART_IDS = [
  'm-skyscraper-deco',
  'm-skyscraper-glass',
  'm-brownstone',
  'm-bodega',
  'm-tower-tall',
  'm-tower-slim',
  'm-tower-slim-b',
  'm-broadcast-tower',
  'm-neon-shop',
  'm-tram-stop',
  'm-city-lamp',
  'm-utility-pole',
  'm-utility-pole-start',
  'm-utility-pole-end',
] as const;
for (const id of NIGHT_CITY_ART_IDS)
  objects[id].detail = { ...objects[id].detail, grain: 0, rim: false };

export const MODERN_OBJECTS: Record<
  string,
  { footprint: [number, number]; floor?: boolean; side?: boolean }
> = Object.fromEntries(
  Object.entries(objects).map(([id, s]) => [
    id,
    {
      footprint: s.footprint,
      ...(s.floor ? { floor: true } : {}),
      ...(s.side ? { side: true } : {}),
    },
  ]),
);

/** Trim transparent margins; the left edge and width stay on 16 px tile columns. */
function trim(frames: PixelImage[], ax: number, ay: number) {
  const { width, height } = frames[0];
  let x0 = width,
    y0 = height,
    x1 = 0,
    y1 = 0;
  for (const f of frames)
    for (let y = 0; y < height; y++)
      for (let x = 0; x < width; x++)
        if (f.data[(y * width + x) * 4 + 3]) {
          x0 = Math.min(x0, x);
          y0 = Math.min(y0, y);
          x1 = Math.max(x1, x + 1);
          y1 = Math.max(y1, y + 1);
        }
  const left = Math.floor(x0 / 16) * 16;
  const w = Math.ceil((x1 - left) / 16) * 16;
  const top = Math.max(0, Math.min(y0, ay - 1)),
    h = Math.max(y1, ay + 1) - top;
  const out = frames.map((f) => {
    const p = new Pixels(w, h);
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const sx = x + left,
          sy = y + top;
        if (sx < 0 || sy < 0 || sx >= width || sy >= height) continue;
        const i = (sy * width + sx) * 4;
        p.data.set(f.data.slice(i, i + 4), (y * w + x) * 4);
      }
    return p;
  });
  return { frames: out, anchor: [ax - left, ay - top] as [number, number] };
}

export function renderModernObject(id: string) {
  const s = objects[id];
  if (!s) throw Error(`Unknown modern object ${id}`);
  const [w, d] = s.footprint,
    pad = (s.pad ?? 6) + 16;
  const ax = Math.ceil((d * 16 + pad) / 16) * 16,
    ay = s.h + pad,
    width = Math.ceil(((w + d) * 16 + pad * 2) / 16) * 16 + 16,
    height = ay + (w + d) * 8 + pad;
  const frames: PixelImage[] = [];
  for (let f = 0; f < (s.frames ?? 1); f++) {
    const c = isoCanvas(width, height, ax, ay);
    s.draw(c, f);
    for (let i = 3; i < c.p.data.length; i += 4)
      if (c.p.data[i]) c.p.data[i] = 255;
    // Floor796-style finishing: outlines, rim light, grain, contact shading.
    if (s.detail !== false)
      detailPass(
        c.p,
        s.floor
          ? {
              outline: false,
              rim: false,
              contact: false,
              grain: 0.006,
              ...s.detail,
            }
          : { ...s.detail },
      );
    if (!s.floor && s.shadow !== false) groundShadow(c, w, d);
    frames.push(c.p);
  }
  return trim(frames, ax, ay);
}

export async function generateModernObjects(ids?: readonly string[]) {
  const meta: Record<string, ObjectArt> = await readJson(
    'art/objects/index.json',
  ).catch(() => ({}));
  for (const id of ids ?? Object.keys(objects)) {
    if (!objects[id]) throw Error(`Unknown modern object ${id}`);
    const s = objects[id],
      { frames, anchor } = renderModernObject(id);
    for (const side of s.side ? [false, true] : [false]) {
      const name = side ? `${id}-side` : id;
      const images = side ? frames.map(mirror) : frames;
      const a: [number, number] = side
        ? [images[0].width - anchor[0], anchor[1]]
        : anchor;
      await png(`art/objects/${name}.png`, images[0]);
      const entry: ObjectArt = {
        file: `objects/${name}.png`,
        anchor: a,
        width: images[0].width,
        height: images[0].height,
        ...(s.floor ? { floor: true } : {}),
        ...(s.period ? { period: s.period } : {}),
      };
      if (images.length > 1) {
        entry.frames = [];
        for (const [i, im] of images.entries()) {
          await png(`art/objects/${name}-${i}.png`, im);
          entry.frames.push(`objects/${name}-${i}.png`);
        }
      }
      meta[name] = entry;
    }
  }
  await writeJson('art/objects/index.json', meta);
}

/*
 * Floor tiles (32×16 diamonds). Each pixel is mapped back to tile-local
 * coordinates (u, v) in [0, 1), so planks, grout, bricks and ripples follow the
 * tile axes. Upper edges catch the light, lower edges and grout sit in shade.
 */
const tileHash = (x: number, y: number, n: number) => {
  let h = Math.imul(x * 73856093 + y * 19349663 + n * 83492791, 2654435761);
  h ^= h >>> 15;
  return ((h >>> 0) % 1000) / 1000;
};
type TileTexture = (u: number, v: number, x: number, y: number) => string;
function texturedTile(n: number, tex: TileTexture) {
  const p = new Pixels(32, 16);
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 32; x++) {
      const px = x + 0.5,
        py = y + 0.5;
      const a = (px - 16) / 16,
        b = py / 8,
        u = (a + b) / 2,
        v = (b - a) / 2;
      if (u < 0 || v < 0 || u >= 1 || v >= 1) continue;
      p.pixel(x, y, tex(u, v, x, y));
    }
  void n;
  return p;
}
/**
 * Smooth value noise over the tile, periodic in u and v with period `k`
 * cells, so neighbouring tiles join without seams. Gives soft patches
 * (veining, wear, damp) instead of salt-and-pepper speckle.
 */
function tileNoise(u: number, v: number, k: number, seed: number, kv = k) {
  const fu = u * k,
    fv = v * kv,
    iu = Math.floor(fu),
    iv = Math.floor(fv),
    s = (t: number) => t * t * (3 - 2 * t),
    tu = s(fu - iu),
    tv = s(fv - iv),
    g = (a: number, b: number) =>
      tileHash(((a % k) + k) % k, ((b % kv) + kv) % kv, seed);
  const top = g(iu, iv) * (1 - tu) + g(iu + 1, iv) * tu,
    bottom = g(iu, iv + 1) * (1 - tu) + g(iu + 1, iv + 1) * tu;
  return top * (1 - tv) + bottom * tv;
}
/**
 * Stone/ceramic slab: dark grout on the lower edges, a lit bevel on the upper
 * ones, soft tonal patches inside and only a rare chip.
 */
function slab(
  base: string,
  n: number,
  divisions = 1,
  chips = 0.012,
  mottle?: string,
  patch = 0.66,
): TileTexture {
  const grout = darker(base),
    bevel = lighter(base),
    shade = darker(base);
  return (u, v, x, y) => {
    const su = (u * divisions) % 1,
      sv = (v * divisions) % 1,
      cell = Math.floor(u * divisions) * 7 + Math.floor(v * divisions);
    if (su > 0.94 || sv > 0.94) return grout;
    if (su < 0.06 || sv < 0.06) return bevel;
    // Each slab gets its own patch pattern.
    if (mottle && tileNoise(u, v, 4, n * 13 + cell) > patch) return mottle;
    if (tileHash(x, y, n) < chips) return shade;
    return base;
  };
}
/** Hand-set courtyard cobbles: staggered sizes, chipped bevels and moss in the joints. */
function villageCobbles(n: number): TileTexture {
  return (u, v, x, y) => {
    const row = Math.floor(v * 3),
      rv = v * 3 - row;
    const along = u * 2 + (row % 2) * 0.5;
    const cell = Math.floor(along),
      ru = along - cell;
    const seed = tileHash(cell % 2, row, n);
    const wobble = tileHash(cell, row + 7, n) * 0.045;
    if (rv < 0.08 + wobble || ru < 0.06 + wobble)
      return tileNoise(u, v, 4, n + 54) > 0.69 ? NC.moss2 : C.sandDark;
    if (rv < 0.2 || ru < 0.15) return C.creamShade;
    if (rv > 0.91 || ru > 0.91) return C.clay;
    if (tileHash(x, y, n) < 0.025) return C.sandShade;
    return seed < 0.25 ? C.warmGreyLight : seed > 0.75 ? C.sandShade : C.sand;
  };
}
export function renderModernTile(n: number) {
  switch (n) {
    // 1–3: courtyard stone in three warm variants, 6: pale stone paving.
    case 1:
      return texturedTile(n, villageCobbles(n));
    case 2:
      return texturedTile(n, villageCobbles(n));
    case 3:
      return texturedTile(n, villageCobbles(n));
    case 6:
      return texturedTile(n, villageCobbles(n));
    case 4: {
      // Rich meadow greens with grouped blades and broad patches of clover.
      return texturedTile(n, (u, v, x, y) => {
        const blade = (yy: number) => tileHash(x, yy, n) < 0.055;
        if (blade(y)) return NC.leaf3;
        if (blade(y + 1)) return NC.leaf1;
        if (blade(y + 2) && tileHash(x, y, n + 5) < 0.5) return NC.leaf0;
        const patch = tileNoise(u, v, 3, 41);
        return patch > 0.74 ? NC.leaf1 : patch < 0.32 ? NC.leaf3 : NC.leaf2;
      });
    }
    case 5: {
      // Water: wavy ripple bands bent by noise, sparse bright glints.
      return texturedTile(n, (u, v, x, y) => {
        const bend = tileNoise(u, v, 2, 57) * 0.5,
          w = (u * 2 + v + bend) % 1,
          deep = tileNoise(u, v, 2, 61);
        if (w < 0.04) return C.waterLight;
        if (w < 0.1) return C.water;
        if (tileHash(x, y, n) < 0.01) return C.white;
        return deep > 0.74 && w > 0.5 ? C.deepTeal : C.turquoise;
      });
    }
    case 7:
      return texturedTile(n, villageCobbles(n));
    case 14:
      // Baitul Mukarram's white marble plaza: large slabs, thin dark grout,
      // soft grey veining.
      return texturedTile(n, (u, v, x, y) => {
        if (u > 0.965 || v > 0.965) return C.grey;
        if (u < 0.03 || v < 0.03) return C.white;
        const vein = tileNoise(u, v, 3, 141);
        if (vein > 0.78 && tileHash(x, y, n) < 0.5) return C.pale;
        if (vein < 0.12) return C.offwhite;
        return tileHash(x, y, n + 3) < 0.004 ? C.silver : C.white;
      });
    case 15:
      // Packed-earth school yard: dusty patches, pebbles and scuffs.
      return texturedTile(n, (u, v, x, y) => {
        const patch = tileNoise(u, v, 3, 151);
        if (tileHash(x, y, n) < 0.02) return C.sandDark;
        if (tileHash(x, y, n + 9) < 0.015) return C.clay;
        return patch > 0.66 ? C.sandShade : patch < 0.2 ? C.paper : C.sand;
      });
    case 8:
      return texturedTile(n, villageCobbles(n));
    case 9: {
      // Oak boards running along u, three per tile: long grain streaks,
      // staggered board ends, a lit upper edge and a dark seam.
      const grain = darker(C.oak),
        seam = darker(C.wood);
      return texturedTile(n, (u, v) => {
        const band = Math.floor(v * 3),
          bv = (v * 3) % 1,
          end = (u + band * 0.37) % 1;
        if (bv > 0.86 || end > 0.96) return seam;
        if (bv < 0.14) return C.woodLight;
        // Stretched noise: streaks run along the board.
        const streak = tileNoise(u, v, 2, 90 + band, 12);
        if (streak > 0.7) return grain;
        if (streak < 0.18) return C.woodLight;
        return C.oak;
      });
    }
    case 10:
      // White lab ceramic, four tiles with crisp grout.
      return texturedTile(n, slab(C.labTile, n, 2, 0));
    case 11: {
      // Clinic vinyl: welded seams and a soft cloudy pattern.
      return texturedTile(n, (u, v, x, y) => {
        if (u > 0.95 || v > 0.95) return C.vinylDark;
        const cloud = tileNoise(u, v, 4, 71);
        if (cloud > 0.7) return C.vinylLight;
        if (tileHash(x, y, n) < 0.015) return C.vinylDark;
        return C.vinyl;
      });
    }
    case 12: {
      // Asphalt: worn patches, sparse grit, a hairline crack.
      return texturedTile(n, (u, v, x, y) => {
        const h = tileHash(x, y, n),
          wear = tileNoise(u, v, 4, 83);
        if (Math.abs(u - 0.55 - v * 0.2) < 0.02 && v > 0.3 && v < 0.7)
          return C.asphaltDark;
        if (h < 0.035) return C.asphaltDark;
        if (h > 0.97 || (wear > 0.76 && h > 0.4)) return C.asphaltLight;
        return C.asphalt;
      });
    }
    case 13: {
      // Terracotta brick paving in running bond, each brick a touch different.
      return texturedTile(n, (u, v) => {
        const row = Math.floor(v * 4),
          rv = (v * 4) % 1,
          bu = u * 2 + (row % 2) * 0.5,
          ru = bu % 1,
          brick = tileHash(Math.floor(bu) % 2, row, n);
        if (rv > 0.8 || ru > 0.9) return C.terracottaDark;
        if (rv < 0.18 || ru < 0.06) return C.terracottaLight;
        return brick > 0.82 ? darker(C.terracotta) : C.terracotta;
      });
    }
    default:
      throw Error(`No tile ${n}`);
  }
}
export async function generateModernTiles(
  ids: readonly number[] = Array.from({ length: 15 }, (_, i) => i + 1),
) {
  for (const n of ids)
    await png(`art/tiles/tile-${n}.png`, renderModernTile(n));
}
