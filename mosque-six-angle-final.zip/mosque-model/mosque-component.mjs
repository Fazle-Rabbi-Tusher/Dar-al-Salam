export class MosqueModel extends HTMLElement {
  connectedCallback() {
    if (this.frame) return;
    this.frame = document.createElement('iframe');
    this.frame.title = 'Interactive 3D mosque model';
    this.ready = new Promise((resolve) => {
      const listen = (e) => {
        if (e.source === this.frame.contentWindow && e.data?.mosqueReady) {
          window.removeEventListener('message', listen);
          resolve();
        }
      };
      window.addEventListener('message', listen);
    });
    this.frame.src = new URL('./index.html', import.meta.url).href;
    this.frame.style.cssText = 'width:100%;height:820px;border:0';
    this.append(this.frame);
  }
  shot(name) {
    this.ready.then(() =>
      this.frame.contentWindow.postMessage(
        { mosque: true, shot: name },
        new URL(this.frame.src).origin,
      ),
    );
  }
  rotate(degrees) {
    this.ready.then(() =>
      this.frame.contentWindow.postMessage(
        { mosque: true, orbit: degrees },
        new URL(this.frame.src).origin,
      ),
    );
  }
}
if (!customElements.get('mosque-model'))
  customElements.define('mosque-model', MosqueModel);
