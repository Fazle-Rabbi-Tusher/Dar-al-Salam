import * as T from './vendor/three.module.min.js';
const V = (a) => new T.Vector3(...a),
  up = new T.Vector3(0, 1, 0),
  I = new T.Quaternion();
export const MODEL_SPEC = {
  width: 16,
  length: 22,
  height: 8.2,
  imam: [0, 0, -7],
  men: 18,
  women: 12,
  screenZ: 3.8,
  status: 'DRAFT — AWAITING REVIEW',
  panelApproved: false,
  needsPanelReview: true,
};
function archPoints(w, h) {
  const p = [
    [-w / 2, 0],
    [w / 2, 0],
    [w / 2, h * 0.6],
  ];
  for (let i = 1; i <= 16; i++) {
    const t = i / 16;
    p.push([(w / 2) * (1 - t * t), h * 0.6 + h * 0.4 * t]);
  }
  for (let i = 1; i <= 16; i++) {
    const t = i / 16;
    p.push([(-w / 2) * (2 * t - t * t), h * (1 - 0.4 * t)]);
  }
  p.push([-w / 2, 0]);
  return p.map(([x, y]) => new T.Vector2(x, y));
}
function archGeometry(w, h, thickness, depth) {
  const points =
    thickness > 0
      ? archPoints(w, h)
          .slice(1)
          .concat(
            archPoints(w - 2 * thickness, h - thickness * 1.5)
              .slice(1)
              .reverse(),
          )
      : archPoints(w, h);
  const shape = new T.Shape(points);
  return new T.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: false,
    curveSegments: 16,
  });
}
function starGeometry(radius, inner, depth = 0) {
  const p = [];
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI) / 8,
      r = i % 2 ? inner : radius;
    p.push(new T.Vector2(Math.cos(a) * r, Math.sin(a) * r));
  }
  const shape = new T.Shape(p);
  return depth
    ? new T.ExtrudeGeometry(shape, { depth, bevelEnabled: false })
    : new T.ShapeGeometry(shape);
}
export async function createMosque() {
  const root = new T.Group();
  root.name = 'Mosque';
  root.userData = MODEL_SPEC;
  const groups = {},
    queues = new Map(),
    mats = {},
    geoms = {
      box: new T.BoxGeometry(1, 1, 1),
      c6: new T.CylinderGeometry(1, 1, 1, 6),
      c8: new T.CylinderGeometry(1, 1, 1, 8),
      sphere: new T.IcosahedronGeometry(1, 1),
      star: starGeometry(0.28, 0.13),
      smallStar: starGeometry(0.12, 0.065),
      diamond: new T.PlaneGeometry(1, 1),
    };
  const group = (name) => {
    if (!groups[name]) {
      groups[name] = new T.Group();
      groups[name].name = name;
      root.add(groups[name]);
    }
    return groups[name];
  };
  const material = (name, color, extra = {}) =>
    mats[name] ??
    (mats[name] = new T.MeshStandardMaterial({
      name,
      color,
      roughness: 0.85,
      ...extra,
    }));
  material('limestone', '#e7d5b7');
  material('sandstone', '#bda480');
  material('brass', '#bf9045', { metalness: 0.35, roughness: 0.32 });
  material('gold', '#dfbc72', { metalness: 0.5, roughness: 0.4 });
  material('walnut', '#543424');
  material('teal', '#164e56');
  material('tealBorder', '#143e46');
  material('cream', '#d3c69c');
  material('leaf', '#256942');
  material('bark', '#51412b');
  material('amber', '#dca34d', {
    emissive: '#ffad3e',
    emissiveIntensity: 0.75,
    roughness: 0.3,
  });
  material('glass', '#78b5ac', {
    transparent: true,
    opacity: 0.18,
    roughness: 0.25,
    metalness: 0.05,
    side: T.DoubleSide,
  });
  const loader = new T.TextureLoader();
  const texture = async (name, rx = 1, ry = 1) => {
    const t = await loader.loadAsync(
      new URL(`./assets/${name}.png`, import.meta.url).href,
    );
    t.colorSpace = T.SRGBColorSpace;
    t.magFilter = T.NearestFilter;
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.repeat.set(rx, ry);
    return t;
  };
  for (const name of [
    'yasser-face',
    'man-face',
    'elder-face',
    'woman-navy-face',
    'woman-cream-face',
  ])
    mats[name] = new T.MeshStandardMaterial({
      name,
      map: await texture(name),
      roughness: 0.9,
      side: T.FrontSide,
    });
  // Optional authored material tiles load without making the geometry depend on them.
  for (const [name, rx, ry] of [
    ['carpet', 8, 11],
    ['stone', 1, 1],
    ['wood', 1, 4],
    ['metal', 1, 1],
  ]) {
    try {
      const t = await texture(name, rx, ry);
      const target = {
        carpet: 'teal',
        stone: 'limestone',
        wood: 'walnut',
        metal: 'brass',
      }[name];
      mats[target].map = t;
      mats[target].color.set(target === 'teal' ? '#225c68' : '#ffffff');
    } catch {
      /* Plain material remains usable during asset authoring. */
    }
  }
  const add = (g, geo, pos, scale, mat, q = I, tint = null) => {
    const key = `${g}|${geo}|${mat}`;
    if (!queues.has(key)) queues.set(key, { g, geo, mat, items: [] });
    queues.get(key).items.push({ pos, scale, q: q.clone(), tint });
  };
  const box = (g, pos, scale, mat = 'limestone', q = I, tint = null) =>
    add(g, 'box', pos, scale, mat, q, tint);
  const beam = (g, a, b, width, depth, mat = 'limestone') => {
    const A = V(a),
      B = V(b),
      d = B.clone().sub(A);
    box(
      g,
      A.add(B).multiplyScalar(0.5).toArray(),
      [width, d.length(), depth],
      mat,
      new T.Quaternion().setFromUnitVectors(up, d.normalize()),
    );
  };
  const mesh = (g, geometry, pos, mat, q = I, scale = [1, 1, 1]) => {
    const key = 'custom' + Object.keys(geoms).length;
    geoms[key] = geometry;
    add(g, key, pos, scale, mat, q);
  };
  const cylinder = (g, p, r, h, mat = 'brass', segments = 8, q = I) =>
    add(g, segments === 6 ? 'c6' : 'c8', p, [r, h, r], mat, q);
  const star = (g, p, r, mat = 'gold') => {
    add(
      g,
      'star',
      p,
      [r / 0.28, r / 0.28, 1],
      mat,
      new T.Quaternion().setFromAxisAngle(new T.Vector3(1, 0, 0), -Math.PI / 2),
    );
  };
  const hash = (i) => {
    const n = Math.sin(i * 91.7 + 1.83) * 19273.17;
    return n - Math.floor(n);
  };
  // Floor, woven carpet, repeating rosettes and border filigree.
  box('Floor', [0, -0.16, 0], [16.8, 0.3, 22.8], 'sandstone');
  box('Floor', [0, 0.005, 0], [16, 0.018, 22], 'teal');
  for (const x of [-7.75, 7.75])
    box('Floor', [x, 0.02, 0], [0.12, 0.012, 21.6], 'gold');
  for (const z of [-10.75, 10.75])
    box('Floor', [0, 0.02, z], [15.6, 0.012, 0.12], 'gold');
  for (let x = -7.2; x <= 7.3; x += 1.2)
    for (let z = -10.2; z <= 10.3; z += 1.2) {
      star('Floor', [x, 0.026, z], 0.22, 'gold');
      star('Floor', [x, 0.027, z], 0.16, 'tealBorder');
      star('Floor', [x, 0.028, z], 0.075, 'cream');
      for (const s of [-1, 1])
        beam(
          'Floor',
          [x - 0.48, 0.025, z + s * 0.4],
          [x + 0.48, 0.025, z - s * 0.4],
          0.013,
          0.012,
          'cream',
        );
    }
  function rug(x, z) {
    box('Imam-rug', [x, 0.035, z], [1.35, 0.03, 2.55], 'gold');
    box('Imam-rug', [x, 0.054, z], [1.24, 0.012, 2.42], 'tealBorder');
    box('Imam-rug', [x, 0.063, z], [1.08, 0.008, 2.23], 'teal');
    for (const dz of [-0.65, 0, 0.65])
      star('Imam-rug', [x, 0.072, z + dz], 0.25);
    for (let i = -0.6; i <= 0.61; i += 0.045)
      for (const s of [-1, 1])
        box(
          'Imam-rug',
          [x + i, 0.048, z + s * 1.34],
          [0.018, 0.018, 0.15],
          'cream',
        );
  }
  rug(0, -7.3);
  // Perimeter block masonry, real arched window openings and inset garden views.
  for (const side of [-1, 1]) {
    const g = side < 0 ? 'West-wall' : 'East-wall';
    for (let row = 0; row < 22; row++)
      for (let j = 0; j < 44; j++) {
        const z = -10.75 + j * 0.5 + (row % 2) * 0.25,
          y = 0.18 + row * 0.36;
        const nearest = [-7.5, -2.5, 2.5, 7.5].reduce((a, b) =>
            Math.abs(z - a) < Math.abs(z - b) ? a : b,
          ),
          dx = Math.abs(z - nearest),
          wy = y - 1.3;
        const inWindow =
          wy >= 0 &&
          wy < 4.8 &&
          dx < 1.05 &&
          (wy < 3 || dx < 1.05 * Math.sqrt(Math.max(0, (4.8 - wy) / 1.8)));
        if (!inWindow)
          box(
            g,
            [side * 8, y, z],
            [0.32, 0.345, 0.485],
            'limestone',
            I,
            new T.Color().setHSL(0.1, 0.25, 0.78 + hash(row * 100 + j) * 0.08),
          );
      }
    for (const z of [-7.5, -2.5, 2.5, 7.5]) {
      const q = new T.Quaternion().setFromAxisAngle(up, Math.PI / 2);
      mesh(
        g,
        archGeometry(2.35, 5.15, 0.16, 0.22),
        [side * 7.84, 1.18, z],
        'sandstone',
        q,
      );
      mesh(
        g,
        archGeometry(2.05, 4.8, 0, 0.015),
        [side * 8.0, 1.3, z],
        'glass',
        q,
      );
      for (let dz = -0.8; dz <= 0.81; dz += 0.4)
        beam(
          g,
          [side * 7.77, 1.4, z + dz],
          [side * 7.77, 5.0, z + dz],
          0.035,
          0.035,
          'brass',
        );
      for (let yy = 1.7; yy < 5.2; yy += 0.4)
        beam(
          g,
          [side * 7.76, yy, z - 0.95],
          [side * 7.76, yy, z + 0.95],
          0.025,
          0.025,
          'brass',
        );
      // Outdoor leaves behind the glass are real faceted geometry.
      for (let j = 0; j < 14; j++)
        add(
          g,
          'sphere',
          [side * 9.5, 2 + hash(j + z) * 4, z + (hash(j * 3) - 0.5) * 2],
          [0.5, 0.7, 0.5],
          'leaf',
          I,
          new T.Color(j % 2 ? '#426d36' : '#769349'),
        );
    }
  }
  for (const [g, z] of [
    ['Qibla-wall', -11],
    ['Entrance-wall', 11],
  ]) {
    for (let row = 0; row < 22; row++)
      for (let j = 0; j < 32; j++) {
        const x = -7.75 + j * 0.5 + (row % 2) * 0.25,
          y = 0.18 + row * 0.36;
        if (
          Math.abs(x) < 1.6 &&
          y < 5.6 &&
          (y < 3.36 || Math.abs(x) < 1.6 * (1 - ((y - 3.36) / 2.24) ** 2))
        )
          continue;
        box(
          g,
          [x, y, z],
          [0.485, 0.345, 0.34],
          'limestone',
          I,
          new T.Color().setHSL(0.1, 0.25, 0.8 + hash(row * 32 + j) * 0.07),
        );
      }
    const isQ = g === 'Qibla-wall';
    mesh(
      g,
      archGeometry(3.5, 5.8, 0.25, 0.25),
      [0, 0.02, z + (isQ ? 0.18 : -0.3)],
      'sandstone',
    );
    mesh(
      g,
      archGeometry(3.0, 5.45, 0, 0.02),
      [0, 0.02, z + (isQ ? -0.12 : -0.1)],
      isQ ? 'gold' : 'walnut',
    );
    mesh(
      g,
      archGeometry(2.85, 5.25, 0, 0.025),
      [0, 0.02, z + (isQ ? 0.02 : -0.12)],
      isQ ? 'sandstone' : 'walnut',
    );
    if (isQ) {
      mesh(
        'Mihrab',
        archGeometry(3.02, 5.5, 0.06, 0.08),
        [0, 0.02, -10.76],
        'amber',
      );
      box('Mihrab', [0, 0.06, -10.7], [3.15, 0.12, 0.7], 'sandstone');
      const l = new T.PointLight('#ffcc83', 32, 7, 2);
      l.position.set(0, 2.8, -10);
      group('Lighting').add(l);
    }
  }
  // Classical faceted structural pillars and pointed arcade ribs.
  for (const x of [-5.7, 5.7])
    for (const z of [-7.5, -2.5, 2.5, 7.5]) {
      box('Colonnades', [x, 0.15, z], [1.0, 0.3, 1.0], 'sandstone');
      box('Colonnades', [x, 0.38, z], [0.8, 0.16, 0.8]);
      cylinder('Colonnades', [x, 2.65, z], 0.34, 4.5, 'limestone');
      for (let y = 0.65; y < 4.9; y += 0.32)
        cylinder('Colonnades', [x, y, z], 0.348, 0.024, 'sandstone');
      for (let k = 0; k < 4; k++)
        box(
          'Colonnades',
          [x, 4.93 + k * 0.12, z],
          [0.6 + k * 0.12, 0.12, 0.6 + k * 0.12],
        );
    }
  const archRib = archGeometry(10.8, 3.0, 0.22, 0.25);
  for (const z of [-7.5, -2.5, 2.5, 7.5])
    mesh('Vaults', archRib, [0, 4.95, z], 'limestone');
  for (const x of [-5.7, 5.7])
    for (const z of [-5, 0, 5])
      mesh(
        'Colonnades',
        archGeometry(4.45, 2.6, 0.2, 0.22),
        [x, 4.9, z],
        'limestone',
        new T.Quaternion().setFromAxisAngle(up, Math.PI / 2),
      );
  // Ornate coffered roof: named group can be removed for overhead exploration.
  for (let x = -6; x <= 6; x += 4)
    for (let z = -8; z <= 8; z += 4) {
      box('Ceiling', [x, 8.12, z], [3.96, 0.15, 3.96], 'limestone');
      for (const s of [-1, 1]) {
        box('Ceiling', [x + s * 1.85, 7.96, z], [0.16, 0.22, 3.9], 'walnut');
        box('Ceiling', [x, 7.96, z + s * 1.85], [3.9, 0.22, 0.16], 'walnut');
        box('Ceiling', [x + s * 1.65, 7.91, z], [0.045, 0.08, 3.4], 'gold');
        box('Ceiling', [x, 7.91, z + s * 1.65], [3.4, 0.08, 0.045], 'gold');
      }
      for (let k = 0; k < 8; k++) {
        const a = (k * Math.PI) / 4,
          b = a + Math.PI / 2;
        beam(
          'Ceiling',
          [x + Math.cos(a) * 1.45, 7.9, z + Math.sin(a) * 1.45],
          [x + Math.cos(b) * 1.45, 7.9, z + Math.sin(b) * 1.45],
          0.055,
          0.06,
          'walnut',
        );
      }
    }
  // Tiered hexagonal brass lanterns, emissive amber panes and dimensional lattice.
  function lantern(x, z, scale = 1, y = 5.5) {
    const g = 'Lanterns';
    beam(g, [x, y + 1.5 * scale, z], [x, 8, z], 0.035, 0.035, 'brass');
    for (const [radius, h, dy] of [
      [0.68, 1.0, 0],
      [0.48, 0.32, 0.7],
      [0.27, 0.24, 1.1],
    ]) {
      cylinder(
        g,
        [x, y + dy * scale, z],
        radius * scale,
        h * scale,
        'amber',
        6,
      );
      for (const sy of [-1, 1])
        cylinder(
          g,
          [x, y + (dy + (sy * h) / 2) * scale, z],
          (radius + 0.06) * scale,
          0.09 * scale,
          'brass',
          6,
        );
      for (let k = 0; k < 6; k++) {
        const a = (k * Math.PI) / 3,
          b = ((k + 1) * Math.PI) / 3,
          A = [
            x + Math.cos(a) * radius * scale,
            y + (dy - h / 2) * scale,
            z + Math.sin(a) * radius * scale,
          ],
          B = [
            x + Math.cos(a) * radius * scale,
            y + (dy + h / 2) * scale,
            z + Math.sin(a) * radius * scale,
          ];
        beam(g, A, B, 0.045 * scale, 0.045 * scale, 'brass');
        const M = [
          x + Math.cos(b) * radius * scale,
          y + (dy + h / 2) * scale,
          z + Math.sin(b) * radius * scale,
        ];
        const edge = new T.Vector3(M[0] - A[0], 0, M[2] - A[2]);
        for (let col = 1; col <= 3; col++)
          for (let row = -1; row <= 1; row++) {
            const f = col / 4,
              c = [
                A[0] + edge.x * f,
                y + (dy + row * h * 0.25) * scale,
                A[2] + edge.z * f,
              ];
            const v = [edge.x * 0.12, 0, edge.z * 0.12],
              hh = h * 0.13 * scale;
            for (const side of [-1, 1]) {
              beam(
                g,
                [c[0] - v[0], c[1], c[2] - v[2]],
                [c[0], c[1] + side * hh, c[2]],
                0.018 * scale,
                0.018 * scale,
                'brass',
              );
              beam(
                g,
                [c[0], c[1] + side * hh, c[2]],
                [c[0] + v[0], c[1], c[2] + v[2]],
                0.018 * scale,
                0.018 * scale,
                'brass',
              );
            }
          }
        beam(g, A, M, 0.028 * scale, 0.028 * scale, 'brass');
        beam(
          g,
          B,
          [M[0], y + (dy - h / 2) * scale, M[2]],
          0.028 * scale,
          0.028 * scale,
          'brass',
        );
      }
    }
    cylinder(
      g,
      [x, y - 0.68 * scale, z],
      0.28 * scale,
      0.22 * scale,
      'brass',
      6,
    );
    if (scale > 0.65) {
      const l = new T.PointLight('#ffc27d', 16 * scale, 11, 2);
      l.position.set(x, y - 0.4, z);
      group('Lighting').add(l);
    }
  }
  for (const z of [-6, 0, 6]) lantern(0, z, z === 0 ? 1.5 : 1.0, 5.7);
  for (const x of [-5.7, 5.7])
    for (const z of [-7.5, -2.5, 2.5, 7.5]) lantern(x, z, 0.4, 3.6);
  // Wall sconces.
  for (const side of [-1, 1])
    for (const z of [-10, -5, 0, 5, 10]) {
      const g = side < 0 ? 'West-wall' : 'East-wall';
      box(g, [side * 7.62, 3.0, z], [0.25, 0.75, 0.3], 'brass');
      box(g, [side * 7.43, 3.0, z], [0.22, 0.53, 0.22], 'amber');
    }
  // Privacy screen with eight-point walnut mashrabiya cells.
  for (const x of [-5.4, -2.7, 0, 2.7, 5.4]) {
    box('Partition', [x, 0.93, 3.8], [0.15, 1.86, 0.18], 'walnut');
    cylinder('Partition', [x, 1.91, 3.8], 0.15, 0.14, 'brass');
  }
  for (const y of [0.13, 0.38, 1.65])
    box('Partition', [0, y, 3.8], [10.9, 0.12, 0.15], 'walnut');
  for (let x = -5.25; x < 5.3; x += 0.35)
    for (let y = 0.6; y < 1.6; y += 0.35) {
      for (const s of [-1, 1])
        beam(
          'Partition',
          [x - 0.16, y - 0.16, 3.79],
          [x + 0.16, y + s * 0.16, 3.79],
          0.028,
          0.055,
          'walnut',
        );
      beam(
        'Partition',
        [x - 0.16, y + 0.16, 3.79],
        [x + 0.16, y - 0.16, 3.79],
        0.028,
        0.055,
        'gold',
      );
    }
  // Golden pots with voxel fern/palm fronds.
  function plant(x, z) {
    const g = 'Plants';
    cylinder(g, [x, 0.34, z], 0.45, 0.65, 'brass');
    cylinder(g, [x, 0.67, z], 0.48, 0.08, 'gold');
    cylinder(g, [x, 0.7, z], 0.38, 0.025, 'bark');
    beam(g, [x, 0.7, z], [x, 1.9, z], 0.06, 0.06, 'bark');
    for (let j = 0; j < 12; j++) {
      const a = (j * Math.PI) / 6,
        height = 1.2 + (j % 3) * 0.28;
      let prev = [x, 1.5, z];
      for (let k = 1; k <= 6; k++) {
        const f = k / 6,
          p = [
            x + Math.cos(a) * f * 0.9,
            1.5 + Math.sin(f * Math.PI) * height * 0.4 + f * 0.05,
            z + Math.sin(a) * f * 0.9,
          ];
        beam(g, prev, p, 0.025, 0.025, 'leaf');
        for (const s of [-1, 1]) {
          const q = [
            p[0] + Math.cos(a + s * 0.9) * 0.2 * (1 - f * 0.65),
            p[1] + 0.015,
            p[2] + Math.sin(a + s * 0.9) * 0.2 * (1 - f * 0.65),
          ];
          beam(g, p, q, 0.075, 0.035, 'leaf');
        }
        prev = p;
      }
    }
  }
  for (const x of [-6.9, 6.9]) for (const z of [-9, -4, 4, 9]) plant(x, z);
  // Natural-proportion clothed congregation. All models share the same canonical facing (-Z).
  function person(id, x, z, female = false, variant = 0, imam = false) {
    const g = 'Congregation',
      h = 2.12,
      headY = 1.91;
    material(
      'skin' + variant,
      ['#ba8665', '#885c41', '#d6ad88', '#a87350'][variant % 4],
    );
    const skin = 'skin' + variant;
    const robeColor = imam
      ? '#34251f'
      : female
        ? ['#202b3f', '#40363c', '#293e3a', '#60534f'][variant % 4]
        : ['#ece6d7', '#9a9c90', '#596759', '#7d6b59'][variant % 4];
    const robe = 'robe' + id;
    material(robe, robeColor);
    const profile = [
      [0.29, 0.08],
      [0.28, 0.28],
      [0.245, 0.65],
      [0.205, 1.05],
      [0.245, 1.55],
      [0.19, 1.66],
    ].map((p) => new T.Vector2(...p));
    mesh(g, new T.LatheGeometry(profile, 8), [x, 0, z], robe);
    for (const s of [-1, 1]) {
      box(g, [x + s * 0.12, 0.045, z - 0.05], [0.1, 0.08, 0.23], skin);
      beam(
        g,
        [x + s * 0.23, 1.55, z],
        [x + s * 0.27, 1.3, z - 0.07],
        0.14,
        0.14,
        robe,
      );
      beam(
        g,
        [x + s * 0.27, 1.3, z - 0.07],
        [x - s * 0.025, 1.36, z - 0.21],
        0.115,
        0.115,
        robe,
      );
      box(
        g,
        [x - s * 0.025, 1.36 + (s > 0 ? 0.025 : 0), z - 0.22],
        [0.1, 0.12, 0.055],
        skin,
      );
    }
    cylinder(g, [x, 1.75, z], 0.065, 0.2, skin);
    cylinder(g, [x, headY, z], 0.125, 0.25, skin);
    const face = imam
      ? 'yasser-face'
      : female
        ? variant % 2
          ? 'woman-cream-face'
          : 'woman-navy-face'
        : variant % 2
          ? 'elder-face'
          : 'man-face';
    mesh(
      g,
      new T.PlaneGeometry(0.205, 0.24),
      [x, headY, z - 0.128],
      face,
      new T.Quaternion().setFromAxisAngle(up, Math.PI),
    );
    const cloth = imam
      ? 'whiteGhutra'
      : female
        ? 'headcloth' + variant
        : 'whiteGhutra';
    material('whiteGhutra', '#f4efdf');
    if (female) material(cloth, variant % 2 ? '#c0b6a1' : '#263348');
    // Head cloth has thickness, side drapes and a stepped crown.
    for (const s of [-1, 1])
      box(g, [x + s * 0.145, 1.87, z + 0.01], [0.045, 0.38, 0.27], cloth);
    box(g, [x, 2.055, z], [0.28, 0.045, 0.28], cloth);
    box(g, [x, 1.85, z + 0.145], [0.32, 0.4, 0.04], cloth);
    beam(g, [x, 1.9, z + 0.15], [x, 1.52, z + 0.13], 0.28, 0.045, cloth);
    if (imam) {
      for (const s of [-1, 1])
        beam(
          g,
          [x + s * 0.19, 1.62, z - 0.15],
          [x + s * 0.22, 0.12, z - 0.24],
          0.028,
          0.035,
          'gold',
        );
      box(g, [x, 0.85, z - 0.225], [0.25, 1.45, 0.028], 'whiteGhutra');
      for (let k = 0; k < 12; k++) {
        const a = (k * Math.PI) / 6;
        box(
          g,
          [x + Math.cos(a) * 0.15, 2.055, z + Math.sin(a) * 0.15],
          [0.065, 0.038, 0.045],
          'walnut',
        );
      }
    }
    group(g).userData[id] = {
      id,
      x,
      z,
      height: h,
      gender: female ? 'female' : 'male',
      imam,
      panelApproved: false,
    };
  }
  person('yasser-al-dosari', 0, -7, false, 0, true);
  for (let i = 0; i < 18; i++)
    person(
      'worshipper-man-' + (i + 1),
      ((i % 6) - 2.5) * 0.8,
      -3.8 + Math.floor(i / 6) * 2.7,
      false,
      i % 4,
    );
  for (let i = 0; i < 12; i++)
    person(
      'worshipper-woman-' + (i + 1),
      ((i % 4) - 1.5) * 0.95,
      5.1 + Math.floor(i / 4) * 1.85,
      true,
      i % 4,
    );
  // Build GPU-efficient named instanced meshes, retained by GLB instancing extension.
  const dummy = new T.Object3D();
  let instances = 0;
  for (const [key, { g, geo, mat, items }] of queues) {
    const m = new T.InstancedMesh(geoms[geo], mats[mat], items.length);
    m.name = key;
    m.castShadow = true;
    m.receiveShadow = true;
    for (let i = 0; i < items.length; i++) {
      const p = items[i];
      dummy.position.copy(V(p.pos));
      dummy.quaternion.copy(p.q);
      dummy.scale.set(...p.scale);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
      if (p.tint) m.setColorAt(i, p.tint);
    }
    m.instanceMatrix.needsUpdate = true;
    m.frustumCulled = false;
    group(g).add(m);
    instances += items.length;
  }
  root.userData.instances = instances;
  return { root, groups, materials: mats, spec: MODEL_SPEC };
}
