# Golden prayer hall — 3D mosque model

A reference-based voxel/pixel-art interpretation of the supplied mosque, with
editable geometry, textured materials and static praying figures. DRAFT —
AWAITING REVIEW. This is a standalone model and component, not an app deployment.

## Included

- `mosque-with-congregation.glb`: complete mosque, imam and 30 adult worshippers.
- `mosque-architecture.glb`: the same architectural model without the people.
- `index.html`: interactive viewer with orbit, zoom, pan and 11 camera presets.
- `mosque.mjs`: editable model-building source; exports `createMosque()`.
- `mosque-component.mjs`: embeddable `<mosque-model>` web component.
- `previews/`: actual rendered angles, interior/details, contact sheet and orbit MP4.
- `assets/`: authored pixel material tiles, original atlas and pixel face textures.
- `validation.json` and `blender-validation.json`: browser/export/import checks.

The model includes limestone block walls and faceted pillars, pointed arches,
coffered geometric wood ceiling panels, tiered hexagonal brass lanterns, arched
windows and outdoor foliage, a recessed illuminated mihrab, wall-to-wall teal
carpet with repeating geometric rosettes, a fringed individual mat, walnut
lattice screen and ferns in gold planters. The imam wears ivory clothing, a
brown/gold bisht, white head covering, dark headband and glasses. Men stand in
three rows behind him; women stand beyond the carved screen. Figures have tall
adult proportions and are stylized architectural entourage, with static folded
hands. Their clothing is geometry, not a cloth simulation or skeletal animation.

## Open the viewer

Extract the ZIP, open a terminal in this folder, and run:

```sh
python3 -m http.server 5186
```

Open http://localhost:5186. All runtime modules and images are included, so the
viewer needs no internet after download. Serve through HTTP rather than opening
`index.html` as a local file. A browser supporting WebGL is required.

Drag to orbit; scroll to zoom; right-drag to pan. Camera presets include the
reference side, reverse/front, rear, east/west, isometric corners, bird's-eye,
interior ceiling, mihrab and chandelier. Switch between perspective and
orthographic projection. Toggle the ceiling, automatic camera-side wall cutaway,
and congregation. `Download GLB` exports a full model with all walls/roof,
regardless of the cutaway used for viewing; the congregation checkbox determines
whether people are included.

## Use the component or geometry

```html
<script type="module" src="./mosque-component.mjs"></script>
<mosque-model id="hall"></mosque-model>
<script>
  // After the element is connected:
  // hall.shot('bird');
  // hall.rotate(180);
</script>
```

Or import the builder into a Three.js scene:

```js
import { createMosque } from './mosque.mjs';
const { root, groups, spec } = await createMosque();
scene.add(root);
groups.Ceiling.visible = false;
```

Named groups separate the floor, mihrab, walls, arcade, ceiling, lanterns,
partition, plants, lighting and congregation. Approximate dimensions are
16 × 22 × 8.2 model units, with Y up. The builder uses fixed authored variation;
there are no random changes while viewing. Texture files resolve relative to
the model module. Retain its `assets/` and `vendor/` directories when embedding.

## Import and visual limits

Both GLBs embed their textures and use standard PBR materials, punctual lights
and `EXT_mesh_gpu_instancing`. They were loaded in the bundled GLTFLoader and
Blender 4.3.2. Blender imported 15,231 mesh instances and nine texture images.
For editors that do not support GPU instancing, import in Blender and export a
converted copy. Roof and walls are complete in the GLBs; hide named groups for
a cutaway view. The web viewer adds environment reflections, a sun/ambient-light
setup, shadows and lightweight golden light-shaft effects. Those viewer effects
are provided by `viewer.mjs`; GLB viewers apply their own environment lighting.

The model is a stylized reconstruction based on the supplied illustrations,
not a measured architectural survey or a pixel-identical recreation of them.
No generated calligraphy or sacred text appears. Named figure approval remains
false; visual generation does not grant review approval. Preview video is silent.

Three.js 0.180.0 and its add-ons are bundled under the MIT license in
`vendor/THREE-LICENSE.txt`. Material tiles were generated for this requested
model; face textures are reused from the owner's earlier prayer character pack.

Preview stills use lossless WebP in the ZIP; decoded pixels were verified against
the original screenshots. GLB files retain their embedded PNG textures.
