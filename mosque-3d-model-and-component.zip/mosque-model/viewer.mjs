import * as T from './vendor/three.module.min.js';
import { RoomEnvironment } from './vendor/RoomEnvironment.js';
import { OrbitControls } from './vendor/OrbitControls.js';
import { GLTFExporter } from './vendor/GLTFExporter.js';
import { createMosque } from './mosque.mjs';
const canvas = document.querySelector('canvas'),
  renderer = new T.WebGLRenderer({
    canvas,
    antialias: false,
    preserveDrawingBuffer: true,
  });
renderer.setSize(1200, 800, false);
renderer.setPixelRatio(1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = T.PCFSoftShadowMap;
renderer.toneMapping = T.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
const scene = new T.Scene();
const pmrem = new T.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.25;
pmrem.dispose();
scene.background = new T.Color('#273439');
const model = await createMosque();
scene.add(model.root);
const persp = new T.PerspectiveCamera(44, 1.5, 0.1, 180),
  ortho = new T.OrthographicCamera(-18, 18, 12, -12, 0.1, 180);
let camera = persp;
const ambient = new T.HemisphereLight('#ffe9c9', '#758e8c', 0.65);
scene.add(ambient);
const sun = new T.DirectionalLight('#ffe0ab', 2.2);
sun.position.set(-14, 20, -6);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, {
  left: -18,
  right: 18,
  top: 18,
  bottom: -18,
  near: 0.5,
  far: 70,
});
sun.shadow.normalBias = 0.025;
sun.shadow.bias = -0.00005;
scene.add(sun);
const fill = new T.DirectionalLight('#a3c7d2', 0.85);
fill.position.set(10, 8, 12);
scene.add(fill);
const atmosphere = new T.Group();
atmosphere.name = 'Viewer-only light shafts';
scene.add(atmosphere);
const shaftMat = new T.ShaderMaterial({
  transparent: true,
  depthWrite: false,
  side: T.DoubleSide,
  blending: T.AdditiveBlending,
  vertexShader:
    'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:
    'varying vec2 vUv;void main(){float edge=pow(max(0.,1.-abs(vUv.x-.5)*2.),2.);float fade=smoothstep(0.,.15,vUv.y)*(1.-smoothstep(.75,1.,vUv.y));gl_FragColor=vec4(1.,.74,.36,edge*fade*.055);}',
});
for (const z of [-7.5, -2.5, 2.5, 7.5]) {
  const A = new T.Vector3(-7.7, 5.5, z),
    B = new T.Vector3(3, 0.05, z + 4),
    d = B.clone().sub(A),
    m = new T.Mesh(new T.PlaneGeometry(2.0, d.length()), shaftMat);
  m.position.copy(A.add(B).multiplyScalar(0.5));
  m.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), d.normalize());
  atmosphere.add(m);
}
let controls,
  cutaway = true,
  people = true,
  roof = false;
function setupControls() {
  controls?.dispose();
  controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 2, 0);
  controls.minDistance = 2;
  controls.maxDistance = 75;
  controls.maxPolarAngle = Math.PI * 0.49;
  controls.addEventListener('change', render);
}
setupControls();
function render() {
  const g = model.groups;
  g['Congregation'].visible = people;
  g['Ceiling'].visible = roof;
  g['Vaults'].visible = roof || camera.position.y < 15;
  g['Qibla-wall'].visible = !cutaway || camera.position.z > 0;
  g['Mihrab'].visible = g['Qibla-wall'].visible;
  g['Entrance-wall'].visible = !cutaway || camera.position.z < 0;
  g['West-wall'].visible = !cutaway || camera.position.x > 0;
  g['East-wall'].visible = !cutaway || camera.position.x < 0;
  renderer.render(scene, camera);
}
export const SHOTS = {
  reference: { p: [12, 9, 15], t: [0, 2, -1] },
  front: { p: [0, 12, -30], t: [0, 1, 1] },
  rear: { p: [0, 12, 30], t: [0, 2, -1] },
  east: { p: [30, 13, 0], t: [0, 2, 0] },
  west: { p: [-30, 13, 0], t: [0, 2, 0] },
  northEast: { p: [22, 16, -24], t: [0, 2, 0] },
  southWest: { p: [-22, 16, 24], t: [0, 2, 0] },
  bird: { p: [0, 36, 0.001], t: [0, 0, 0], ortho: true },
  interior: { p: [4.6, 3.9, 9.7], t: [0, 3.5, -6], inside: true },
  mihrab: { p: [4, 3.5, -3], t: [0, 2.5, -10] },
  lantern: { p: [4, 6, 4], t: [0, 6, 0], inside: true },
};
function shot(name) {
  const s = SHOTS[name];
  document.querySelector('#projection').value = s?.ortho ? 'ortho' : 'persp';
  if (!s) throw Error('Unknown shot');
  const next = s.ortho ? ortho : persp;
  if (next !== camera) {
    camera = next;
    setupControls();
  }
  camera.up.set(0, 1, 0);
  camera.position.set(...s.p);
  controls.target.set(...s.t);
  cutaway = !s.inside;
  roof = !!s.inside;
  document.querySelector('#cutaway').checked = cutaway;
  document.querySelector('#roof').checked = roof;
  controls.update();
  render();
}
async function exportGLB({ withPeople = true } = {}) {
  const visibility = [];
  model.root.traverse((o) => {
    visibility.push([o, o.visible]);
    o.visible = true;
  });
  model.groups.Congregation.visible = withPeople;
  try {
    const buffer = await new GLTFExporter().parseAsync(model.root, {
      binary: true,
      onlyVisible: true,
      trs: false,
      maxTextureSize: 1024,
    });
    return buffer;
  } finally {
    for (const [o, v] of visibility) o.visible = v;
    render();
  }
}
async function saveGLB() {
  const buffer = await exportGLB({ withPeople: people });
  const blob = new Blob([buffer], { type: 'model/gltf-binary' }),
    link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = people
    ? 'mosque-with-congregation.glb'
    : 'mosque-architecture.glb';
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}
document.querySelector('#shot').onchange = (e) => shot(e.target.value);
document.querySelector('#cutaway').onchange = (e) => {
  cutaway = e.target.checked;
  render();
};
document.querySelector('#roof').onchange = (e) => {
  roof = e.target.checked;
  render();
};
document.querySelector('#people').onchange = (e) => {
  people = e.target.checked;
  render();
};
document.querySelector('#export').onclick = saveGLB;
document.querySelector('#projection').onchange = (e) => {
  const next = e.target.value === 'ortho' ? ortho : persp;
  if (camera !== next) {
    const p = camera.position.clone(),
      target = controls.target.clone();
    camera = next;
    setupControls();
    camera.position.copy(p);
    controls.target.copy(target);
    controls.update();
    render();
  }
};
window.mosque = {
  model,
  scene,
  renderer,
  get camera() {
    return camera;
  },
  shot,
  render,
  exportGLB,
  orbit(degrees) {
    const a = (degrees * Math.PI) / 180;
    camera.position.set(Math.sin(a) * 32, 16, Math.cos(a) * 32);
    controls.target.set(0, 2, 0);
    controls.update();
    render();
  },
  setPeople(value) {
    people = value;
    render();
  },
};
window.mosqueReady = true;
shot('reference');
document.querySelector('#status').textContent =
  `${model.root.userData.instances.toLocaleString()} model parts · DRAFT`;
if (parent !== window) parent.postMessage({ mosqueReady: true }, '*');
window.addEventListener('message', (e) => {
  if (e.source !== parent || !e.data?.mosque) return;
  if (e.data.shot) shot(e.data.shot);
  if (e.data.orbit !== undefined) window.mosque.orbit(e.data.orbit);
});
