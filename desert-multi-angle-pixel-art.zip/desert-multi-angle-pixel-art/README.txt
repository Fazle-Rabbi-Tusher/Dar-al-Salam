MULTI-ANGLE PIXEL ART

Five original-resolution PNG sheets generated for the supplied references.

historic-building-8-views.png: eight views of the weathered stair-and-arch building.
reciter-turnaround-and-poses.png: eight turnaround views plus four portrait/gesture poses.
desert-guide-camels-and-rider.png: guide, bare camel and saddled/ridden camel views.
desert-terrain-multiple-views.png: dunes, oasis, mesa and caravan terrain rotations.
desert-buildings-and-props.png: fortress, tent, well, market stall and vegetation.

These are 2D pixel-art reference sheets shaded to appear three-dimensional,
not rigged 3D meshes or animated frame sequences. Backgrounds are charcoal.
Original full sheets are included without resampling or image modifications.
The current app and its reverted source are unchanged.
